'use client';

import { createContext, useContext, useEffect, useMemo, useState } from 'react';
import type { Session } from '@supabase/supabase-js';
import { supabase, isSupabaseConfigured, supabaseConfigHint } from '@/lib/supabase';
import { fetchStoreConfigDefaults } from '@/lib/storeDisplayName';
import { defaultRolePermissions, type PermissionKey, type UserRole } from '@/lib/permissions';

type UserProfile = {
  user_id: string;
  full_name: string | null;
  role: UserRole;
  store_id: string | null;
};

function withTimeout<T>(promise: PromiseLike<T>, ms: number): Promise<T> {
  return Promise.race([
    promise,
    new Promise<never>((_, reject) => setTimeout(() => reject(new Error('timeout')), ms)),
  ]) as Promise<T>;
}

type AuthContextValue = {
  loading: boolean;
  session: Session | null;
  profile: UserProfile | null;
  permissions: Record<PermissionKey, boolean>;
  hasPermission: (key: PermissionKey) => boolean;
  signOut: () => Promise<void>;
};

const AuthContext = createContext<AuthContextValue>({
  loading: true,
  session: null,
  profile: null,
  permissions: { ...defaultRolePermissions.cashier },
  hasPermission: () => false,
  signOut: async () => {},
});

export function useAuth() {
  return useContext(AuthContext);
}

export default function AuthProvider({ children }: { children: React.ReactNode }) {
  const disableAuthByEnv = process.env.NEXT_PUBLIC_DISABLE_AUTH === 'true';
  let isLocalLikeRuntime = false;
  try {
    if (typeof window !== 'undefined') {
      const host = window.location.hostname;
      isLocalLikeRuntime =
        window.location.protocol === 'app:' ||
        host === 'localhost' ||
        host === '127.0.0.1' ||
        host.endsWith('.local');
    }
  } catch {
    // ignore runtime inspection errors
  }

  // 保险逻辑：生产环境下仅允许本地/桌面环境关闭鉴权，公网域名会自动忽略该开关。
  const disableAuth =
    disableAuthByEnv &&
    (process.env.NODE_ENV !== 'production' || isLocalLikeRuntime);

  useEffect(() => {
    if (disableAuthByEnv && !disableAuth) {
      console.warn(
        '[AuthProvider] 已忽略 NEXT_PUBLIC_DISABLE_AUTH=true：生产环境公网访问默认强制启用鉴权。',
      );
    }
  }, [disableAuthByEnv, disableAuth]);

  const [loading, setLoading] = useState(disableAuth ? false : isSupabaseConfigured);
  const [session, setSession] = useState<Session | null>(null);
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [rolePermissionOverrides, setRolePermissionOverrides] = useState<
    Partial<Record<UserRole, Partial<Record<PermissionKey, boolean>>>>
  >({});

  async function loadProfile(userId: string) {
    try {
      const result = (await withTimeout(
        supabase
          .from('user_profiles')
          .select('user_id, full_name, role, store_id')
          .eq('user_id', userId)
          .maybeSingle(),
        5000,
      )) as { data: UserProfile | null };
      setProfile((result.data as UserProfile | null) ?? null);
    } catch {
      setProfile(null);
    }
  }

  useEffect(() => {
    if (disableAuth) {
      // 本地开发用：跳过 Supabase 登录与 user_profiles 绑定。
      // 以 owner 权限放行，避免 RLS 因 store_id 为空导致写入失败。
      const fakeSession = {
        user: { id: 'local-dev-user', email: 'local-dev' },
      } as unknown as Session;
      setSession(fakeSession);
      setProfile({ user_id: 'local-dev-user', full_name: '本地所有权', role: 'owner', store_id: null });
      setRolePermissionOverrides({});
      setLoading(false);
      return;
    }

    if (!isSupabaseConfigured) return;

    (async () => {
      try {
        // 防止异常环境下 getSession/资料查询卡住导致界面一直“加载中”
        const result = (await withTimeout(supabase.auth.getSession(), 8000)) as {
          data: { session: Session | null };
        };
        const s = result.data.session;
        setSession(s ?? null);
        setLoading(false);
        if (s?.user?.id) void loadProfile(s.user.id);
      } catch {
        setSession(null);
        setProfile(null);
        setLoading(false);
      } finally {
        // no-op
      }
    })();

    const { data: sub } = supabase.auth.onAuthStateChange(async (_event, s) => {
      try {
        setSession(s ?? null);
        if (s?.user?.id) {
          setLoading(false);
          void loadProfile(s.user.id);
        } else {
          setProfile(null);
          setLoading(false);
        }
      } finally {
        // no-op
      }
    });
    return () => sub.subscription.unsubscribe();
  }, []);

  useEffect(() => {
    if (disableAuth) return;
    if (!isSupabaseConfigured) return;
    if (!session?.user?.id) return;
    void fetchStoreConfigDefaults(supabase);
  }, [session?.user?.id, disableAuth]);

  useEffect(() => {
    if (disableAuth) return;
    if (!isSupabaseConfigured) return;
    (async () => {
      const { data } = await supabase
        .from('role_permissions')
        .select('role, permissions')
        .in('role', ['owner', 'manager', 'cashier', 'inventory']);
      const map: Partial<Record<UserRole, Partial<Record<PermissionKey, boolean>>>> = {};
      for (const row of data ?? []) {
        map[row.role as UserRole] = (row.permissions || {}) as Partial<Record<PermissionKey, boolean>>;
      }
      setRolePermissionOverrides(map);
    })();
  }, []);

  const resolvedPermissions = useMemo(
    () =>
      profile
        ? {
            ...defaultRolePermissions[profile.role],
            ...(rolePermissionOverrides[profile.role] || {}),
          }
        : { ...defaultRolePermissions.cashier },
    [profile, rolePermissionOverrides],
  );

  const value = useMemo(
    () => ({
      loading,
      session,
      profile,
      permissions: resolvedPermissions,
      hasPermission: (key: PermissionKey) => !!resolvedPermissions[key],
      signOut: async () => {
        await supabase.auth.signOut();
        setProfile(null);
      },
    }),
    [loading, session, profile, resolvedPermissions],
  );

  if (!isSupabaseConfigured && !disableAuth) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50 text-gray-700 p-6">
        <div className="max-w-xl rounded-xl border border-amber-200 bg-amber-50 p-5 text-sm leading-relaxed">
          {supabaseConfigHint}
        </div>
      </div>
    );
  }

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}


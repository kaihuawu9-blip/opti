'use client';

import { Suspense, useEffect, useMemo, useState } from 'react';
import { usePathname } from 'next/navigation';
import { supabase } from '@/lib/supabase';
import { toChineseErrorMessage } from '@/lib/userMessages';
import Sidebar from '@/components/Sidebar';
import { useAuth } from '@/components/AuthProvider';
import { roleNameMap } from '@/lib/permissions';
import { getDefaultUpdateManifestUrl } from '@/lib/optiAiPublic';
import { APP_NAME } from '@/lib/constants';

function RouteModuleFallback() {
  return (
    <div className="min-h-[40vh] flex flex-col items-center justify-center gap-3 text-gray-500">
      <div
        className="h-8 w-8 rounded-full border-2 border-gray-200 border-t-blue-600 animate-spin"
        aria-hidden
      />
      <p className="text-sm">加载模块中…</p>
    </div>
  );
}

function LoginScreen() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);

  const handleLogin = async () => {
    if (!email.trim() || !password.trim()) {
      window.alert('请输入账号和密码');
      return;
    }
    if (loading) return;
    setLoading(true);
    try {
      const loginTask = supabase.auth.signInWithPassword({
        email: email.trim(),
        password,
      });
      const timeoutTask = new Promise<never>((_, reject) => {
        window.setTimeout(() => reject(new Error('登录请求超时，请检查网络或云端鉴权服务')), 12000);
      });
      const { error } = (await Promise.race([loginTask, timeoutTask])) as Awaited<typeof loginTask>;
      if (error) {
        window.alert('登录失败：' + toChineseErrorMessage(error.message));
      }
    } catch (e) {
      const msg = e instanceof Error ? e.message : String(e);
      window.alert('登录失败：' + toChineseErrorMessage(msg));
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen w-full bg-gray-50 flex items-center justify-center p-6">
      <div className="w-full max-w-md bg-white border border-gray-200 rounded-2xl p-6 shadow-sm">
        <h1 className="text-2xl font-bold text-gray-800 mb-1">{APP_NAME}</h1>
        <p className="text-sm text-gray-500 mb-6">员工登录</p>
        <div className="space-y-3">
          <input
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            className="w-full px-3 py-2 border border-gray-200 rounded-lg"
            placeholder="账号（邮箱）"
          />
          <input
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            className="w-full px-3 py-2 border border-gray-200 rounded-lg"
            placeholder="密码"
          />
          <button
            type="button"
            onClick={handleLogin}
            disabled={loading}
            className="w-full py-2.5 rounded-lg bg-blue-600 text-white font-medium hover:bg-blue-700 disabled:opacity-60"
          >
            {loading ? '登录中...' : '登录'}
          </button>
        </div>
      </div>
    </div>
  );
}

export default function AppShell({ children }: { children: React.ReactNode }) {
  const pathname = usePathname();
  const pathnameNorm = (pathname || '').replace(/\/+$/, '') || '/';
  const { loading, session, profile } = useAuth();
  const [updateInfo, setUpdateInfo] = useState<{
    latestVersion: string;
    notes?: string;
    downloadUrl?: string;
    force?: boolean;
  } | null>(null);
  const [checkingUpdate, setCheckingUpdate] = useState(false);

  const currentVersion = process.env.NEXT_PUBLIC_APP_VERSION || '1.0.0';
  const updateManifestExplicit = (process.env.NEXT_PUBLIC_UPDATE_MANIFEST_URL || '').trim();
  const updateManifestUrl =
    updateManifestExplicit === 'off' || updateManifestExplicit === 'false'
      ? ''
      : updateManifestExplicit || getDefaultUpdateManifestUrl();

  const compareSemver = useMemo(
    () => (a: string, b: string) => {
      const pa = a.split('.').map((x) => Number.parseInt(x, 10) || 0);
      const pb = b.split('.').map((x) => Number.parseInt(x, 10) || 0);
      const len = Math.max(pa.length, pb.length);
      for (let i = 0; i < len; i += 1) {
        const va = pa[i] || 0;
        const vb = pb[i] || 0;
        if (va > vb) return 1;
        if (va < vb) return -1;
      }
      return 0;
    },
    [],
  );

  useEffect(() => {
    let mounted = true;
    const runningInElectron = typeof window !== 'undefined' && window.location.protocol === 'app:';
    if (!runningInElectron || !updateManifestUrl) return;
    setCheckingUpdate(true);
    (async () => {
      try {
        const resp = await fetch(updateManifestUrl, { cache: 'no-store' });
        if (!resp.ok) return;
        const data = (await resp.json()) as {
          latestVersion?: string;
          notes?: string;
          downloadUrl?: string;
          force?: boolean;
        };
        const latestVersion = (data.latestVersion || '').trim();
        if (!latestVersion) return;
        if (compareSemver(latestVersion, currentVersion) > 0 && mounted) {
          setUpdateInfo({
            latestVersion,
            notes: data.notes,
            downloadUrl: data.downloadUrl,
            force: Boolean(data.force),
          });
        }
      } catch {
        // ignore update check errors
      } finally {
        if (mounted) setCheckingUpdate(false);
      }
    })();
    return () => {
      mounted = false;
    };
  }, [updateManifestUrl, compareSemver, currentVersion]);

  const isPublicBrandPage = pathnameNorm === '/brand';
  /** 未登录访客：全屏品牌页；已登录从侧栏进入时保留主导航 */
  const isBrandPublicStandalone = isPublicBrandPage && !loading && !session;

  if (isBrandPublicStandalone) {
    return (
      <div className="min-h-screen min-h-dvh">
        <Suspense fallback={<div className="min-h-screen bg-[#030816] flex items-center justify-center text-sky-200/50 text-sm">加载中…</div>}>
          {children}
        </Suspense>
      </div>
    );
  }

  if (loading) return <div className="h-screen flex items-center justify-center">加载中...</div>;
  if (!session) return <LoginScreen />;
  if (!profile) {
    return (
      <div className="min-h-screen w-full bg-gray-50 flex items-center justify-center p-6">
        <div className="max-w-xl rounded-xl border border-amber-200 bg-amber-50 p-5 text-sm leading-relaxed text-amber-900 space-y-4">
          <div>
            当前账号未绑定员工权限。请管理员在 <code className="text-xs">user_profiles</code> 表中配置{' '}
            <code className="text-xs">role</code> 与 <code className="text-xs">store_id</code> 后重新登录。绑定前无法使用收银台、库存等模块。
          </div>
          <div className="text-xs text-amber-800/90 break-all">当前账号：{session.user.email}</div>
          <button
            type="button"
            onClick={() => supabase.auth.signOut()}
            className="px-4 py-2 text-sm rounded-lg bg-amber-600 text-white hover:bg-amber-700"
          >
            退出登录并切换账号
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="flex h-full bg-gray-50 text-gray-900">
      <Sidebar />
      <main className="flex-1 h-screen overflow-y-auto bg-gray-50">
        {updateInfo && (
          <div
            className={`mx-8 mt-4 rounded-xl border p-3 ${
              updateInfo.force ? 'border-red-200 bg-red-50 text-red-900' : 'border-blue-200 bg-blue-50 text-blue-900'
            }`}
          >
            <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-2">
              <div className="text-sm">
                发现新版本 <strong>{updateInfo.latestVersion}</strong>（当前 {currentVersion}）
                {updateInfo.notes ? `：${updateInfo.notes}` : ''}
              </div>
              <div className="flex items-center gap-2">
                {!updateInfo.force && (
                  <button
                    type="button"
                    onClick={() => setUpdateInfo(null)}
                    className="px-3 py-1.5 text-xs rounded-lg border border-blue-200 hover:bg-white"
                  >
                    稍后再说
                  </button>
                )}
                <button
                  type="button"
                  onClick={() => {
                    const target = updateInfo.downloadUrl || '';
                    if (!target) {
                      window.alert('未配置下载链接，请联系管理员。');
                      return;
                    }
                    if (window.electronApp?.openExternal) {
                      void window.electronApp.openExternal(target);
                    } else {
                      window.open(target, '_blank');
                    }
                  }}
                  className="px-3 py-1.5 text-xs rounded-lg bg-blue-600 text-white hover:bg-blue-700"
                >
                  立即更新
                </button>
              </div>
            </div>
          </div>
        )}
        <div className="px-8 py-4 border-b border-gray-200 bg-white flex items-center justify-end gap-4">
          <div className="text-sm text-gray-600">
            <span className="font-medium text-gray-800">{profile.full_name || session.user.email}</span>
            <span className="mx-2 text-gray-300">|</span>
            <span>{roleNameMap[profile.role]}</span>
            <span className="mx-2 text-gray-300">|</span>
            <span>{profile.store_id ? `门店ID:${profile.store_id}` : '未绑定门店'}</span>
            <span className="mx-2 text-gray-300">|</span>
            <span>{checkingUpdate ? '检查更新中…' : `版本 ${currentVersion}`}</span>
          </div>
          <button
            type="button"
            onClick={() => supabase.auth.signOut()}
            className="px-3 py-1.5 text-sm rounded-lg border border-gray-200 hover:bg-gray-50"
          >
            退出登录
          </button>
        </div>
        <div
          className={
            pathnameNorm === '/brand'
              ? 'p-0 min-h-full'
              : `p-8 ${pathnameNorm === '/dashboard' ? 'bg-[#f4f7fb] min-h-full' : ''}`
          }
        >
          <Suspense fallback={<RouteModuleFallback />}>{children}</Suspense>
        </div>
      </main>
    </div>
  );
}


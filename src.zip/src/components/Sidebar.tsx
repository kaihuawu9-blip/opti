'use client';

import { useEffect, useMemo, useState, type ComponentType } from 'react';
import { usePathname } from 'next/navigation';
import {
  ShoppingCart,
  Package,
  BarChart3,
  LayoutDashboard,
  Search,
  Shield,
  Wrench,
  Bot,
  Store,
  Settings,
  BookOpen,
  MessageCircle,
  Landmark,
  ChevronDown,
  Layers,
  Info,
} from 'lucide-react';
import { useAuth } from '@/components/AuthProvider';
import { useAppNavigate } from '@/lib/useAppNavigate';
import { APP_NAME } from '@/lib/constants';

type NavItem = {
  name: string;
  href: string;
  icon: ComponentType<{ className?: string }>;
  visible: boolean;
};

const MENU_PREFS_KEY = 'sidebar-menu-prefs-v3';
const MENU_PREFS_LEGACY_V2 = 'sidebar-menu-prefs-v2';
const MENU_PREFS_LEGACY_V1 = 'sidebar-menu-prefs-v1';

const FINANCE_HREFS = ['/reports', '/reconciliation'] as const;

/** 读 v3；从 v2/v1 迁移，并保证财务报表、财务对账默认显示在「财务管理」分组内 */
function loadSidebarMenuPrefs(): Record<string, boolean> {
  try {
    if (typeof window === 'undefined') return {};
    const v3 = window.localStorage.getItem(MENU_PREFS_KEY);
    if (v3) return JSON.parse(v3) as Record<string, boolean>;
    const v2 = window.localStorage.getItem(MENU_PREFS_LEGACY_V2);
    const v1 = window.localStorage.getItem(MENU_PREFS_LEGACY_V1);
    const raw = v2 || v1;
    if (raw) {
      const parsed = JSON.parse(raw) as Record<string, boolean>;
      for (const h of FINANCE_HREFS) delete parsed[h];
      window.localStorage.setItem(MENU_PREFS_KEY, JSON.stringify(parsed));
      return parsed;
    }
    return {};
  } catch {
    return {};
  }
}

const Sidebar = () => {
  const pathname = usePathname();
  const navigate = useAppNavigate();
  const { hasPermission, signOut } = useAuth();
  const [showMenuSettings, setShowMenuSettings] = useState(false);
  const [showBrandSettings, setShowBrandSettings] = useState(false);
  const [appTitle, setAppTitle] = useState(() => {
    try {
      if (typeof window === 'undefined') return APP_NAME;
      return window.localStorage.getItem('app-brand-title-v1') || APP_NAME;
    } catch {
      return APP_NAME;
    }
  });
  const [appLogoDataUrl, setAppLogoDataUrl] = useState(() => {
    try {
      if (typeof window === 'undefined') return '';
      return window.localStorage.getItem('app-brand-logo-v1') || '';
    } catch {
      return '';
    }
  });
  const [menuPrefs, setMenuPrefs] = useState<Record<string, boolean>>(loadSidebarMenuPrefs);
  const [financeExpanded, setFinanceExpanded] = useState(() => {
    const p = pathname.replace(/\/+$/, '') || '/';
    return p.startsWith('/reports') || p.startsWith('/reconciliation');
  });

  useEffect(() => {
    const p = pathname.replace(/\/+$/, '') || '/';
    if (p.startsWith('/reports') || p.startsWith('/reconciliation')) {
      setFinanceExpanded(true);
    }
  }, [pathname]);

  const mainNavItems = useMemo(
    (): NavItem[] => [
      { name: '工作台', href: '/dashboard', icon: LayoutDashboard, visible: true },
      { name: '收银台', href: '/cashier', icon: ShoppingCart, visible: hasPermission('cashier.view') },
      { name: '库存管理', href: '/inventory', icon: Package, visible: hasPermission('inventory.view') },
      { name: '套餐管理', href: '/packages', icon: Layers, visible: hasPermission('inventory.view') },
      { name: '客户查询', href: '/customers', icon: Search, visible: hasPermission('customers.view') },
    ],
    [hasPermission],
  );

  const financeNavItems = useMemo(
    (): NavItem[] => [
      { name: '财务报表', href: '/reports', icon: BarChart3, visible: hasPermission('reports.view') },
      { name: '财务对账', href: '/reconciliation', icon: Landmark, visible: hasPermission('reports.view') },
    ],
    [hasPermission],
  );

  const otherNavItems = useMemo(
    (): NavItem[] => [
      { name: '镜问镜答', href: '/chat', icon: MessageCircle, visible: true },
      { name: 'AI入口', href: '/ai', icon: Bot, visible: true },
      { name: '线上运营', href: '/online', icon: Store, visible: true },
      { name: '工具', href: '/tools', icon: Wrench, visible: true },
      { name: '科普', href: '/kepu', icon: BookOpen, visible: true },
      { name: '权限管理', href: '/admin', icon: Shield, visible: hasPermission('admin.view') },
      { name: '关于', href: '/about', icon: Info, visible: true },
    ],
    [hasPermission],
  );

  const navItems = useMemo(
    () => [...mainNavItems, ...financeNavItems, ...otherNavItems],
    [mainNavItems, financeNavItems, otherNavItems],
  );

  const visibleMainNav = useMemo(
    () =>
      mainNavItems.filter((x) => {
        if (!x.visible) return false;
        // 收银台：有权限则始终显示，避免在「菜单设置」里被误关后找不到入口
        if (x.href === '/cashier' && hasPermission('cashier.view')) return true;
        return menuPrefs[x.href] !== false;
      }),
    [mainNavItems, menuPrefs, hasPermission],
  );

  const visibleFinanceNav = useMemo(
    () => financeNavItems.filter((x) => x.visible && menuPrefs[x.href] !== false),
    [financeNavItems, menuPrefs],
  );

  const showFinanceSection = visibleFinanceNav.length > 0;

  const visibleOtherNav = useMemo(
    () => otherNavItems.filter((x) => x.visible && menuPrefs[x.href] !== false),
    [otherNavItems, menuPrefs],
  );

  /** 收银台不在此列表出现，避免被误关后「找不到收银」 */
  const configurableItems = useMemo(
    () => navItems.filter((x) => x.visible && x.href !== '/cashier'),
    [navItems],
  );

  const financeHrefSet = useMemo(() => new Set<string>(FINANCE_HREFS), []);

  const menuSettingsGroups = useMemo(() => {
    const store = configurableItems.filter((i) =>
      ['/dashboard', '/inventory', '/packages', '/customers'].includes(i.href),
    );
    const finance = configurableItems.filter((i) => financeHrefSet.has(i.href));
    const rest = configurableItems.filter(
      (i) => !['/dashboard', '/inventory', '/packages', '/customers', ...FINANCE_HREFS].includes(i.href),
    );
    return [
      { title: '门店', items: store },
      { title: '财务管理', items: finance },
      { title: '其他', items: rest },
    ].filter((g) => g.items.length > 0);
  }, [configurableItems, financeHrefSet]);

  const toggleMenuItem = (href: string, checked: boolean) => {
    setMenuPrefs((prev) => {
      const next = { ...prev, [href]: checked };
      try {
        window.localStorage.setItem(MENU_PREFS_KEY, JSON.stringify(next));
      } catch {
        // ignore
      }
      return next;
    });
  };

  const handleNavigate = (href: string) => {
    navigate(href);
  };

  const saveBrandSettings = (title: string, logo: string) => {
    const nextTitle = title.trim() || APP_NAME;
    setAppTitle(nextTitle);
    setAppLogoDataUrl(logo);
    try {
      window.localStorage.setItem('app-brand-title-v1', nextTitle);
      if (logo) window.localStorage.setItem('app-brand-logo-v1', logo);
      else window.localStorage.removeItem('app-brand-logo-v1');
    } catch {
      // ignore
    }
    setShowBrandSettings(false);
  };

  return (
    <div className="flex flex-col h-screen w-64 bg-gray-900 text-white border-r border-gray-800">
      <button
        type="button"
        onClick={() => setShowBrandSettings(true)}
        className="flex items-center justify-center h-16 border-b border-gray-800 hover:bg-gray-800/60 transition-colors"
        title="点击修改图标和名称"
      >
        {appLogoDataUrl ? (
          // eslint-disable-next-line @next/next/no-img-element
          <img src={appLogoDataUrl} alt="logo" className="w-8 h-8 mr-2 rounded object-cover border border-gray-700" />
        ) : (
          <LayoutDashboard className="w-8 h-8 mr-2 text-blue-500" />
        )}
        <span className="text-xl font-bold tracking-wider truncate max-w-[180px]">{appTitle}</span>
      </button>
      <nav className="flex-1 px-4 py-6 space-y-2 overflow-y-auto">
        {visibleMainNav.map((item) => (
          <NavLinkButton
            key={item.href}
            item={item}
            pathname={pathname}
            onNavigate={handleNavigate}
          />
        ))}

        {showFinanceSection && (
          <div className="pt-3">
            <button
              type="button"
              onClick={() => setFinanceExpanded((v) => !v)}
              className="flex w-full items-center justify-between gap-2 rounded-lg px-3 py-2 text-left text-gray-400 transition-colors hover:bg-gray-800/70 hover:text-gray-200"
              aria-expanded={financeExpanded}
            >
              <span className="flex items-center gap-2 text-[11px] font-semibold uppercase tracking-[0.12em]">
                <Landmark className="h-3.5 w-3.5 shrink-0 text-amber-500/90" aria-hidden />
                财务管理
              </span>
              <ChevronDown
                className={`h-4 w-4 shrink-0 transition-transform ${financeExpanded ? '' : '-rotate-90'}`}
                aria-hidden
              />
            </button>
            {financeExpanded ? (
              <div className="mt-1 space-y-1 border-l border-amber-600/35 ml-3 pl-2">
                {visibleFinanceNav.map((item) => (
                  <NavLinkButton
                    key={item.href}
                    item={item}
                    pathname={pathname}
                    onNavigate={handleNavigate}
                    nested
                  />
                ))}
              </div>
            ) : null}
          </div>
        )}

        {visibleOtherNav.length > 0 && (
          <div className={showFinanceSection || visibleMainNav.length > 0 ? 'pt-2' : ''}>
            {visibleOtherNav.map((item) => (
              <NavLinkButton
                key={item.href}
                item={item}
                pathname={pathname}
                onNavigate={handleNavigate}
              />
            ))}
          </div>
        )}
      </nav>
      <div className="p-4 border-t border-gray-800 space-y-3">
        <button
          type="button"
          onClick={() => setShowMenuSettings(true)}
          className="w-full inline-flex items-center justify-center px-3 py-2 text-sm rounded-lg border border-gray-700 text-gray-200 hover:bg-gray-800"
        >
          <Settings className="w-4 h-4 mr-1.5" />
          菜单设置
        </button>
        <button
          type="button"
          onClick={() => signOut()}
          className="w-full px-3 py-2 text-sm rounded-lg border border-gray-700 text-gray-200 hover:bg-gray-800"
        >
          退出登录（切换账号）
        </button>
        <div className="text-xs text-gray-500 text-center">v1.0.0 © 2026</div>
      </div>

      {showMenuSettings && (
        <div className="fixed inset-0 z-50 bg-black/40 p-4 flex items-center justify-center">
          <div className="w-full max-w-md rounded-2xl border border-gray-200 bg-white p-5 space-y-4 text-gray-800">
            <div className="flex items-center justify-between">
              <h3 className="text-base font-bold">菜单栏显示设置</h3>
              <button
                type="button"
                onClick={() => setShowMenuSettings(false)}
                className="px-2 py-1 text-sm rounded border border-gray-200 hover:bg-gray-50"
              >
                关闭
              </button>
            </div>
            <div className="space-y-4 max-h-72 overflow-y-auto">
              {menuSettingsGroups.map((group) => (
                <div key={group.title} className="space-y-2">
                  <p className="text-[11px] font-bold uppercase tracking-wide text-gray-400 px-0.5">{group.title}</p>
                  <div className="space-y-2">
                    {group.items.map((item) => (
                      <label
                        key={item.href}
                        className="flex items-center justify-between rounded-lg border border-gray-100 px-3 py-2"
                      >
                        <span className="text-sm">{item.name}</span>
                        <input
                          type="checkbox"
                          checked={menuPrefs[item.href] !== false}
                          onChange={(e) => toggleMenuItem(item.href, e.target.checked)}
                        />
                      </label>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {showBrandSettings && (
        <BrandSettingsModal
          initialTitle={appTitle}
          initialLogo={appLogoDataUrl}
          onCancel={() => setShowBrandSettings(false)}
          onSave={saveBrandSettings}
        />
      )}
    </div>
  );
};

function BrandSettingsModal({
  initialTitle,
  initialLogo,
  onCancel,
  onSave,
}: {
  initialTitle: string;
  initialLogo: string;
  onCancel: () => void;
  onSave: (title: string, logo: string) => void;
}) {
  const [title, setTitle] = useState(initialTitle);
  const [logo, setLogo] = useState(initialLogo);

  const handlePickLogo = (file?: File) => {
    if (!file) return;
    if (!file.type.startsWith('image/')) {
      window.alert('请选择图片文件');
      return;
    }
    if (file.size > 1024 * 1024) {
      window.alert('图标请控制在 1MB 内');
      return;
    }
    const reader = new FileReader();
    reader.onload = () => {
      setLogo(String(reader.result || ''));
    };
    reader.readAsDataURL(file);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/40 p-4 flex items-center justify-center">
      <div className="w-full max-w-md rounded-2xl border border-gray-200 bg-white p-5 space-y-4 text-gray-800">
        <div className="flex items-center justify-between">
          <h3 className="text-base font-bold">品牌显示设置</h3>
          <button
            type="button"
            onClick={onCancel}
            className="px-2 py-1 text-sm rounded border border-gray-200 hover:bg-gray-50"
          >
            关闭
          </button>
        </div>
        <div className="space-y-3">
          <div>
            <label className="block text-sm text-gray-600 mb-1">软件名称</label>
            <input
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              className="w-full px-3 py-2 border border-gray-200 rounded-lg"
              placeholder="输入显示名称"
            />
          </div>
          <div>
            <label className="block text-sm text-gray-600 mb-1">软件图标</label>
            <input
              type="file"
              accept="image/*"
              onChange={(e) => handlePickLogo(e.target.files?.[0])}
              className="w-full text-sm"
            />
            <p className="mt-1 text-xs text-gray-500">建议正方形图，1MB以内。仅影响本机界面显示。</p>
          </div>
          <div className="rounded-lg border border-gray-100 bg-gray-50 p-3 flex items-center">
            {logo ? (
              // eslint-disable-next-line @next/next/no-img-element
              <img src={logo} alt="preview" className="w-10 h-10 rounded object-cover border border-gray-200 mr-2" />
            ) : (
              <LayoutDashboard className="w-10 h-10 text-blue-500 mr-2" />
            )}
            <div className="text-sm font-semibold text-gray-700 truncate">{title.trim() || APP_NAME}</div>
          </div>
        </div>
        <div className="flex justify-end gap-2">
          <button
            type="button"
            onClick={() => setLogo('')}
            className="px-3 py-1.5 text-sm rounded border border-gray-200 hover:bg-gray-50"
          >
            清空图标
          </button>
          <button
            type="button"
            onClick={() => onSave(title, logo)}
            className="px-3 py-1.5 text-sm rounded bg-blue-600 text-white hover:bg-blue-700"
          >
            保存
          </button>
        </div>
      </div>
    </div>
  );
}

function NavLinkButton({
  item,
  pathname,
  onNavigate,
  nested,
}: {
  item: NavItem;
  pathname: string;
  onNavigate: (href: string) => void;
  nested?: boolean;
}) {
  const pathNorm = pathname.replace(/\/+$/, '') || '/';
  const hrefNorm = item.href.replace(/\/+$/, '') || '/';
  const isActive =
    pathNorm === hrefNorm || (pathNorm === '/' && hrefNorm === '/cashier');
  const Icon = item.icon;
  return (
    <button
      type="button"
      onClick={() => onNavigate(item.href)}
      className={`flex w-full items-center py-2.5 text-sm font-medium transition-all rounded-lg group cursor-pointer ${
        nested ? 'pl-3 pr-3' : 'px-4 py-3'
      } ${
        isActive
          ? 'bg-blue-600 text-white shadow-lg shadow-blue-500/20'
          : 'text-gray-400 hover:bg-gray-800 hover:text-white'
      }`}
    >
      <Icon
        className={`w-5 h-5 shrink-0 mr-3 transition-colors ${
          isActive ? 'text-white' : 'text-gray-500 group-hover:text-white'
        }`}
      />
      <span className="truncate text-left">{item.name}</span>
    </button>
  );
}

export default Sidebar;

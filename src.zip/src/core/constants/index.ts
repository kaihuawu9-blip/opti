export const APP_NAME = '镜售 (Opti-AI)' as const;

export const DEFAULT_STORE_DISPLAY_FALLBACK = '镜售管理系统' as const;

export const COPYRIGHT_LINE = 'Copyright © 2026 厦门厦客贸易有限公司' as const;

export const PRINT_TECH_SUPPORT_LINE = '技术支持: opti-ai.cn' as const;

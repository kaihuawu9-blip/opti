export * from './supabase';

export const disableAuthMode =
  process.env.NEXT_PUBLIC_DISABLE_AUTH === 'true' ||
  process.env.NEXT_PUBLIC_DISABLE_AUTH === '1';

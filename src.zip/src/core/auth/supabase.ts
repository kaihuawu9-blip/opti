import { createClient } from '@supabase/supabase-js';

export function getSupabaseUrl(): string {
  return (
    process.env.NEXT_PUBLIC_SUPABASE_URL?.trim() ||
    process.env.SUPABASE_URL?.trim() ||
    process.env.ALIYUN_SUPABASE_URL?.trim() ||
    process.env.NEXT_PUBLIC_ALIYUN_SUPABASE_URL?.trim() ||
    process.env.NEXT_PUBLIC_OPTI_AI_SUPABASE_URL?.trim() ||
    'https://placeholder.supabase.co'
  );
}

export function getSupabaseAnonKey(): string {
  return (
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY?.trim() ||
    process.env.SUPABASE_ANON_KEY?.trim() ||
    process.env.ALIYUN_SUPABASE_ANON_KEY?.trim() ||
    process.env.NEXT_PUBLIC_ALIYUN_SUPABASE_ANON_KEY?.trim() ||
    'placeholder-key'
  );
}

export function getSupabaseServiceKey(): string {
  return (
    process.env.SUPABASE_SERVICE_ROLE_KEY?.trim() ||
    process.env.SUPABASE_SECRET_KEY?.trim() ||
    process.env.ALIYUN_SUPABASE_SERVICE_KEY?.trim() ||
    ''
  );
}

const supabaseUrl = getSupabaseUrl();
const supabaseAnonKey = getSupabaseAnonKey();

export const isSupabaseConfigured =
  !!supabaseUrl &&
  !!supabaseAnonKey &&
  !supabaseUrl.includes('your-project.supabase.co') &&
  !supabaseAnonKey.includes('your-anon-key') &&
  !supabaseUrl.includes('placeholder.supabase.co') &&
  !supabaseAnonKey.includes('placeholder-key');

export const supabaseConfigHint =
  '云端数据服务未配置。请在 .env.local 填写服务地址与匿名密钥（支持 Supabase/Aliyun 自托管变量），保存后重新构建并启动。';

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

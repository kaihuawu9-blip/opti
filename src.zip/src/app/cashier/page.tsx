'use client';

import { useState, useEffect, useRef, useMemo, useCallback } from 'react';
import { supabase, isSupabaseConfigured, supabaseConfigHint } from '@/lib/supabase';
import { toChineseErrorMessage } from '@/lib/userMessages';
import {
  ShoppingCart,
  Plus,
  Minus,
  Trash2,
  Printer,
  X,
  QrCode,
  User,
  ClipboardList,
  Glasses,
  Camera,
} from 'lucide-react';
import { useAuth } from '@/components/AuthProvider';
import { useAppNavigate } from '@/lib/useAppNavigate';
import { roleNameMap } from '@/lib/permissions';
import PrintTemplate, { type PrintOrder } from '@/components/PrintTemplate';
import { resolveStoreDisplayName } from '@/lib/storeDisplayName';
import { ReceiptDesktopPrinterBar } from '@/components/ReceiptDesktopPrinterBar';
import { buildOrderQrPayload, ORDER_QR_MAGIC, parseOrderQrPayload } from '@/lib/orderQr';
import { localCache } from '@/lib/localCache';
import { printReceiptWithElectronPreference } from '@/lib/receiptElectronPrint';
import '@/styles/Print.css';

type Product = {
  id: string;
  name: string;
  price: number;
  stock: number;
  category?: string | null;
  brand?: string | null;
  model?: string | null;
  frame_type?: string | null;
  lens_type?: string | null;
  allow_discount?: boolean | null;
  allow_points?: boolean | null;
  allow_promo_price?: boolean | null;
  is_hot?: boolean | null;
  is_promo?: boolean | null;
  promo_price?: number | null;
  low_stock_threshold?: number | null;
};

/** 历史销售/挂单 JSON 中可能仍有 category「快充」，恢复购物车时剔除 */
const LEGACY_QUICK_CATEGORY = '快充';
/** 收银自定义：手写镜框+镜片描述 + 成套价，不落 SKU 库存，需验光（与套餐验光规则一致） */
const CUSTOM_COMBO_CATEGORY = '自主配镜';

function isUuid(id: string): boolean {
  return /^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(id);
}

function isLensProduct(p: Product): boolean {
  if ((p.category || '').trim() === '套餐') return true;
  if ((p.category || '').trim() === CUSTOM_COMBO_CATEGORY) return true;
  // 优先用字段 lens_type 判断；必要时用名称/分类兜底
  return Boolean(p.lens_type) || (p.category || '').includes('镜片') || p.name.toLowerCase().includes('镜片');
}

type ProductQuickCategory = 'all' | 'frame' | 'lens' | 'package' | 'other';

function getProductQuickCategory(p: Product): ProductQuickCategory {
  const c = String(p.category || '').trim();
  const n = String(p.name || '').toLowerCase();
  if (c === '套餐' || n.includes('套餐')) return 'package';
  if (c.includes('镜框') || String(p.frame_type || '').trim()) return 'frame';
  if (c.includes('镜片') || String(p.lens_type || '').trim() || n.includes('镜片')) return 'lens';
  return 'other';
}

type Store = {
  id: string;
  name: string;
};

/** 单眼：球镜 DS、矫正视力、瞳距(mm) 必填；柱镜 DC 选填，填 DC 则轴位必填；下加 ADD 选填 */
type RxEye = {
  ds: string;
  dc: string;
  axis: string;
  va: string;
  pd: string;
  add: string;
};

const emptyEye = (): RxEye => ({
  ds: '',
  dc: '',
  axis: '',
  va: '',
  pd: '',
  add: '',
});

/** 金额草稿：仅保留数字与最多一个小数点，避免 type=number 在 Electron/中文环境下无法键入或小数点被吞 */
function sanitizePriceDraft(raw: string): string {
  const t = raw.replace(/[^\d.]/g, '');
  const dot = t.indexOf('.');
  if (dot === -1) return t;
  return t.slice(0, dot + 1) + t.slice(dot + 1).replace(/\./g, '');
}

type CartItem = Product & {
  lineId: string;
  quantity: number;
  rx: { right: RxEye; left: RxEye };
  discountPercent: number;
  overrideUnitPrice?: number | null;
  /** 历史草稿/挂单：曾用快充行，仅用于恢复时过滤 */
  isQuickSale?: boolean;
  /** 自主配镜行：手写镜框+镜片+成套价 */
  isCustomCombo?: boolean;
};

function mergeRxEye(partial: Partial<RxEye> | undefined): RxEye {
  return { ...emptyEye(), ...partial };
}

function normalizeCartRx(item: CartItem): CartItem {
  return {
    ...item,
    rx: {
      right: mergeRxEye(item.rx?.right),
      left: mergeRxEye(item.rx?.left),
    },
  };
}

function isCustomComboLine(item: CartItem): boolean {
  return Boolean(item.isCustomCombo || (item.category || '').trim() === CUSTOM_COMBO_CATEGORY);
}

function isLegacyQuickCartLine(item: CartItem): boolean {
  return Boolean(item.isQuickSale || (item.category || '').trim() === LEGACY_QUICK_CATEGORY);
}

function filterOutLegacyQuickSaleLines(cart: CartItem[]): CartItem[] {
  return cart.filter((item) => !isLegacyQuickCartLine(item));
}

type PaymentMethod = 'cash' | 'wechat' | 'alipay' | 'meituan_douyin';
type SaleStatus = '待加工' | '加工中' | '待取镜' | '已完成' | '售后' | '已退单';

function paymentMethodLabel(m: PaymentMethod): string {
  switch (m) {
    case 'cash':
      return '现金';
    case 'wechat':
      return '微信被扫';
    case 'alipay':
      return '支付宝被扫';
    case 'meituan_douyin':
      return '美团/抖音';
    default:
      return m;
  }
}

type LastOrder = {
  store?: string;
  customer: { name: string; phone: string };
  items: CartItem[];
  total: number;
  time: string;
  saleNo: string;
  /** 本单首条 sales 行 id，印在二维码内 */
  primarySaleId: string;
  /** 取镜扫码用完整载荷 */
  orderQrPayload: string;
  paymentMethod?: PaymentMethod;
  /** 美团/抖音团购手动录入的券号（仅 meituan_douyin） */
  meituanVoucher?: string;
  /** 结算成功后构造并注入打印模板的订单对象 */
  orderObject: PrintOrder;
};

type OrderLookupRow = {
  id: string;
  sale_no: string | null;
  sale_status: string | null;
  quantity: number;
  total_price: number | string;
  product_category: string | null;
  products?: { name?: string | null } | null;
};
type CashierDraft = {
  selectedStore: string;
  customerName: string;
  customerPhone: string;
  cart: CartItem[];
};

type PendingBill = {
  id: string;
  createdAt: string;
  note: string;
  draft: CashierDraft;
};
type QuerySale = {
  id: string;
  created_at: string;
  quantity: number;
  total_price: number | string;
  customer_name?: string | null;
  customer_phone?: string | null;
  sale_no?: string | null;
  product_category?: string | null;
  product_brand?: string | null;
  product_model?: string | null;
  frame_type?: string | null;
  lens_type?: string | null;
  sale_status?: string | null;
  refund_reason?: string | null;
  products?: { name?: string | null } | null;
  stores?: { name?: string | null } | null;
};

function querySaleLineLabel(row: QuerySale): string {
  if (row.products?.name) return row.products.name;
  if ((row.product_category || '').trim() === LEGACY_QUICK_CATEGORY && row.product_model?.trim()) {
    return row.product_model.trim();
  }
  if ((row.product_category || '').trim() === CUSTOM_COMBO_CATEGORY) {
    const m = row.product_model?.trim();
    return m ? `自主配镜 · ${m}` : '自主配镜';
  }
  return row.product_model?.trim() || '—';
}
const CASHIER_DRAFT_KEY = 'cashier_draft_v1';
const PENDING_BILLS_KEY = 'cashier_pending_bills_v1';
const SALE_STATUSES: SaleStatus[] = ['待加工', '加工中', '待取镜', '已完成', '售后', '已退单'];

function isEyeRxComplete(eye: RxEye): boolean {
  const ds = String(eye.ds).trim();
  const va = String(eye.va).trim();
  const pd = String(eye.pd).trim();
  if (!ds || !va || !pd) return false;
  const dc = String(eye.dc).trim();
  const axis = String(eye.axis).trim();
  if (dc !== '' && !axis) return false;
  return true;
}

function isRxComplete(rx: CartItem['rx']): boolean {
  return isEyeRxComplete(rx.right) && isEyeRxComplete(rx.left);
}

/** 结算弹窗关闭后，按校验顺序找到第一个未满足的验光字段（用于自动聚焦，避免焦点落在 body 无法继续输入） */
function firstIncompleteRxField(rx: CartItem['rx']): { side: 'right' | 'left'; field: keyof RxEye } | null {
  for (const side of ['right', 'left'] as const) {
    const eye = rx[side];
    if (!String(eye.ds).trim()) return { side, field: 'ds' };
    if (!String(eye.va).trim()) return { side, field: 'va' };
    if (!String(eye.pd).trim()) return { side, field: 'pd' };
    const dc = String(eye.dc).trim();
    if (dc !== '' && !String(eye.axis).trim()) return { side, field: 'axis' };
  }
  return null;
}

function EyeRxBlock({
  title,
  eyeSide,
  eye,
  onPatch,
}: {
  title: string;
  eyeSide: 'right' | 'left';
  eye: RxEye;
  onPatch: (patch: Partial<RxEye>) => void;
}) {
  const row = (key: keyof RxEye, label: string, ph: string) => (
    <div className="min-w-0">
      <label className="block text-[10px] text-gray-500 mb-0.5 truncate">{label}</label>
      <input
        data-rx-field={`${eyeSide}-${String(key)}`}
        value={eye[key]}
        onChange={(e) => onPatch({ [key]: e.target.value } as Partial<RxEye>)}
        className="w-full px-1.5 py-1 text-xs border border-gray-200 rounded focus:ring-1 focus:ring-blue-500"
        placeholder={ph}
      />
    </div>
  );

  return (
    <div className="rounded-lg border border-gray-100 bg-gray-50/90 p-2">
      <p className="text-xs font-bold text-gray-800 mb-1">{title}</p>
      <p className="text-[10px] text-gray-500 leading-snug mb-2">
        球镜、矫正视力、瞳距必填；柱镜可不填；填了柱镜则轴位必填。ADD 选填。
      </p>
      <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
        {row('ds', '球镜 (DS) · 必填', '如 -6.00')}
        {row('dc', '柱镜 (DC) · 选填', '可不填')}
        {row('axis', '轴位 (°)', '有柱镜时必填')}
        {row('va', '矫正视力 · 必填', '如 1.0')}
        {row('pd', '瞳距 (mm) · 必填', '如 32')}
        {row('add', '下加 (ADD) · 选填', '如 +1.50')}
      </div>
    </div>
  );
}

export default function CashierPage() {
  const { profile, session, hasPermission, loading: authLoading } = useAuth();
  const [products, setProducts] = useState<Product[]>([]);
  const [stores, setStores] = useState<Store[]>([]);
  const [selectedStore, setSelectedStore] = useState<string>('');
  const [cart, setCart] = useState<CartItem[]>([]);
  const [dataLoading, setDataLoading] = useState(true);
  const [showReceipt, setShowReceipt] = useState(false);
  const [lastOrder, setLastOrder] = useState<LastOrder | null>(null);
  const [customerName, setCustomerName] = useState('');
  const [customerPhone, setCustomerPhone] = useState('');
  const [draftLoaded, setDraftLoaded] = useState(false);
  const [queryKeyword, setQueryKeyword] = useState('');
  const [queryRows, setQueryRows] = useState<QuerySale[]>([]);
  const [querying, setQuerying] = useState(false);
  const [queryStatus, setQueryStatus] = useState<string>('全部');
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('cash');
  const [paying, setPaying] = useState(false);
  const [checkoutSubmitting, setCheckoutSubmitting] = useState(false);
  const [rxEditorLineId, setRxEditorLineId] = useState<string | null>(null);
  const [rxFocusTarget, setRxFocusTarget] = useState<{
    lineId: string;
    side: 'right' | 'left';
    field: keyof RxEye;
  } | null>(null);
  const [rxPhotoFileName, setRxPhotoFileName] = useState('');
  const [rxRecognizing, setRxRecognizing] = useState(false);
  const [showScanModal, setShowScanModal] = useState(false);
  const [showMeituanVerifyModal, setShowMeituanVerifyModal] = useState(false);
  const [meituanScanning, setMeituanScanning] = useState(false);
  const [meituanVerifySubmitting, setMeituanVerifySubmitting] = useState(false);
  const [meituanDetectedCode, setMeituanDetectedCode] = useState('');
  const [scanCode, setScanCode] = useState('');
  /** 美团/抖音：团购券码，主界面与扫码弹窗共用 */
  const [meituanVoucher, setMeituanVoucher] = useState('');
  const [refundTarget, setRefundTarget] = useState<QuerySale | null>(null);
  const [refundReasonInput, setRefundReasonInput] = useState('');
  const [refundSaving, setRefundSaving] = useState(false);
  const draftSaveTimerRef = useRef<number | null>(null);
  const meituanVideoRef = useRef<HTMLVideoElement>(null);
  const meituanScanTimerRef = useRef<number | null>(null);
  const meituanStreamRef = useRef<MediaStream | null>(null);
  const scanCodeInputRef = useRef<HTMLInputElement>(null);
  const customerSectionRef = useRef<HTMLDivElement>(null);
  const guestNameInputRef = useRef<HTMLInputElement>(null);
  const guestPhoneInputRef = useRef<HTMLInputElement>(null);
  /** 点过结算但客人信息未填时，高亮并滚动到客人区域 */
  const [guestHighlight, setGuestHighlight] = useState(false);
  const [customComboSummary, setCustomComboSummary] = useState('');
  const [customComboFrame, setCustomComboFrame] = useState('');
  const [customComboLens, setCustomComboLens] = useState('');
  const [customComboPrice, setCustomComboPrice] = useState('');
  const [customComboError, setCustomComboError] = useState<string | null>(null);
  const [productQuickCategory, setProductQuickCategory] = useState<ProductQuickCategory>('all');
  const [guestInfoError, setGuestInfoError] = useState<string | null>(null);
  /** 购物车「改价」输入中的字符串，失焦后再写入 overrideUnitPrice，避免受控 number 吞掉「12.」等中间态 */
  const [unitPriceDraftByLine, setUnitPriceDraftByLine] = useState<Record<string, string>>({});
  const [pendingBills, setPendingBills] = useState<PendingBill[]>([]);
  const [showPendingModal, setShowPendingModal] = useState(false);
  const [orderLookupOpen, setOrderLookupOpen] = useState(false);
  const [orderLookupTitle, setOrderLookupTitle] = useState('');
  const [orderLookupBody, setOrderLookupBody] = useState('');
  const [orderLookupLoading, setOrderLookupLoading] = useState(false);
  const orderScanBufRef = useRef('');
  const orderScanLastTsRef = useRef(0);

  const allowSalesEdit = hasPermission('sales.edit');
  const navigate = useAppNavigate();
  const selectedStoreId = isUuid(selectedStore) ? selectedStore : '';
  const localBypassMode =
    process.env.NEXT_PUBLIC_LOCAL_DEMO_MODE === 'true' && (profile?.user_id === 'local-dev-user' || !session?.user?.id);
  const disableAuthMode = process.env.NEXT_PUBLIC_DISABLE_AUTH === 'true' || profile?.user_id === 'local-dev-user';

  async function fetchData() {
    setDataLoading(true);
    try {
      // 在禁用认证模式下，初始化默认数据
      if (disableAuthMode) {
        // 创建默认门店
        const defaultStoreId = crypto.randomUUID();
        const defaultStore = { id: defaultStoreId, name: '镜售总店' };
        setStores([defaultStore as Store]);
        setSelectedStore(defaultStoreId);

        // 创建一些示例产品
        const sampleProducts: Product[] = [
          { id: crypto.randomUUID(), name: '防蓝光镜片', price: 299, stock: 100, category: '镜片' },
          { id: crypto.randomUUID(), name: '金属镜架', price: 399, stock: 50, category: '镜架' },
          { id: crypto.randomUUID(), name: '隐形眼镜', price: 199, stock: 200, category: '隐形眼镜' },
        ];
        setProducts(sampleProducts);

        setDataLoading(false);
        return;
      }

      // 从本地缓存获取数据
      const [productsData, storesData] = await Promise.all([
        localCache.getProducts(),
        localCache.getStores()
      ]);

      if (productsData) setProducts(productsData as Product[]);
      if (storesData) {
        let normalizedStores = (storesData as Store[]).filter((s) => isUuid(String(s.id)));

        // 自愈：owner 首次上线且无门店时，尝试自动创建默认门店并重载。
        if (normalizedStores.length === 0 && profile?.role === 'owner' && isSupabaseConfigured) {
          const { error: createStoreError } = await supabase.from('stores').insert({ name: '镜售总店' });
          if (createStoreError) {
            console.warn('[cashier] auto create store:', createStoreError.message);
          } else {
            // 重新从云端获取门店数据
            const { data: reloadedStores, error: reloadStoresError } = await supabase
              .from('stores')
              .select('id,name');
            if (reloadStoresError) {
              console.warn('[cashier] stores reload after create:', reloadStoresError.message);
            } else {
              normalizedStores = ((reloadedStores ?? []) as Store[]).filter((s) => isUuid(String(s.id)));
              // 更新本地缓存
              if (normalizedStores.length > 0) {
                await localCache.set('stores:all', normalizedStores);
              }
            }
          }
        }

        setStores(normalizedStores);
        if (normalizedStores.length > 0) {
          setSelectedStore((prev) => {
            const firstId = normalizedStores[0].id;
            if (!isUuid(firstId)) return '';
            if (isUuid(prev) && normalizedStores.some((s) => s.id === prev)) return prev;
            return firstId;
          });
        } else {
          setSelectedStore('');
        }
      }

      // 后台同步数据
      if (isSupabaseConfigured) {
        localCache.syncFromCloud().catch((error) => {
          console.warn('[cashier] syncFromCloud:', error);
        });
      }
    } catch (e) {
      console.warn('[cashier] fetchData:', e);
    } finally {
      setDataLoading(false);
    }
  }

  useEffect(() => {
    fetchData();
  }, [profile?.user_id]);

  useEffect(() => {
    if (typeof window === 'undefined') return;
    try {
      const raw = window.localStorage.getItem(PENDING_BILLS_KEY);
      if (!raw) return;
      const parsed = JSON.parse(raw) as PendingBill[];
      if (Array.isArray(parsed)) setPendingBills(parsed);
    } catch {
      // ignore
    }
  }, []);

  useEffect(() => {
    if (typeof window === 'undefined') return;
    try {
      window.localStorage.setItem(PENDING_BILLS_KEY, JSON.stringify(pendingBills));
    } catch {
      // ignore quota
    }
  }, [pendingBills]);

  useEffect(() => {
    if (typeof window === 'undefined') return;
    try {
      const raw = window.localStorage.getItem(CASHIER_DRAFT_KEY);
      if (!raw) return;
      const draft = JSON.parse(raw) as Partial<CashierDraft>;
      if (draft.selectedStore && isUuid(draft.selectedStore)) setSelectedStore(draft.selectedStore);
      if (typeof draft.customerName === 'string') setCustomerName(draft.customerName);
      if (typeof draft.customerPhone === 'string') setCustomerPhone(draft.customerPhone);
      if (Array.isArray(draft.cart)) {
        setUnitPriceDraftByLine({});
        setCart(filterOutLegacyQuickSaleLines(draft.cart as CartItem[]).map(normalizeCartRx));
      }
    } catch {
      // ignore malformed local draft
    } finally {
      setDraftLoaded(true);
    }
  }, []);

  useEffect(() => {
    if (typeof window === 'undefined' || !draftLoaded) return;
    if (draftSaveTimerRef.current) {
      window.clearTimeout(draftSaveTimerRef.current);
    }
    // 防抖落盘：避免每次点击/输入都同步写 localStorage 造成卡顿
    draftSaveTimerRef.current = window.setTimeout(() => {
      const payload: CashierDraft = {
        selectedStore,
        customerName,
        customerPhone,
        cart,
      };
      window.localStorage.setItem(CASHIER_DRAFT_KEY, JSON.stringify(payload));
      draftSaveTimerRef.current = null;
    }, 280);

    return () => {
      if (draftSaveTimerRef.current) {
        window.clearTimeout(draftSaveTimerRef.current);
      }
    };
  }, [selectedStore, customerName, customerPhone, cart, draftLoaded]);

  const handleOrderQrScan = useCallback(async (raw: string) => {
    const parsed = parseOrderQrPayload(raw);
    if (!parsed) return;
    setOrderLookupOpen(true);
    setOrderLookupLoading(true);
    setOrderLookupTitle('正在查询订单…');
    setOrderLookupBody('');
    try {
      const { data, error } = await supabase
        .from('sales')
        .select(
          'id,sale_no,sale_status,quantity,total_price,product_category,products(name)',
        )
        .eq('sale_no', parsed.saleNo)
        .order('created_at', { ascending: true });
      if (error) throw error;
      const rows = (data ?? []) as OrderLookupRow[];
      if (rows.length === 0) {
        setOrderLookupTitle('未找到订单');
        setOrderLookupBody(
          `单据号「${parsed.saleNo}」无销售记录，请核对小票或稍后在报表中查询。`,
        );
        return;
      }
      const idOk = rows.some((r) => r.id === parsed.primarySaleId);
      const statusLabels = [...new Set(rows.map((r) => (r.sale_status || '—').trim()))];
      const statusSummary = statusLabels.length === 1 ? statusLabels[0] : statusLabels.join(' · ');
      const lines: string[] = [
        `单据号：${parsed.saleNo}`,
        idOk ? '二维码校验：已匹配本单' : '提示：二维码内行 ID 与当前数据不完全一致，仍以单据号为准。',
        `加工状态汇总：${statusSummary}`,
        '',
        '—— 明细 ——',
        ...rows.map((r, i) => {
          const name = r.products?.name?.trim() || r.product_category || '—';
          const st = (r.sale_status || '—').trim();
          return `${i + 1}. ${name}  ×${r.quantity}  ｜ ${st}`;
        }),
      ];
      setOrderLookupTitle('取镜查询 · 加工状态');
      setOrderLookupBody(lines.join('\n'));
    } catch (e) {
      const msg = e instanceof Error ? e.message : String(e);
      setOrderLookupTitle('查询失败');
      setOrderLookupBody(toChineseErrorMessage(msg));
    } finally {
      setOrderLookupLoading(false);
    }
  }, []);

  /**
   * Electron：捕获阶段识别取镜二维码载荷。
   * 普通输入框（验光、客人信息等）内必须跳过，否则会污染缓冲、表现为报错后无法再输入度数等。
   * 仅「先扫付款码」弹窗内的付款码输入框继续走本逻辑，供扫码枪楔入。
   */
  useEffect(() => {
    if (typeof window === 'undefined') return;
    if (!window.electronApp?.isDesktop) return;
    const GAP_MS = 55;
    const prefix = `${ORDER_QR_MAGIC}|`;
    const onCap = (e: KeyboardEvent) => {
      if (e.ctrlKey || e.metaKey || e.altKey) return;
      const rawTarget = e.target;
      if (rawTarget instanceof HTMLElement && rawTarget.isContentEditable) return;
      if (rawTarget instanceof Node) {
        const el = rawTarget instanceof Element ? rawTarget : rawTarget.parentElement;
        if (el?.closest('[data-rx-editor]')) return;
      }
      if (
        rawTarget instanceof HTMLInputElement ||
        rawTarget instanceof HTMLTextAreaElement ||
        rawTarget instanceof HTMLSelectElement
      ) {
        if (rawTarget !== scanCodeInputRef.current) return;
      }
      const now = Date.now();
      if (e.key === 'Enter') {
        const line = orderScanBufRef.current;
        orderScanBufRef.current = '';
        orderScanLastTsRef.current = 0;
        if (line.startsWith(prefix)) {
          e.preventDefault();
          e.stopPropagation();
          void handleOrderQrScan(line);
        }
        return;
      }
      if (now - orderScanLastTsRef.current > GAP_MS) orderScanBufRef.current = '';
      orderScanLastTsRef.current = now;
      if (e.key.length === 1) orderScanBufRef.current += e.key;
    };
    document.addEventListener('keydown', onCap, true);
    return () => document.removeEventListener('keydown', onCap, true);
  }, [handleOrderQrScan]);

  const addToCart = useCallback((product: Product) => {
    const promoOk = product.allow_promo_price !== false;
    const promo =
      product.is_promo && promoOk && product.promo_price != null
        ? Number(product.promo_price)
        : null;
    const usePromo = promo !== null && Number.isFinite(promo) && promo >= 0;
    const lineId = crypto.randomUUID();
    setCart((prev) => [
      ...prev,
      {
        ...product,
        lineId,
        quantity: 1,
        rx: { right: emptyEye(), left: emptyEye() },
        discountPercent: 0,
        overrideUnitPrice: usePromo ? promo : null,
      },
    ]);
    if (isLensProduct(product)) {
      setRxEditorLineId(lineId);
      setRxFocusTarget(null);
      setRxPhotoFileName('');
      setRxRecognizing(false);
    }
  }, []);

  const removeFromCart = (lineId: string) => {
    setCart((prev) => prev.filter((item) => item.lineId !== lineId));
    setUnitPriceDraftByLine((p) => {
      if (!(lineId in p)) return p;
      const next = { ...p };
      delete next[lineId];
      return next;
    });
  };

  const updateQuantity = (lineId: string, delta: number) => {
    setCart((prev) =>
      prev.map((item) => {
        if (item.lineId !== lineId) return item;
        const targetQty = item.quantity + delta;
        const maxQty =
          isCustomComboLine(item) ||
          !Number.isFinite(item.stock) ||
          item.stock <= 0
            ? targetQty
            : item.stock;
        const newQty = Math.max(1, Math.min(maxQty, targetQty));
        return { ...item, quantity: newQty };
      }),
    );
  };

  const patchRx = (lineId: string, side: 'right' | 'left', patch: Partial<RxEye>) => {
    setCart((prev) =>
      prev.map((item) => {
        if (item.lineId !== lineId) return item;
        const eye = item.rx[side];
        return {
          ...item,
          rx: {
            ...item.rx,
            [side]: { ...eye, ...patch },
          },
        };
      }),
    );
  };

  const applyRxFromOcr = useCallback(
    (lineId: string, side: 'right' | 'left', payload: Record<string, unknown>) => {
      patchRx(lineId, side, {
        ds: typeof payload.ds === 'string' ? payload.ds : '',
        dc: typeof payload.dc === 'string' ? payload.dc : '',
        axis: typeof payload.axis === 'string' ? payload.axis : '',
        va: typeof payload.va === 'string' ? payload.va : '',
        pd: typeof payload.pd === 'string' ? payload.pd : '',
        add: typeof payload.add === 'string' ? payload.add : '',
      });
    },
    [],
  );

  const patchDiscount = (lineId: string, discountPercent: number) => {
    setCart((prev) =>
      prev.map((item) => {
        if (item.lineId !== lineId) return item;
        if (item.allow_discount === false) return item;
        return { ...item, discountPercent: Math.min(100, Math.max(0, discountPercent || 0)) };
      }),
    );
  };

  const addCustomComboLine = () => {
    setCustomComboError(null);
    
    const amount = Number(customComboPrice);
    if (!Number.isFinite(amount) || amount <= 0) {
      setCustomComboError('请输入正确的成套价格');
      return;
    }
    const frame = customComboFrame.trim();
    const lens = customComboLens.trim();
    if (!frame || !lens) {
      setCustomComboError('请填写镜框属性与镜片属性（可手写品牌、型号、折射率等）');
      return;
    }
    const summary = customComboSummary.trim();
    const title = summary ? `自主配镜 · ${summary}` : '自主配镜';
    const line: CartItem = {
      id: '',
      name: title,
      price: amount,
      stock: 999999,
      category: CUSTOM_COMBO_CATEGORY,
      brand: null,
      model: summary || null,
      frame_type: frame,
      lens_type: lens,
      lineId: crypto.randomUUID(),
      quantity: 1,
      rx: { right: emptyEye(), left: emptyEye() },
      discountPercent: 0,
      overrideUnitPrice: null,
      isCustomCombo: true,
      allow_discount: true,
      allow_points: true,
    };
    setCart((prev) => [...prev, line]);
    setRxEditorLineId(line.lineId);
    setRxFocusTarget(null);
    setRxPhotoFileName('');
    setRxRecognizing(false);
    setCustomComboSummary('');
    setCustomComboFrame('');
    setCustomComboLens('');
    setCustomComboPrice('');
  };

  const savePendingBill = () => {
    if (cart.length === 0) {
      window.alert('购物车为空，无需挂单');
      return;
    }
    const note = window.prompt('挂单备注（可选，例如：客人暂离、先去验光）', '') ?? '';
    const bill: PendingBill = {
      id: crypto.randomUUID(),
      createdAt: new Date().toISOString(),
      note: note.trim(),
      draft: {
        selectedStore,
        customerName,
        customerPhone,
        cart: cart.map((c) => ({ ...c })),
      },
    };
    setPendingBills((p) => [bill, ...p]);
    setCart([]);
    setUnitPriceDraftByLine({});
    setCustomerName('');
    setCustomerPhone('');
    window.alert('已挂单。可从「取单」恢复本单。');
  };

  const restorePendingBill = (bill: PendingBill) => {
    if (cart.length > 0) {
      const ok = window.confirm('当前购物车有商品，取回挂单将替换当前购物车与客人信息，是否继续？');
      if (!ok) return;
    }
    setSelectedStore(bill.draft.selectedStore);
    setCustomerName(bill.draft.customerName);
    setCustomerPhone(bill.draft.customerPhone);
    setUnitPriceDraftByLine({});
    setCart(filterOutLegacyQuickSaleLines(bill.draft.cart as CartItem[]).map(normalizeCartRx));
    setPendingBills((p) => p.filter((x) => x.id !== bill.id));
    setShowPendingModal(false);
  };

  const removePendingBill = (id: string) => {
    setPendingBills((p) => p.filter((x) => x.id !== id));
  };

  const patchOwnerPrice = (lineId: string, value: string) => {
    const parsed = value === '' ? null : Number(value);
    setCart((prev) =>
      prev.map((item) =>
        item.lineId === lineId
          ? { ...item, overrideUnitPrice: parsed === null || Number.isNaN(parsed) ? null : Math.max(0, parsed) }
          : item,
      ),
    );
  };

  const getFinalUnitPrice = (item: CartItem) => {
    if (typeof item.overrideUnitPrice === 'number') return item.overrideUnitPrice;
    return Number((item.price * (1 - (item.discountPercent || 0) / 100)).toFixed(2));
  };

  const total = useMemo(
    () => cart.reduce((sum, item) => sum + getFinalUnitPrice(item) * item.quantity, 0),
    [cart],
  );
  const editingRxItem = useMemo(
    () => (rxEditorLineId ? cart.find((item) => item.lineId === rxEditorLineId) ?? null : null),
    [cart, rxEditorLineId],
  );

  /** 需验光的行与未填齐数量，用于提示「填在哪」与结算前引导 */
  const rxCartSummary = useMemo(() => {
    const rxLines = cart.filter((item) => isLensProduct(item));
    const incomplete = rxLines.filter((item) => !isRxComplete(item.rx));
    return { rxLineCount: rxLines.length, incompleteCount: incomplete.length };
  }, [cart]);

  const productCards = useMemo(() => {
    const list = products.filter((product) => {
      if (productQuickCategory === 'all') return true;
      return getProductQuickCategory(product) === productQuickCategory;
    });
    if (list.length === 0) {
      return (
        <div className="col-span-full rounded-xl border border-dashed border-gray-300 bg-gray-50 p-6 text-sm text-gray-500">
          当前分类暂无可售商品
        </div>
      );
    }
    return list.map((product) => {
      const promoOk = product.allow_promo_price !== false;
      const hasPromo = product.is_promo && promoOk && product.promo_price != null && Number(product.promo_price) >= 0;
      const showPrice = hasPromo ? Number(product.promo_price) : Number(product.price);
      return (
        <button
          key={product.id}
          type="button"
          onClick={() => addToCart(product)}
          className="w-full text-left rounded-xl border p-3 transition bg-white border-gray-200 hover:border-blue-400 hover:bg-blue-50"
          style={{ touchAction: 'manipulation' }}
        >
          <div className="flex items-center justify-between gap-2">
            <span className="font-semibold truncate">{product.name}</span>
            <span className="font-bold text-blue-600 shrink-0">￥{showPrice.toFixed(2)}</span>
          </div>
          <div className="mt-1 text-xs text-gray-500">
            库存 {product.stock} · 可继续销售
          </div>
        </button>
      );
    });
  }, [products, addToCart, productQuickCategory]);

  const handleSearchCustomers = async () => {
    const keyword = queryKeyword.trim();
    if (!keyword) {
      setQueryRows([]);
      return;
    }
    if (!isSupabaseConfigured) {
      window.alert(supabaseConfigHint);
      return;
    }
    setQuerying(true);
    let q = supabase
      .from('sales')
      .select(
        `
        id,
        created_at,
        quantity,
        total_price,
        customer_name,
        customer_phone,
        sale_no,
        product_category,
        product_brand,
        product_model,
        frame_type,
        lens_type,
        sale_status,
        refund_reason,
        products (name),
        stores (name)
      `,
      )
      .or(`customer_name.ilike.%${keyword}%,customer_phone.ilike.%${keyword}%,sale_no.ilike.%${keyword}%`)
      .order('created_at', { ascending: false })
      .limit(20);
    if (queryStatus !== '全部') q = q.eq('sale_status', queryStatus);
    const { data, error } = await q;
    setQuerying(false);
    if (error) {
      window.alert('查询失败：' + toChineseErrorMessage(error.message));
      return;
    }
    setQueryRows((data ?? []) as QuerySale[]);
  };

  const reopenByCustomer = (row: QuerySale) => {
    const ok = window.confirm('将清空当前购物车，并回填该客人信息用于重开单，是否继续？');
    if (!ok) return;
    setCart([]);
    setUnitPriceDraftByLine({});
    setCustomerName((row.customer_name || '').trim());
    setCustomerPhone((row.customer_phone || '').trim());
    setPaymentMethod('cash');
  };

  const openRefundModal = (row: QuerySale) => {
    setRefundTarget(row);
    setRefundReasonInput('');
  };

  const submitRefund = async () => {
    if (!refundTarget) return;
    const reason = refundReasonInput.trim();
    if (!reason) {
      window.alert('请填写退单原因');
      return;
    }
    if (!isSupabaseConfigured) {
      window.alert(supabaseConfigHint);
      return;
    }
    setRefundSaving(true);
    const { error } = await supabase
      .from('sales')
      .update({
        sale_status: '已退单',
        refund_reason: reason,
      })
      .eq('id', refundTarget.id);
    setRefundSaving(false);
    if (error) {
      window.alert('退单失败：' + toChineseErrorMessage(error.message));
      return;
    }
    setRefundTarget(null);
    setRefundReasonInput('');
    await handleSearchCustomers();
  };

  /** alert 关闭后焦点常在 body，Electron 全局 keydown 会污染取镜码缓冲；聚焦第一个未填项并清空缓冲 */
  const focusAfterIncompleteRxAlert = useCallback((lineId: string, rx: CartItem['rx']) => {
    window.setTimeout(() => {
      orderScanBufRef.current = '';
      orderScanLastTsRef.current = 0;
      const miss = firstIncompleteRxField(rx);
      if (!miss) return;
      setRxEditorLineId(lineId);
      setRxFocusTarget({ lineId, side: miss.side, field: miss.field });
    }, 0);
  }, []);

  useEffect(() => {
    if (!rxEditorLineId) return;
    if (editingRxItem) return;
    setRxEditorLineId(null);
    setRxFocusTarget(null);
    setRxPhotoFileName('');
    setRxRecognizing(false);
  }, [editingRxItem, rxEditorLineId]);

  useEffect(() => {
    if (!rxFocusTarget) return;
    const selector = `[data-rx-editor="${rxFocusTarget.lineId}"] [data-rx-field="${rxFocusTarget.side}-${String(rxFocusTarget.field)}"]`;
    const timer = window.setTimeout(() => {
      const el = document.querySelector(selector);
      if (!(el instanceof HTMLInputElement)) return;
      el.focus();
      el.scrollIntoView({ behavior: 'smooth', block: 'center' });
      setRxFocusTarget(null);
    }, 0);
    return () => window.clearTimeout(timer);
  }, [rxFocusTarget, rxEditorLineId]);

  /** 出单前校验（购物车、门店、客人、镜片验光） */
  const assertCanCheckout = (): boolean => {
    if (!isSupabaseConfigured) {
      window.alert(supabaseConfigHint);
      return false;
    }
    if (!session?.user?.id && !localBypassMode) {
      window.alert('请先登录云端账号后再结算（当前会话无效）。');
      return false;
    }
    if (cart.length === 0) {
      window.alert('购物车为空');
      return false;
    }
    if (!selectedStoreId && !localBypassMode) {
      window.alert('请选择有效门店（门店ID异常，请重新选择后再结算）。');
      return false;
    }
    // RLS：非所有权账号必须绑定门店，且收银所选门店须与 profile.store_id 一致，否则会报「没有操作权限」
    if (profile && profile.role !== 'owner') {
      if (!profile.store_id) {
        window.alert(
          '当前账号未绑定所属门店，无法保存销售与扣库存。请管理员在「权限管理」或数据库 user_profiles 中为该账号设置 store_id 后重新登录。',
        );
        return false;
      }
      if (selectedStoreId !== profile.store_id) {
        window.alert(
          '收银台所选门店与您的所属门店不一致，云端策略会拒绝保存。请改选您的门店，或使用所有权账号操作。',
        );
        return false;
      }
    }
    if (!customerName.trim() || !customerPhone.trim()) {
      setGuestHighlight(true);
      setGuestInfoError('请填写下方「客人信息」中的姓名与联系电话，再点结算。');
      window.setTimeout(() => {
        customerSectionRef.current?.scrollIntoView({ behavior: 'smooth', block: 'center' });
      }, 0);
      window.setTimeout(() => {
        orderScanBufRef.current = '';
        orderScanLastTsRef.current = 0;
        if (!customerName.trim()) guestNameInputRef.current?.focus();
        else guestPhoneInputRef.current?.focus();
      }, 0);
      return false;
    }
    setGuestHighlight(false);
    const incomplete = cart.find((item) => isLensProduct(item) && !isRxComplete(item.rx));
    if (incomplete) {
      window.alert(
        `商品「${incomplete.name}」的屈光度数未按规则填完整。\n每只眼须填：球镜(DS)、矫正视力、瞳距(mm)。\n柱镜(DC)可不填；若填写了柱镜，则必须填写轴位。\n下加(ADD)选填。`,
      );
      focusAfterIncompleteRxAlert(incomplete.lineId, incomplete.rx);
      return false;
    }
    return true;
  };

  /**
   * 落库销售并扣库存。
   * @param skipOptionalPaymentLog 为 true 时不写 payment_transactions（已由扫码流程写入，或用户选择不记流水）
   */
  const finalizeSale = async (skipOptionalPaymentLog = false) => {
    if (!selectedStoreId && !localBypassMode && !disableAuthMode) {
      window.alert('结算失败：门店ID无效，请重新选择门店后重试。');
      return false;
    }
    if (!localBypassMode && !disableAuthMode && !stores.some((s) => s.id === selectedStoreId)) {
      window.alert('结算失败：当前门店不存在或已变更，请重新选择门店后重试。');
      return false;
    }
    const meituanVoucherSnap =
      paymentMethod === 'meituan_douyin' ? meituanVoucher.trim() : '';
    // 生成单据号：门店 + 日期 + 当天序号（同一笔结算写入多条销售明细，sale_no 相同）
    const now = new Date();
    const yyyy = now.getFullYear();
    const mm = String(now.getMonth() + 1).padStart(2, '0');
    const dd = String(now.getDate()).padStart(2, '0');
    const ymd = `${yyyy}${mm}${dd}`;
    const storeCode = String(selectedStoreId).replace(/-/g, '').slice(0, 4).toUpperCase();
    const dayStart = new Date(yyyy, now.getMonth(), now.getDate(), 0, 0, 0);
    const dayEnd = new Date(yyyy, now.getMonth(), now.getDate() + 1, 0, 0, 0);
    const localSaleNo = `${storeCode || 'LOCAL'}-${ymd}-${String(Date.now()).slice(-4)}`;
    const saleStatus: SaleStatus = cart.some((item) => isLensProduct(item)) ? '待加工' : '已完成';

    if (localBypassMode || disableAuthMode) {
      const primarySaleId = crypto.randomUUID();
      const orderQrPayload = buildOrderQrPayload(localSaleNo, primarySaleId);
      const settledOrderObject: PrintOrder = {
        order_no: localSaleNo,
        created_at: new Date().toISOString(),
        store_name: resolveStoreDisplayName(stores.find((s) => s.id === selectedStoreId)?.name),
        customer_name: customerName.trim(),
        customer_phone: customerPhone.trim(),
        payment_method: paymentMethod,
        meituan_voucher: paymentMethod === 'meituan_douyin' ? meituanVoucherSnap : '',
        total_amount: total,
        items: cart.map((item) => ({
          name: item.name,
          quantity: item.quantity,
          unit_price: getFinalUnitPrice(item),
          line_total: getFinalUnitPrice(item) * item.quantity,
          rx: isLensProduct(item) ? item.rx : null,
        })),
      };
      setLastOrder({
        store: stores.find((s) => s.id === selectedStoreId)?.name,
        customer: { name: customerName.trim(), phone: customerPhone.trim() },
        items: [...cart],
        total,
        time: new Date().toLocaleString(),
        saleNo: localSaleNo,
        primarySaleId,
        orderQrPayload,
        paymentMethod,
        meituanVoucher: paymentMethod === 'meituan_douyin' ? meituanVoucherSnap : undefined,
        orderObject: settledOrderObject,
      });
      setCart([]);
      setUnitPriceDraftByLine({});
      setCustomerName('');
      setCustomerPhone('');
      setMeituanVoucher('');
      if (typeof window !== 'undefined') window.localStorage.removeItem(CASHIER_DRAFT_KEY);
      
      // 立即调用打印功能
      setTimeout(async () => {
        try {
          await printReceiptWithElectronPreference(settledOrderObject);
        } catch (e) {
          console.error('自动打印失败:', e);
        }
      }, 100);
      
      return true;
    }

    if (!isSupabaseConfigured) {
      window.alert(supabaseConfigHint);
      return false;
    }

    let maxSeq = 0;
    let saleNoError = null;
    
    // 尝试从云端获取销售数据
    try {
      const { data: existingSales, error } = await supabase
        .from('sales')
        .select('sale_no,created_at')
        .eq('store_id', selectedStoreId)
        .gte('created_at', dayStart.toISOString())
        .lt('created_at', dayEnd.toISOString())
        .order('created_at', { ascending: false })
        .limit(1000);
      
      saleNoError = error;
      
      if (existingSales) {
        for (const row of existingSales) {
          const sn = row.sale_no || '';
          const m = sn.match(/(\d+)\s*$/);
          const seq = m ? Number(m[1]) : 0;
          if (Number.isFinite(seq) && seq > maxSeq) maxSeq = seq;
        }
      }
    } catch (error) {
      console.warn('查询云端销售数据失败，使用本地单号生成:', error);
    }

    const saleNo = `${storeCode}-${ymd}-${String(maxSeq + 1).padStart(4, '0')}`;

    // 1) 先按“商品id汇总”扣减库存：不再做库存拦截，可扣为负数
    const qtyByProductId = new Map<string, number>();
    for (const item of cart) {
      if (!isUuid(item.id)) continue;
      qtyByProductId.set(item.id, (qtyByProductId.get(item.id) || 0) + item.quantity);
    }

    const productIds = Array.from(qtyByProductId.keys());
    
    // 从本地缓存获取库存数据
    const productsData = await localCache.getProducts();
    const stockMap = new Map<string, number>();
    for (const product of productsData) {
      if (productIds.includes(product.id)) {
        stockMap.set(product.id, product.stock || 0);
      }
    }

    // 如果本地缓存没有数据，尝试从云端获取
    if (stockMap.size === 0 && isSupabaseConfigured) {
      const { data: stockRows, error: stockError } = await supabase
        .from('products')
        .select('id,stock')
        .in('id', productIds);

      if (stockError) {
        window.alert('库存检查失败：' + toChineseErrorMessage(stockError.message));
        return false;
      }

      for (const row of stockRows ?? []) stockMap.set(row.id, row.stock);
    }

    const revertStocks = new Map<string, number>(stockMap);
    const stockDecrementResults = await Promise.all(
      productIds.map(async (id) => {
        const prev = revertStocks.get(id) ?? 0;
        const next = prev - (qtyByProductId.get(id) || 0);
        return supabase.from('products').update({ stock: next }).eq('id', id);
      }),
    );
    const decrementErr = stockDecrementResults.find((r) => r.error)?.error;
    if (decrementErr) {
      window.alert('扣减库存失败：' + toChineseErrorMessage(decrementErr.message));
      return false;
    }

    // 2) 落库销售明细：处方只给“镜片商品”；自主配镜等非 UUID 行 product_id 为空
    const salesData = cart.map((item) => ({
      product_id: isUuid(item.id) ? item.id : null,
      store_id: selectedStoreId,
      sale_no: saleNo,
      sale_status: saleStatus,
      quantity: item.quantity,
      total_price: getFinalUnitPrice(item) * item.quantity,
      original_unit_price: item.price,
      final_unit_price: getFinalUnitPrice(item),
      discount_percent: item.discountPercent || 0,
      prescription: isLensProduct(item) ? item.rx : null,
      customer_name: customerName.trim(),
      customer_phone: customerPhone.trim(),
      product_category: isCustomComboLine(item)
        ? CUSTOM_COMBO_CATEGORY
        : item.category?.trim() || null,
      product_brand: isCustomComboLine(item) ? null : item.brand?.trim() || null,
      product_model: isCustomComboLine(item)
        ? item.model?.trim() || item.name.trim() || '自主配镜'
        : item.model?.trim() || null,
      frame_type: item.frame_type?.trim() || null,
      lens_type: item.lens_type?.trim() || null,
    }));

    // 保存到本地缓存
    for (const saleData of salesData) {
      await localCache.saveSale(saleData);
    }

    // 尝试写入云端
    let insertedSales = null;
    if (isSupabaseConfigured) {
      const { data, error } = await supabase.from('sales').insert(salesData).select('id');
      if (error) {
        console.warn('写入销售单到云端失败：', error.message);
        // 即使云端写入失败，也继续执行，因为数据已经保存在本地
      } else {
        insertedSales = data;
      }
    }

    // 生成本地ID作为备用
    let primarySaleId = insertedSales?.[0]?.id as string | undefined;
    if (!primarySaleId) {
      primarySaleId = crypto.randomUUID();
    }
    const orderQrPayload = buildOrderQrPayload(saleNo, primarySaleId);

    // 微信/支付宝：出单成功后尽力记一笔流水（与真实通道无关，便于对账；失败不阻卖出）
    if (!skipOptionalPaymentLog && paymentMethod !== 'cash') {
      const { error: payErr } = await supabase.from('payment_transactions').insert({
        store_id: selectedStoreId,
        channel: paymentMethod,
        amount: total,
        status: 'paid',
        customer_name: customerName.trim(),
        customer_phone: customerPhone.trim(),
        cart_snapshot: cart,
        external_txn_no: `${saleNo}-${paymentMethod}`,
        paid_at: new Date().toISOString(),
      });
      if (payErr) {
        console.warn('[cashier] payment_transactions:', payErr.message);
      }
    }

    const settledOrderObject: PrintOrder = {
      order_no: saleNo,
      created_at: new Date().toISOString(),
      store_name: resolveStoreDisplayName(stores.find((s) => s.id === selectedStoreId)?.name),
      customer_name: customerName.trim(),
      customer_phone: customerPhone.trim(),
      payment_method: paymentMethod,
      meituan_voucher: paymentMethod === 'meituan_douyin' ? meituanVoucherSnap : '',
      total_amount: total,
      items: cart.map((item) => ({
        name: item.name,
        quantity: item.quantity,
        unit_price: getFinalUnitPrice(item),
        line_total: getFinalUnitPrice(item) * item.quantity,
        rx: isLensProduct(item) ? item.rx : null,
      })),
    };

    setLastOrder({
      store: stores.find((s) => s.id === selectedStoreId)?.name,
      customer: { name: customerName.trim(), phone: customerPhone.trim() },
      items: [...cart],
      total,
      time: new Date().toLocaleString(),
      saleNo,
      primarySaleId,
      orderQrPayload,
      paymentMethod,
      meituanVoucher: paymentMethod === 'meituan_douyin' ? meituanVoucherSnap : undefined,
      orderObject: settledOrderObject,
    });
    setCart([]);
    setUnitPriceDraftByLine({});
    setCustomerName('');
    setCustomerPhone('');
    setMeituanVoucher('');
    if (typeof window !== 'undefined') window.localStorage.removeItem(CASHIER_DRAFT_KEY);
    fetchData();
    
    // 立即调用打印功能
    setTimeout(async () => {
      try {
        await printReceiptWithElectronPreference(settledOrderObject);
      } catch (e) {
        console.error('自动打印失败:', e);
      }
    }, 100);
    
    return true;
  };

  const handleCheckout = async () => {
    if (!assertCanCheckout()) return;
    if (checkoutSubmitting) return;
    setCheckoutSubmitting(true);
    try {
      await finalizeSale(false);
    } finally {
      setCheckoutSubmitting(false);
    }
  };

  const stopMeituanScanner = useCallback(() => {
    if (meituanScanTimerRef.current) {
      window.clearInterval(meituanScanTimerRef.current);
      meituanScanTimerRef.current = null;
    }
    if (meituanStreamRef.current) {
      for (const track of meituanStreamRef.current.getTracks()) track.stop();
      meituanStreamRef.current = null;
    }
    setMeituanScanning(false);
  }, []);

  const submitMeituanVerify = useCallback(
    async (voucherCode: string) => {
      const code = voucherCode.trim();
      if (!code) return;
      if (!selectedStoreId) {
        window.alert('请先选择门店后再进行美团核销。');
        return;
      }
      if (meituanVerifySubmitting) return;
      setMeituanVerifySubmitting(true);
      try {
        const resp = await fetch('/api/meituan/verify', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            voucherCode: code,
            storeId: selectedStoreId,
            amount: total,
            customerName: customerName.trim(),
            customerPhone: customerPhone.trim(),
          }),
        });
        const json = (await resp.json()) as { ok?: boolean; error?: string; message?: string };
        if (!resp.ok || !json.ok) {
          window.alert(`核销失败：${toChineseErrorMessage(String(json.error ?? `HTTP ${resp.status}`))}`);
          return;
        }
        setMeituanVoucher(code);
        setPaymentMethod('meituan_douyin');
        window.alert(json.message || '核销成功');
        setShowMeituanVerifyModal(false);
        stopMeituanScanner();
      } catch (e) {
        const msg = e instanceof Error ? e.message : String(e);
        window.alert(`核销失败：${toChineseErrorMessage(msg)}`);
      } finally {
        setMeituanVerifySubmitting(false);
      }
    },
    [customerName, customerPhone, meituanVerifySubmitting, selectedStoreId, stopMeituanScanner, total],
  );

  const openMeituanVerifyModal = useCallback(async () => {
    setShowMeituanVerifyModal(true);
    setMeituanDetectedCode('');
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: { ideal: 'environment' } },
        audio: false,
      });
      meituanStreamRef.current = stream;
      const videoEl = meituanVideoRef.current;
      if (videoEl) {
        videoEl.srcObject = stream;
        await videoEl.play();
      }
      setMeituanScanning(true);

      type BarcodeResult = { rawValue?: string };
      type BarcodeDetectorInstance = { detect: (input: HTMLVideoElement) => Promise<BarcodeResult[]> };
      type BarcodeDetectorCtor = new (opts: { formats: string[] }) => BarcodeDetectorInstance;
      const Detector = (window as unknown as { BarcodeDetector?: BarcodeDetectorCtor }).BarcodeDetector;
      if (Detector) {
        const detector = new Detector({ formats: ['qr_code', 'ean_13', 'code_128'] });
        meituanScanTimerRef.current = window.setInterval(async () => {
          if (meituanVerifySubmitting) return;
          const el = meituanVideoRef.current;
          if (!el) return;
          try {
            const found = await detector.detect(el);
            const value = String(found?.[0]?.rawValue ?? '').trim();
            if (!value) return;
            setMeituanDetectedCode(value);
            await submitMeituanVerify(value);
          } catch {
            // ignore detect frame errors
          }
        }, 500);
      }
    } catch (e) {
      const msg = e instanceof Error ? e.message : String(e);
      setMeituanScanning(false);
      window.alert(`无法打开摄像头：${toChineseErrorMessage(msg)}\n可在弹窗中手工输入券码核销。`);
    }
  }, [meituanVerifySubmitting, submitMeituanVerify]);

  /** 需要先扫顾客付款码并把码写入流水时再打开弹窗（与「确认结算」一键出单分离） */
  const openScanPayModal = () => {
    if (checkoutSubmitting || paying) return;
    if (!assertCanCheckout()) return;
    if (paymentMethod !== 'meituan_douyin') setScanCode('');
    setShowScanModal(true);
  };

  const handleScanPay = async () => {
    if (!scanCode.trim() && paymentMethod !== 'meituan_douyin') {
      window.alert('请用扫码枪扫描顾客付款码，或点击「线下已收款，直接完成订单」。');
      scanCodeInputRef.current?.focus();
      return;
    }
    const extNo =
      (paymentMethod === 'meituan_douyin' ? meituanVoucher.trim() : scanCode.trim()) ||
      (paymentMethod === 'meituan_douyin' ? `meituan-douyin-manual-${Date.now()}` : '');
    setPaying(true);
    let insertError: { message: string } | null = null;
    try {
      const { error } = await supabase.from('payment_transactions').insert({
        store_id: selectedStoreId,
        channel: paymentMethod,
        amount: total,
        status: 'paid',
        customer_name: customerName,
        customer_phone: customerPhone,
        cart_snapshot: cart,
        external_txn_no: extNo,
        paid_at: new Date().toISOString(),
      });
      insertError = error;
    } finally {
      setPaying(false);
    }
    if (insertError) {
      const raw = insertError.message || '';
      const hint =
        /permission|policy|row level|RLS|42501|violates/i.test(raw) || /权限|策略/i.test(raw)
          ? '\n\n提示：请确认账号所属门店与收银台所选门店一致；或未执行 payment_transactions 相关迁移。也可使用下方「线下已收款」直接完成销售。'
          : '';
      window.alert('收款流水记账失败：' + toChineseErrorMessage(raw) + hint);
      orderScanBufRef.current = '';
      orderScanLastTsRef.current = 0;
      setShowScanModal(false);
      setScanCode('');
      return;
    }
    setCheckoutSubmitting(true);
    try {
      const ok = await finalizeSale(true);
      if (ok) {
        setShowScanModal(false);
        setScanCode('');
      }
    } finally {
      setCheckoutSubmitting(false);
    }
  };

  /** 弹窗内：已线下收款，不重复记流水，直接出单 */
  const completeSaleSkipPaymentLog = async () => {
    const ok = window.confirm(
      '确认顾客已完成付款（现金、刷卡或其他方式）？\n将直接生成销售单；若刚才未扫付款码，则本笔不会另记支付流水。',
    );
    if (!ok) return;
    if (checkoutSubmitting) return;
    setCheckoutSubmitting(true);
    try {
      const done = await finalizeSale(true);
      if (done) {
        setShowScanModal(false);
        setScanCode('');
      }
    } finally {
      setCheckoutSubmitting(false);
    }
  };

  const resetByFixedTemplate = () => {
    const ok = window.confirm('将按固定模板清空当前单据，所有信息需要重选，是否继续？');
    if (!ok) return;
    setSelectedStore('');
    setCustomerName('');
    setCustomerPhone('');
    setCart([]);
    setUnitPriceDraftByLine({});
    setPaymentMethod('cash');
    setQueryKeyword('');
    setQueryRows([]);
    setShowScanModal(false);
    setScanCode('');
    setMeituanVoucher('');
    setCustomComboSummary('');
    setCustomComboFrame('');
    setCustomComboLens('');
    setCustomComboPrice('');
    if (typeof window !== 'undefined') window.localStorage.removeItem(CASHIER_DRAFT_KEY);
  };

  if (authLoading) {
    return (
      <div className="flex justify-center items-center h-64 text-gray-600">正在加载账号与权限…</div>
    );
  }
  if (!hasPermission('cashier.view')) {
    const roleLabel = profile?.role ? roleNameMap[profile.role] : '未识别';
    return (
      <div className="max-w-lg mx-auto rounded-2xl border border-amber-200 bg-amber-50/90 p-6 text-sm text-amber-950 space-y-3">
        <h2 className="text-lg font-bold text-amber-900">无法使用收银台</h2>
        <p>
          当前登录角色为「{roleLabel}」，账号未开通收银台权限（<code className="text-xs bg-white/80 px-1 rounded">cashier.view</code>
          ）。
        </p>
        <p className="text-xs text-amber-800/90">
          若侧栏菜单中看不到「收银台」，可在侧栏菜单设置中勾选显示；若入口可见但仍提示无权限，请按下方说明开通 <code className="text-[11px]">cashier.view</code>。
        </p>
        <p className="text-xs text-amber-800/90">
          若使用库存等角色需要进入收银台，请管理员在「权限管理」或数据库 <code className="text-[11px]">role_permissions</code>{' '}
          中为该角色开启 <code className="text-[11px]">cashier.view</code>；销售相关修改仍受 <code className="text-[11px]">sales.edit</code>{' '}
          等权限约束。开发测试可在浏览器将 <code className="text-[11px]">localStorage</code> 设为{' '}
          <code className="text-[11px]">disableAuth=true</code>（仅建议本地使用）。
        </p>
        <button
          type="button"
          onClick={() => navigate('/dashboard')}
          className="w-full py-2.5 rounded-xl bg-amber-700 text-white font-medium hover:bg-amber-800"
        >
          返回工作台
        </button>
      </div>
    );
  }
  if (dataLoading) {
    return (
      <div className="flex justify-center items-center h-64 text-gray-600">正在加载商品与门店…</div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold text-gray-800">收银台</h1>
        <div className="flex items-center space-x-2">
          <button
            type="button"
            onClick={resetByFixedTemplate}
            className="px-3 py-2 text-sm rounded-lg border border-amber-200 bg-amber-50 text-amber-700 hover:bg-amber-100"
          >
            固定模板（全部重选）
          </button>
          <span className="text-sm text-gray-500">当前门店：</span>
          <select
            value={selectedStore}
            onChange={(e) => setSelectedStore(e.target.value)}
            className="bg-white border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block p-2.5"
          >
            {stores.map((store) => (
              <option key={store.id} value={store.id}>
                {store.name}
              </option>
            ))}
          </select>
        </div>
      </div>

      <div className="grid grid-cols-1 gap-6">
        <div className="space-y-4">
          <div className="bg-white rounded-xl border border-gray-200 p-3">
            <div className="flex flex-wrap items-center gap-2">
              {([
                { id: 'frame', label: '镜框' },
                { id: 'lens', label: '镜片' },
                { id: 'package', label: '套餐' },
                { id: 'other', label: '其他' },
              ] as Array<{ id: Exclude<ProductQuickCategory, 'all'>; label: string }>).map((x) => (
                <button
                  key={x.id}
                  type="button"
                  onClick={() => setProductQuickCategory(x.id)}
                  className={`px-4 py-2 text-sm rounded-lg border font-semibold ${
                    productQuickCategory === x.id
                      ? 'bg-blue-600 text-white border-blue-600'
                      : 'bg-white text-gray-700 border-gray-200 hover:bg-gray-50'
                  }`}
                  style={{ touchAction: 'manipulation' }}
                >
                  {x.label}
                </button>
              ))}
              <button
                type="button"
                onClick={() => setProductQuickCategory('all')}
                className={`px-3 py-2 text-xs rounded-lg border ${
                  productQuickCategory === 'all'
                    ? 'bg-slate-800 text-white border-slate-800'
                    : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-50'
                }`}
                style={{ touchAction: 'manipulation' }}
              >
                全部
              </button>
            </div>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {productCards}
          </div>

          <div className="bg-white rounded-xl border border-gray-200 p-4 space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="text-base font-bold text-gray-800">快速结算</h3>
              <span className="text-sm text-gray-600">
                已选 {cart.length} 项 · 合计 <span className="font-bold text-blue-600">￥{total.toFixed(2)}</span>
              </span>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
              <input
                value={customerName}
                onChange={(e) => {
                  setCustomerName(e.target.value);
                  setGuestHighlight(false);
                  setGuestInfoError(null);
                }}
                autoComplete="name"
                className="w-full px-3 py-2 text-sm border border-gray-200 rounded-lg"
                placeholder="客人姓名（必填）"
              />
              <input
                value={customerPhone}
                onChange={(e) => {
                  setCustomerPhone(e.target.value);
                  setGuestHighlight(false);
                  setGuestInfoError(null);
                }}
                type="tel"
                inputMode="tel"
                autoComplete="tel"
                className="w-full px-3 py-2 text-sm border border-gray-200 rounded-lg"
                placeholder="联系电话（必填）"
              />
            </div>
            <div className="rounded-lg border border-gray-200 bg-gray-50 p-3">
              <div className="flex items-center justify-between mb-2">
                <p className="text-sm font-semibold text-gray-800">已选商品</p>
                <span className="text-xs text-gray-500">{cart.length} 项</span>
              </div>
              {cart.length === 0 ? (
                <p className="text-xs text-gray-500">点击上方商品后，会在这里显示，可直接删除。</p>
              ) : (
                <div className="space-y-2 max-h-40 overflow-y-auto pr-1">
                  {cart.map((item) => (
                    <div key={item.lineId} className="flex items-center justify-between gap-2 rounded bg-white px-2 py-1.5 border border-gray-100">
                      <div className="min-w-0">
                        <p className="text-sm text-gray-800 truncate">{item.name}</p>
                        <p className="text-[11px] text-gray-500">￥{getFinalUnitPrice(item).toFixed(2)} × {item.quantity}</p>
                      </div>
                      <div className="flex items-center gap-1 shrink-0">
                        <button
                          type="button"
                          onClick={() => updateQuantity(item.lineId, -1)}
                          className="h-7 w-7 rounded border border-gray-200 bg-white text-gray-600 hover:bg-gray-50"
                        >
                          -
                        </button>
                        <button
                          type="button"
                          onClick={() => updateQuantity(item.lineId, 1)}
                          className="h-7 w-7 rounded border border-gray-200 bg-white text-gray-600 hover:bg-gray-50"
                        >
                          +
                        </button>
                        <button
                          type="button"
                          onClick={() => removeFromCart(item.lineId)}
                          className="h-7 w-7 rounded border border-red-200 bg-red-50 text-red-600 hover:bg-red-100"
                          aria-label="删除商品"
                        >
                          <Trash2 className="w-3.5 h-3.5 mx-auto" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
            {guestInfoError ? <div className="text-sm text-red-600">{guestInfoError}</div> : null}
            <div className="flex flex-wrap gap-2">
              <button
                type="button"
                onClick={() => void handleCheckout()}
                disabled={paying || checkoutSubmitting || cart.length === 0}
                className="px-4 py-2 rounded-lg bg-blue-600 text-white font-semibold hover:bg-blue-700 disabled:opacity-50"
              >
                {checkoutSubmitting ? '结算中...' : '生成账单'}
              </button>
              <button
                type="button"
                onClick={openScanPayModal}
                disabled={paying || checkoutSubmitting || cart.length === 0}
                className="px-4 py-2 rounded-lg bg-emerald-600 text-white font-semibold hover:bg-emerald-700 disabled:opacity-50"
              >
                扫码支付并结算
              </button>
            </div>
          </div>
        </div>

        <div className="hidden lg:col-span-2 bg-white p-5 rounded-xl border border-gray-200 h-fit lg:sticky lg:top-4 max-h-[calc(100vh-5rem)] flex flex-col">
          <div className="flex flex-wrap items-center justify-between gap-2 mb-3 shrink-0">
            <div className="flex items-center">
              <ShoppingCart className="w-6 h-6 mr-2 text-gray-700" />
              <h2 className="text-xl font-bold text-gray-800">购物车</h2>
            </div>
            <div className="flex flex-wrap gap-2">
              <button
                type="button"
                onClick={savePendingBill}
                className="inline-flex items-center gap-1 px-2.5 py-1.5 text-xs font-semibold rounded-lg border border-amber-200 bg-amber-50 text-amber-900 hover:bg-amber-100"
              >
                <ClipboardList className="w-3.5 h-3.5" />
                挂单
              </button>
              <button
                type="button"
                onClick={() => setShowPendingModal(true)}
                disabled={pendingBills.length === 0}
                className="inline-flex items-center gap-1 px-2.5 py-1.5 text-xs font-semibold rounded-lg border border-slate-200 bg-white text-slate-800 hover:bg-slate-50 disabled:opacity-40"
              >
                取单
                {pendingBills.length > 0 ? (
                  <span className="rounded-full bg-slate-800 text-white px-1.5 min-w-[1.25rem] text-center">
                    {pendingBills.length}
                  </span>
                ) : null}
              </button>
            </div>
          </div>

          <div className="rounded-xl border border-violet-100 bg-violet-50/60 p-3 mb-3 shrink-0 space-y-2">
            <div className="flex items-center gap-1.5 text-xs font-bold text-violet-900">
              <Glasses className="w-4 h-4" />
              自主配镜（镜框 + 镜片）
            </div>
            <p className="text-[11px] text-violet-900/85 leading-snug">
              不选库存 SKU：手写镜框/镜片说明并填成套价；<strong>不落库存</strong>，单据走加工流程（
              <strong>待加工</strong>
              ）；验光须填球镜/矫正视力/瞳距，柱镜选填（填柱镜须填轴位）。
            </p>
            <input
              value={customComboSummary}
              onChange={(e) => {
                setCustomComboSummary(e.target.value);
                setCustomComboError(null);
              }}
              className="w-full px-2.5 py-2 text-sm border border-violet-200/80 rounded-lg bg-white"
              placeholder="摘要（可选，如：客人自带框 / 渐进片）"
            />
            <input
              value={customComboFrame}
              onChange={(e) => {
                setCustomComboFrame(e.target.value);
                setCustomComboError(null);
              }}
              className={`w-full px-2.5 py-2 text-sm border rounded-lg bg-white ${
                customComboError ? 'border-red-400' : 'border-violet-200/80'
              }`}
              placeholder="镜框属性（必填，如：钛架 全框 枪灰）"
            />
            <input
              value={customComboLens}
              onChange={(e) => {
                setCustomComboLens(e.target.value);
                setCustomComboError(null);
              }}
              className={`w-full px-2.5 py-2 text-sm border rounded-lg bg-white ${
                customComboError ? 'border-red-400' : 'border-violet-200/80'
              }`}
              placeholder="镜片属性（必填，如：蔡司 1.67 防蓝光）"
            />
            <div className="flex flex-col sm:flex-row gap-2">
              <input
                type="text"
                inputMode="decimal"
                autoComplete="off"
                value={customComboPrice}
                onChange={(e) => {
                  setCustomComboPrice(sanitizePriceDraft(e.target.value));
                  setCustomComboError(null);
                }}
                className={`w-full sm:w-32 px-2.5 py-2 text-sm border rounded-lg bg-white ${
                  customComboError ? 'border-red-400' : 'border-violet-200/80'
                }`}
                placeholder="成套价"
              />
              <button
                type="button"
                onClick={addCustomComboLine}
                className="px-3 py-2 text-sm font-semibold rounded-lg bg-violet-600 text-white hover:bg-violet-700"
              >
                加入购物车
              </button>
            </div>
            {customComboError && (
              <div className="mt-2 p-2 bg-red-50 border border-red-200 rounded-lg text-sm text-red-700">
                {customComboError}
              </div>
            )}
          </div>

          {cart.length === 0 ? (
            <div className="text-center py-10 px-3 rounded-xl border border-dashed border-gray-200 bg-gray-50/80 text-sm text-gray-500 space-y-2">
              <p className="font-medium text-gray-600">购物车是空的</p>
              <p className="text-xs text-gray-500 leading-relaxed">
                在左侧点击商品「添加」，或使用「自主配镜」加入本单。需要验光时，输入框会出现在本条列表中。
              </p>
            </div>
          ) : (
            <>
              <div className="space-y-4 mb-4 overflow-y-auto flex-1 min-h-0 pr-1">
                {cart.map((item) => (
                  <div
                    key={item.lineId}
                    className={`rounded-xl p-3 border ${
                      isLensProduct(item) && !isRxComplete(item.rx)
                        ? 'border-amber-300 ring-1 ring-amber-100 bg-amber-50/35'
                        : 'border-gray-100 bg-gray-50/50'
                    }`}
                  >
                    <div className="flex justify-between items-start gap-2 mb-2">
                      <div className="flex-1 min-w-0">
                        <h4 className="font-medium text-gray-800">{item.name}</h4>
                        {(item.category || item.frame_type || item.lens_type) && (
                          <p className="text-[11px] text-gray-500 mt-0.5">
                            {item.category || '—'}
                            {item.frame_type ? ` · 镜框:${item.frame_type}` : ''}
                            {item.lens_type ? ` · 镜片:${item.lens_type}` : ''}
                          </p>
                        )}
                        <p className="text-sm text-gray-500">
                          标价￥{item.price} × {item.quantity}
                        </p>
                        <p className="text-xs text-blue-700">
                          成交单价￥{getFinalUnitPrice(item).toFixed(2)}
                        </p>
                        <span
                          className={`inline-block mt-1 text-[10px] px-1.5 py-0.5 rounded ${
                            isCustomComboLine(item)
                              ? isRxComplete(item.rx)
                                ? 'bg-violet-100 text-violet-800'
                                : 'bg-amber-100 text-amber-800'
                              : isLensProduct(item)
                                ? isRxComplete(item.rx)
                                  ? 'bg-green-100 text-green-700'
                                  : 'bg-amber-100 text-amber-800'
                                : 'bg-gray-100 text-gray-700'
                          }`}
                        >
                          {isCustomComboLine(item)
                            ? isRxComplete(item.rx)
                              ? '自主配镜 · 验光已填齐'
                              : '自主配镜 · 验光未填齐'
                            : isLensProduct(item)
                              ? isRxComplete(item.rx)
                                ? '验光已填齐'
                                : '验光未填齐'
                              : '镜框无需验光'}
                        </span>
                      </div>
                      <div className="flex items-center gap-2 shrink-0">
                        <div className="flex items-center border border-gray-200 rounded-lg overflow-hidden bg-white">
                          <button
                            type="button"
                            onClick={() => updateQuantity(item.lineId, -1)}
                            className="p-1.5 hover:bg-gray-100 text-gray-500"
                          >
                            <Minus className="w-4 h-4" />
                          </button>
                          <span className="px-2 text-sm font-medium">{item.quantity}</span>
                          <button
                            type="button"
                            onClick={() => updateQuantity(item.lineId, 1)}
                            className="p-1.5 hover:bg-gray-100 text-gray-500"
                          >
                            <Plus className="w-4 h-4" />
                          </button>
                        </div>
                        <button
                          type="button"
                          onClick={() => removeFromCart(item.lineId)}
                          className="text-red-500 hover:text-red-700 p-1"
                        >
                          <Trash2 className="w-5 h-5" />
                        </button>
                      </div>
                    </div>
                    <div className="mt-2 grid grid-cols-1 gap-2">
                      {profile?.role === 'manager' && (
                        <div className="flex items-center gap-2">
                          <label className="text-xs text-gray-600 min-w-[72px]">折扣(%)</label>
                          <input
                            type="number"
                            min={0}
                            max={100}
                            value={item.discountPercent}
                            disabled={item.allow_discount === false}
                            onChange={(e) => patchDiscount(item.lineId, Number(e.target.value))}
                            className="w-full px-2 py-1.5 text-xs border border-gray-200 rounded disabled:bg-gray-100 disabled:text-gray-400"
                          />
                          {item.allow_discount === false ? (
                            <span className="text-[10px] text-gray-500 shrink-0">商品设置不参与打折</span>
                          ) : null}
                        </div>
                      )}
                      {(profile?.role === 'owner' || allowSalesEdit) && (
                        <div className="flex items-center gap-2">
                          <label className="text-xs text-gray-600 min-w-[72px]">改价(单价)</label>
                          <input
                            type="text"
                            inputMode="decimal"
                            autoComplete="off"
                            value={
                              unitPriceDraftByLine[item.lineId] !== undefined
                                ? unitPriceDraftByLine[item.lineId]
                                : item.overrideUnitPrice != null
                                  ? String(item.overrideUnitPrice)
                                  : ''
                            }
                            onChange={(e) =>
                              setUnitPriceDraftByLine((p) => ({
                                ...p,
                                [item.lineId]: sanitizePriceDraft(e.target.value),
                              }))
                            }
                            onBlur={() => {
                              const raw = unitPriceDraftByLine[item.lineId];
                              if (raw === undefined) return;
                              patchOwnerPrice(item.lineId, raw);
                              setUnitPriceDraftByLine((p) => {
                                if (!(item.lineId in p)) return p;
                                const next = { ...p };
                                delete next[item.lineId];
                                return next;
                              });
                            }}
                            className="w-full px-2 py-1.5 text-xs border border-gray-200 rounded"
                            placeholder={`默认￥${item.price}`}
                          />
                        </div>
                      )}
                    </div>
                    <div className="space-y-2 mt-2">
                      <p className="text-xs font-semibold text-gray-600">屈光度数</p>
                      {isCustomComboLine(item) ? (
                        <div className="text-[11px] text-violet-900 bg-violet-50/90 border border-violet-100 rounded-lg p-2 mb-1">
                          自主配镜：左右眼球镜/矫正视力/瞳距必填，柱镜选填（填柱镜须轴位），与套餐规则相同；本行不扣 SKU 库存。
                        </div>
                      ) : null}
                      {isLensProduct(item) ? (
                        <div className="rounded-lg border border-blue-100 bg-blue-50/50 p-2.5 text-xs text-blue-900">
                          <div className="flex items-center justify-between gap-2">
                            <div className="leading-relaxed">
                              <p>验光单改为独立窗口填写，避免购物车区域拥挤。</p>
                              <p className="text-[11px] text-blue-700/90">DS/VA/PD 必填，DC 选填（填 DC 则轴位必填）。</p>
                            </div>
                            <button
                              type="button"
                              onClick={() => {
                                setRxEditorLineId(item.lineId);
                                setRxPhotoFileName('');
                                setRxRecognizing(false);
                              }}
                              className="shrink-0 rounded-lg bg-blue-600 px-3 py-1.5 text-xs font-semibold text-white hover:bg-blue-700"
                            >
                              填写验光单
                            </button>
                          </div>
                        </div>
                      ) : (
                        <div className="text-xs text-gray-500 bg-gray-50 border border-gray-100 rounded-lg p-2">
                          该商品为镜框/非镜片：无需填写处方。
                        </div>
                      )}
                    </div>
                  </div>
                ))}
              </div>

              <div className="border-t border-gray-200 pt-4 space-y-4 shrink-0">
                <div
                  ref={customerSectionRef}
                  className={`rounded-lg border p-3 space-y-2 transition-colors ${
                    guestHighlight
                      ? 'border-red-400 bg-red-50/90 ring-2 ring-red-200/80'
                      : 'border-gray-100 bg-gray-50'
                  }`}
                >
                  <p className="text-xs font-semibold text-gray-800">
                    客人信息（必填）
                    {guestHighlight ? (
                      <span className="ml-2 font-bold text-red-600">请填写姓名与电话后再结算</span>
                    ) : null}
                  </p>
                  <input
                    ref={guestNameInputRef}
                    value={customerName}
                    onChange={(e) => {
                      setCustomerName(e.target.value);
                      setGuestHighlight(false);
                      setGuestInfoError(null);
                    }}
                    autoComplete="name"
                    aria-invalid={guestHighlight && !customerName.trim()}
                    className={`w-full px-2.5 py-2 text-sm border rounded focus:ring-2 focus:ring-blue-500 ${
                      guestHighlight && !customerName.trim()
                        ? 'border-red-400 bg-white placeholder:text-red-300'
                        : 'border-gray-200'
                    }`}
                    placeholder="客人姓名（必填）"
                  />
                  <input
                    ref={guestPhoneInputRef}
                    value={customerPhone}
                    onChange={(e) => {
                      setCustomerPhone(e.target.value);
                      setGuestHighlight(false);
                      setGuestInfoError(null);
                    }}
                    type="tel"
                    inputMode="tel"
                    autoComplete="tel"
                    aria-invalid={guestHighlight && !customerPhone.trim()}
                    className={`w-full px-2.5 py-2 text-sm border rounded focus:ring-2 focus:ring-blue-500 ${
                      guestHighlight && !customerPhone.trim()
                        ? 'border-red-400 bg-white placeholder:text-red-300'
                        : 'border-gray-200'
                    }`}
                    placeholder="联系电话（必填）"
                  />
                  {guestInfoError && (
                    <div className="mt-2 p-2 bg-red-50 border border-red-200 rounded-lg text-sm text-red-700">
                      {guestInfoError}
                    </div>
                  )}
                </div>
                <div className="flex justify-between items-center text-lg font-bold">
                  <span>总计</span>
                  <span className="text-blue-600">￥{total.toFixed(2)}</span>
                </div>
                <div className="rounded-lg border border-gray-100 bg-gray-50 p-3 space-y-2">
                  <label htmlFor="cashier-payment-method" className="text-xs font-semibold text-gray-700 block">
                    结算方式（记账用）
                  </label>
                  <select
                    id="cashier-payment-method"
                    value={paymentMethod}
                    onChange={(e) => {
                      const v = e.target.value as PaymentMethod;
                      setPaymentMethod(v);
                      if (v !== 'meituan_douyin') setMeituanVoucher('');
                    }}
                    className="w-full px-3 py-2.5 text-sm border border-gray-200 rounded-lg bg-white focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  >
                    <option value="cash">{paymentMethodLabel('cash')}</option>
                    <option value="wechat">{paymentMethodLabel('wechat')}</option>
                    <option value="alipay">{paymentMethodLabel('alipay')}</option>
                    <option value="meituan_douyin">{paymentMethodLabel('meituan_douyin')}</option>
                  </select>
                  <p className="text-[11px] text-gray-500 leading-snug">
                    选非现金时，出单后会尽量记一笔店内流水（失败不影响出单）。微信/支付宝若要把顾客付款码写入流水，请用「先扫付款码再出单」。美团/抖音请在平台完成验券后选此项记账；也可在弹窗内选填券码备注。
                  </p>
                  {paymentMethod === 'meituan_douyin' ? (
                    <div className="pt-1 space-y-1">
                      <label htmlFor="cashier-meituan-voucher" className="text-[11px] font-medium text-gray-700 block">
                        团购券号（可选，将印在小票底部）
                      </label>
                      <input
                        id="cashier-meituan-voucher"
                        value={meituanVoucher}
                        onChange={(e) => setMeituanVoucher(e.target.value)}
                        className="w-full px-3 py-2 text-sm border border-amber-200 rounded-lg bg-amber-50/50 focus:ring-2 focus:ring-amber-400/40 focus:border-amber-400"
                        placeholder="扫描或手输券码"
                        autoComplete="off"
                      />
                    </div>
                  ) : null}
                </div>
                <button
                  type="button"
                  onClick={() => void handleCheckout()}
                  disabled={paying || checkoutSubmitting}
                  className="w-full py-3 px-4 bg-blue-600 text-white rounded-xl font-bold hover:bg-blue-700 transition-colors shadow-lg shadow-blue-500/30 disabled:opacity-60"
                >
                  {checkoutSubmitting ? '结算提交中...' : '确认结算（直接出单）'}
                </button>
                <button
                  type="button"
                  onClick={openScanPayModal}
                  disabled={paying || checkoutSubmitting}
                  className="w-full py-2.5 px-4 rounded-xl border border-gray-300 bg-white text-sm font-semibold text-gray-700 hover:bg-gray-50 disabled:opacity-60"
                >
                  先扫付款码再出单（扫码枪）
                </button>
                <button
                  type="button"
                  onClick={() => void openMeituanVerifyModal()}
                  disabled={checkoutSubmitting || meituanVerifySubmitting}
                  className="w-full py-2.5 px-4 rounded-xl border border-amber-300 bg-amber-50 text-sm font-semibold text-amber-800 hover:bg-amber-100 disabled:opacity-60"
                >
                  {meituanVerifySubmitting ? '核销中...' : '扫券核销（美团）'}
                </button>
              </div>
            </>
          )}
        </div>
      </div>

      {refundTarget && (
        <div className="fixed inset-0 bg-black/55 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl w-full max-w-md border border-gray-200 p-5 space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="font-bold text-gray-800">销售退单</h3>
              <button
                type="button"
                onClick={() => {
                  setRefundTarget(null);
                  setRefundReasonInput('');
                }}
                className="p-1.5 rounded-full hover:bg-gray-100"
              >
                <X className="w-4 h-4 text-gray-500" />
              </button>
            </div>
            <p className="text-xs text-gray-600">
              单据：{refundTarget.sale_no || refundTarget.id.slice(0, 8)} · {querySaleLineLabel(refundTarget)}
            </p>
            <label className="block text-xs text-gray-500">
              <span className="text-red-600">*</span> 退单原因（必填）
              <textarea
                value={refundReasonInput}
                onChange={(e) => setRefundReasonInput(e.target.value)}
                rows={3}
                required
                className={`mt-1 w-full px-3 py-2 text-sm border rounded-lg ${
                  !refundReasonInput.trim() ? 'border-red-300' : 'border-gray-200'
                }`}
                placeholder="例如：顾客取消、错单、库存问题等"
              />
            </label>
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => {
                  setRefundTarget(null);
                  setRefundReasonInput('');
                }}
                className="py-2 rounded-lg border border-gray-200 text-gray-700 hover:bg-gray-50 text-sm"
              >
                取消
              </button>
              <button
                type="button"
                onClick={() => void submitRefund()}
                disabled={refundSaving || !refundReasonInput.trim()}
                className="py-2 rounded-lg bg-red-600 text-white hover:bg-red-700 text-sm disabled:opacity-60"
              >
                {refundSaving ? '提交中...' : '确认退单'}
              </button>
            </div>
          </div>
        </div>
      )}

      {showPendingModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl w-full max-w-lg border border-gray-200 shadow-xl max-h-[min(80vh,520px)] flex flex-col">
            <div className="px-4 py-3 border-b border-gray-100 flex items-center justify-between shrink-0">
              <h3 className="font-bold text-gray-800">挂单列表</h3>
              <button
                type="button"
                onClick={() => setShowPendingModal(false)}
                className="p-1.5 rounded-full hover:bg-gray-100"
                aria-label="关闭"
              >
                <X className="w-4 h-4 text-gray-500" />
              </button>
            </div>
            <div className="p-3 overflow-y-auto flex-1 space-y-2">
              {pendingBills.length === 0 ? (
                <p className="text-sm text-gray-500 text-center py-8">暂无挂单</p>
              ) : (
                pendingBills.map((bill) => {
                  const n = bill.draft.cart?.length ?? 0;
                  const sum = (bill.draft.cart || []).reduce((s, it) => {
                    const unit =
                      typeof it.overrideUnitPrice === 'number' && it.overrideUnitPrice >= 0
                        ? it.overrideUnitPrice
                        : Number(it.price || 0) * (1 - (it.discountPercent || 0) / 100);
                    return s + unit * (it.quantity || 1);
                  }, 0);
                  return (
                    <div
                      key={bill.id}
                      className="rounded-xl border border-gray-100 bg-gray-50/80 p-3 flex flex-col gap-2"
                    >
                      <div className="flex justify-between gap-2 text-xs text-gray-600">
                        <span>{new Date(bill.createdAt).toLocaleString('zh-CN')}</span>
                        <span>
                          {n} 行 · 约 ￥{sum.toFixed(2)}
                        </span>
                      </div>
                      {bill.note ? <p className="text-xs text-gray-700">备注：{bill.note}</p> : null}
                      <p className="text-xs text-gray-600">
                        客人：{bill.draft.customerName?.trim() || '—'} / {bill.draft.customerPhone?.trim() || '—'}
                      </p>
                      <div className="flex gap-2 pt-1">
                        <button
                          type="button"
                          onClick={() => restorePendingBill(bill)}
                          className="flex-1 py-2 text-xs font-semibold rounded-lg bg-blue-600 text-white hover:bg-blue-700"
                        >
                          取回此单
                        </button>
                        <button
                          type="button"
                          onClick={() => removePendingBill(bill.id)}
                          className="px-3 py-2 text-xs font-semibold rounded-lg border border-red-200 text-red-700 hover:bg-red-50"
                        >
                          删除
                        </button>
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          </div>
        </div>
      )}

      {showScanModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-3 sm:p-4">
          <div className="flex max-h-[min(92vh,880px)] w-full max-w-5xl flex-col overflow-hidden rounded-2xl border border-slate-200/90 bg-white shadow-2xl ring-1 ring-black/5">
            <div className="flex shrink-0 items-center justify-between border-b border-slate-100 bg-gradient-to-r from-slate-50 to-white px-4 py-3 sm:px-6">
              <div>
                <p className="text-[10px] font-semibold uppercase tracking-[0.2em] text-slate-400">收银结算</p>
                <h3 className="text-lg font-bold text-slate-900">
                  {paymentMethod === 'meituan_douyin'
                    ? '美团/抖音团购收款'
                    : paymentMethod === 'wechat'
                      ? '微信扫码收款'
                      : '支付宝扫码收款'}
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setShowScanModal(false)}
                className="rounded-full p-2 text-slate-500 transition hover:bg-slate-100"
                aria-label="关闭"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            <div className="flex min-h-0 flex-1 flex-col lg:flex-row">
              {/* 左侧：订单明细 */}
              <div className="flex min-h-0 flex-col border-b border-slate-100 bg-slate-50/80 lg:w-[42%] lg:border-b-0 lg:border-r lg:border-slate-100">
                <div className="border-b border-slate-100/80 px-4 py-3 sm:px-5">
                  <p className="text-xs font-semibold text-slate-500">订单明细</p>
                  <div className="mt-2 flex items-start gap-2 text-sm text-slate-700">
                    <User className="mt-0.5 h-4 w-4 shrink-0 text-slate-400" />
                    <div>
                      <p className="font-medium text-slate-900">{customerName.trim() || '—'}</p>
                      <p className="text-xs text-slate-500">{customerPhone.trim() || '—'}</p>
                      <p className="mt-1 text-[11px] text-slate-400">
                        门店：{resolveStoreDisplayName(stores.find((s) => s.id === selectedStoreId)?.name)}
                      </p>
                    </div>
                  </div>
                </div>
                <div className="min-h-0 flex-1 overflow-y-auto px-4 py-3 sm:px-5">
                  <ul className="space-y-2.5">
                    {cart.map((item) => {
                      const unit = getFinalUnitPrice(item);
                      const line = unit * item.quantity;
                      return (
                        <li
                          key={item.lineId}
                          className="flex justify-between gap-3 rounded-lg border border-white bg-white/90 px-3 py-2.5 text-sm shadow-sm"
                        >
                          <div className="min-w-0 flex-1">
                            <p className="truncate font-medium text-slate-800">{item.name}</p>
                            <p className="text-xs text-slate-500">
                              ￥{unit.toFixed(2)} × {item.quantity}
                            </p>
                          </div>
                          <p className="shrink-0 font-mono font-semibold text-slate-900">￥{line.toFixed(2)}</p>
                        </li>
                      );
                    })}
                  </ul>
                </div>
                <div className="border-t border-slate-200/80 bg-white px-4 py-4 sm:px-5">
                  <div className="flex items-end justify-between">
                    <span className="text-sm font-medium text-slate-600">应付合计</span>
                    <span className="font-mono text-2xl font-bold tracking-tight text-[#0f3468]">
                      ￥{total.toFixed(2)}
                    </span>
                  </div>
                </div>
              </div>

              {/* 右侧：支付操作 */}
              <div className="flex flex-1 flex-col items-center justify-center gap-5 px-5 py-8 sm:px-8">
                {paymentMethod === 'meituan_douyin' ? (
                  <>
                    <p className="max-w-md text-center text-sm text-slate-600 leading-relaxed">
                      请先在 <strong>美团开店宝</strong> 或 <strong>抖音来客</strong> 完成验券。下方可扫描或粘贴券码，写入本店流水备注（可留空直接确认）。
                    </p>
                    <div className="flex h-40 w-full max-w-md flex-col items-center justify-center rounded-2xl border-2 border-dashed border-amber-200/80 bg-amber-50/40 px-4 text-center text-sm text-amber-900/85">
                      团购券码（可选）
                    </div>
                  </>
                ) : paymentMethod === 'alipay' ? (
                  <button
                    type="button"
                    onClick={() => {
                      scanCodeInputRef.current?.focus();
                    }}
                    className="w-full max-w-md rounded-2xl bg-[#1677FF] py-5 text-center text-xl font-bold tracking-wide text-white shadow-lg shadow-[#1677FF]/35 transition hover:bg-[#0e6de8] active:scale-[0.99]"
                    title="点击后请在下方输入框用扫码枪扫描顾客付款码，再点「确认收款」"
                  >
                    支付宝扫码支付
                  </button>
                ) : (
                  <button
                    type="button"
                    onClick={() => {
                      scanCodeInputRef.current?.focus();
                    }}
                    className="w-full max-w-md rounded-2xl bg-[#07C160] py-5 text-center text-xl font-bold tracking-wide text-white shadow-lg shadow-[#07C160]/30 transition hover:bg-[#06ad56] active:scale-[0.99]"
                    title="点击后请在下方输入框用扫码枪扫描顾客付款码，再点「确认收款」"
                  >
                    微信扫码支付
                  </button>
                )}
                {paymentMethod !== 'meituan_douyin' ? (
                  <p className="max-w-md text-center text-[11px] leading-relaxed text-slate-500 -mt-2">
                    主扫码图未对接时：请用扫码枪扫顾客付款码，输入框获得焦点后扫描即可填入。
                  </p>
                ) : null}

                {paymentMethod !== 'meituan_douyin' ? (
                  <div
                    className={`flex h-52 w-52 flex-col items-center justify-center rounded-2xl border-2 border-dashed bg-slate-50/50 sm:h-56 sm:w-56 ${
                      paymentMethod === 'alipay' ? 'border-[#1677FF]/35' : 'border-[#07C160]/35'
                    }`}
                  >
                    <QrCode
                      className={`h-16 w-16 sm:h-20 sm:w-20 ${
                        paymentMethod === 'alipay' ? 'text-[#1677FF]/40' : 'text-[#07C160]/40'
                      }`}
                      strokeWidth={1.25}
                    />
                    <p className="mt-3 px-4 text-center text-xs font-medium text-slate-500">
                      模拟收款二维码区域
                    </p>
                    <p className="mt-1 px-4 text-center text-[10px] leading-relaxed text-slate-400">
                      正式环境由支付宝开放平台生成预下单链接并渲染码图
                    </p>
                  </div>
                ) : null}

                <div className="w-full max-w-md space-y-2">
                  <label className="block text-xs font-medium text-slate-600">
                    {paymentMethod === 'meituan_douyin'
                      ? '券码或备注（可选，用于支付流水）'
                      : '或：扫码枪扫顾客付款码（被扫）'}
                  </label>
                  <input
                    ref={scanCodeInputRef}
                    autoFocus
                    value={paymentMethod === 'meituan_douyin' ? meituanVoucher : scanCode}
                    onChange={(e) =>
                      paymentMethod === 'meituan_douyin'
                        ? setMeituanVoucher(e.target.value)
                        : setScanCode(e.target.value)
                    }
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') void handleScanPay();
                    }}
                    className={`w-full rounded-xl border border-slate-200 bg-white px-3 py-3 font-mono text-sm focus:outline-none focus:ring-2 ${
                      paymentMethod === 'meituan_douyin'
                        ? 'focus:border-amber-500 focus:ring-amber-500/20'
                        : 'focus:border-[#1677FF] focus:ring-[#1677FF]/20'
                    }`}
                    placeholder={
                      paymentMethod === 'meituan_douyin' ? '可扫描或粘贴团购券码（可空）' : '请扫描顾客出示的付款码'
                    }
                  />
                  <p className="text-[11px] text-slate-400">
                    {paymentMethod === 'meituan_douyin'
                      ? '无券码也可点「确认收款」记账；验券以美团/抖音后台为准。'
                      : '扫码枪一般带自动回车，回车即尝试确认收款。'}
                  </p>
                </div>

                <button
                  type="button"
                  disabled={paying}
                  onClick={() => void completeSaleSkipPaymentLog()}
                  className="w-full max-w-md rounded-xl border border-dashed border-slate-300 bg-white py-2.5 text-sm font-medium text-slate-600 hover:border-slate-400 hover:bg-slate-50 disabled:opacity-60"
                >
                  {checkoutSubmitting ? '结算提交中...' : '线下已收款，直接完成订单（不记支付流水）'}
                </button>
                <div className="flex w-full max-w-md gap-3">
                  <button
                    type="button"
                    onClick={() => setShowScanModal(false)}
                    className="flex-1 rounded-xl border border-slate-200 py-3 text-sm font-semibold text-slate-700 hover:bg-slate-50"
                  >
                    取消
                  </button>
                  <button
                    type="button"
                    onClick={() => void handleScanPay()}
                    disabled={paying || checkoutSubmitting}
                    className={`flex-1 rounded-xl py-3 text-sm font-bold text-white disabled:opacity-60 ${
                      paymentMethod === 'alipay'
                        ? 'bg-[#1677FF] hover:bg-[#0e6de8]'
                        : paymentMethod === 'meituan_douyin'
                          ? 'bg-amber-600 hover:bg-amber-700'
                          : 'bg-[#07C160] hover:bg-[#06ad56]'
                    }`}
                  >
                    {paying ? '收款中...' : checkoutSubmitting ? '结算提交中...' : '确认收款'}
                  </button>
                </div>
              </div>
            </div>

            <div className="shrink-0 border-t border-slate-100 bg-slate-50/90 px-4 py-3 text-center">
              <p className="text-[11px] leading-relaxed text-slate-500">
                {paymentMethod === 'meituan_douyin' ? (
                  <>美团/抖音团购以平台订单与验券结果为准；本窗口仅作店内流水备注。</>
                ) : paymentMethod === 'alipay' ? (
                  <>
                    由 <span className="font-semibold text-[#1677FF]">支付宝</span> 官方提供支付技术支持
                  </>
                ) : (
                  <>
                    由 <span className="font-semibold text-[#07C160]">微信支付</span> 提供支付技术支持
                  </>
                )}
              </p>
            </div>
          </div>
        </div>
      )}

      {showMeituanVerifyModal ? (
        <div className="fixed inset-0 z-[70] flex items-center justify-center bg-black/60 p-4">
          <div className="w-full max-w-lg rounded-2xl border border-gray-200 bg-white p-4 shadow-2xl">
            <div className="mb-3 flex items-center justify-between">
              <h3 className="text-base font-bold text-gray-900">美团扫券核销</h3>
              <button
                type="button"
                onClick={() => {
                  setShowMeituanVerifyModal(false);
                  stopMeituanScanner();
                }}
                className="rounded-full p-1.5 text-gray-500 hover:bg-gray-100"
              >
                <X className="h-4 w-4" />
              </button>
            </div>
            <div className="overflow-hidden rounded-xl border border-gray-200 bg-black">
              <video ref={meituanVideoRef} className="h-64 w-full object-cover" autoPlay muted playsInline />
            </div>
            <p className="mt-2 text-xs text-gray-500">
              {meituanScanning ? '请将券码对准摄像头。' : '摄像头未就绪，可直接手动输入券码核销。'}
            </p>
            <div className="mt-3 flex gap-2">
              <input
                value={meituanDetectedCode}
                onChange={(e) => setMeituanDetectedCode(e.target.value)}
                placeholder="手动输入券码"
                className="flex-1 rounded-lg border border-gray-200 px-3 py-2 text-sm"
              />
              <button
                type="button"
                onClick={() => void submitMeituanVerify(meituanDetectedCode)}
                disabled={meituanVerifySubmitting}
                className="rounded-lg bg-amber-600 px-4 py-2 text-sm font-semibold text-white hover:bg-amber-700 disabled:opacity-60"
              >
                核销
              </button>
            </div>
          </div>
        </div>
      ) : null}

      {editingRxItem ? (
        <div className="fixed inset-0 z-[65] flex items-center justify-center bg-black/60 p-4">
          <div className="w-full max-w-2xl rounded-2xl border border-gray-200 bg-white shadow-2xl">
            <div className="flex items-center justify-between border-b border-gray-100 px-5 py-4">
              <div>
                <h3 className="text-base font-bold text-gray-900">验光单填写窗口</h3>
                <p className="text-xs text-gray-500 mt-0.5">商品：{editingRxItem.name}</p>
              </div>
              <button
                type="button"
                onClick={() => {
                  setRxEditorLineId(null);
                  setRxFocusTarget(null);
                  setRxPhotoFileName('');
                  setRxRecognizing(false);
                }}
                className="rounded-full p-1.5 text-gray-500 hover:bg-gray-100"
                aria-label="关闭"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            <div className="space-y-3 px-5 py-4 max-h-[70vh] overflow-y-auto">
              <div className="rounded-lg border border-amber-200 bg-amber-50/70 p-3">
                <div className="flex flex-wrap items-center gap-2 justify-between">
                  <p className="text-xs text-amber-900">
                    拍照识别入口（预留）：先可上传验光单图片，后续接入 AI 自动识别球镜/柱镜/轴位/瞳距。
                  </p>
                  <label className="inline-flex items-center gap-1 rounded-lg bg-amber-600 px-3 py-1.5 text-xs font-semibold text-white hover:bg-amber-700 cursor-pointer">
                    <Camera className="h-3.5 w-3.5" />
                    {rxRecognizing ? '识别中...' : '拍照识别'}
                    <input
                      type="file"
                      accept="image/*"
                      className="hidden"
                      disabled={rxRecognizing}
                      onChange={async (e) => {
                        const file = e.target.files?.[0];
                        if (!file) return;
                        setRxPhotoFileName(file.name);
                        setRxRecognizing(true);
                        try {
                          const form = new FormData();
                          form.append('image', file);
                          const resp = await fetch('/api/vision/rx-ocr', {
                            method: 'POST',
                            body: form,
                          });
                          const data = (await resp.json()) as {
                            ok?: boolean;
                            error?: string;
                            result?: { right?: Record<string, unknown>; left?: Record<string, unknown> };
                          };
                          if (!resp.ok || !data?.ok || !data.result) {
                            throw new Error(data?.error || '识别失败');
                          }
                          applyRxFromOcr(editingRxItem.lineId, 'right', data.result.right || {});
                          applyRxFromOcr(editingRxItem.lineId, 'left', data.result.left || {});
                          window.alert('识别完成，已自动回填右眼/左眼度数。请核对后保存。');
                        } catch (err) {
                          const msg = err instanceof Error ? err.message : String(err);
                          window.alert('识别失败：' + msg);
                        } finally {
                          setRxRecognizing(false);
                          e.currentTarget.value = '';
                        }
                      }}
                    />
                  </label>
                </div>
                {rxRecognizing ? <p className="mt-2 text-[11px] text-amber-800">正在识别中，请稍候...</p> : null}
                {rxPhotoFileName ? <p className="mt-2 text-[11px] text-amber-800">已选择：{rxPhotoFileName}</p> : null}
              </div>

              <div className="space-y-2" data-rx-editor={editingRxItem.lineId}>
                <EyeRxBlock
                  title="右眼 (OD)"
                  eyeSide="right"
                  eye={editingRxItem.rx.right}
                  onPatch={(p) => patchRx(editingRxItem.lineId, 'right', p)}
                />
                <EyeRxBlock
                  title="左眼 (OS)"
                  eyeSide="left"
                  eye={editingRxItem.rx.left}
                  onPatch={(p) => patchRx(editingRxItem.lineId, 'left', p)}
                />
              </div>
            </div>

            <div className="flex justify-end gap-2 border-t border-gray-100 bg-gray-50 px-5 py-3">
              <button
                type="button"
                onClick={() => {
                  setRxEditorLineId(null);
                  setRxFocusTarget(null);
                  setRxPhotoFileName('');
                  setRxRecognizing(false);
                }}
                className="rounded-lg border border-gray-200 bg-white px-4 py-2 text-sm font-medium text-gray-700 hover:bg-gray-100"
              >
                稍后填写
              </button>
              <button
                type="button"
                onClick={() => {
                  setRxEditorLineId(null);
                  setRxFocusTarget(null);
                }}
                className="rounded-lg bg-blue-600 px-4 py-2 text-sm font-semibold text-white hover:bg-blue-700"
              >
                保存并返回
              </button>
            </div>
          </div>
        </div>
      ) : null}

      {showReceipt && lastOrder && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 p-4 print:p-0 print:bg-white print:static print:inset-auto">
          <div className="bg-white rounded-3xl shadow-2xl max-w-3xl w-full overflow-hidden flex flex-col print:shadow-none print:max-w-none print:w-full print:rounded-none">
            <div className="p-5 border-b border-gray-100 flex justify-between items-center print:hidden">
              <div className="flex items-center space-x-2 text-gray-800">
                <Printer className="w-5 h-5" />
                <h3 className="font-bold">小票打印预览</h3>
              </div>
              <button
                type="button"
                onClick={() => setShowReceipt(false)}
                className="p-2 hover:bg-gray-100 rounded-full transition-all"
              >
                <X className="w-5 h-5 text-gray-500" />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto p-6 flex justify-center bg-gray-50 print:bg-white print:p-0">
              <div id="receipt-print-area" className="bg-white p-3 shadow-xl print:shadow-none print:p-0">
                <PrintTemplate order={lastOrder.orderObject} />
              </div>
            </div>

            <div className="p-6 bg-gray-50 border-t border-gray-100 space-y-3 print:hidden">
              <ReceiptDesktopPrinterBar />
              <button
                type="button"
                onClick={() => setShowReceipt(false)}
                className="w-full py-3 px-4 bg-white border border-gray-200 text-gray-600 rounded-xl font-bold hover:bg-gray-100 transition-all"
              >
                关闭
              </button>
            </div>
          </div>
        </div>
      )}

      {orderLookupOpen ? (
        <div
          className="fixed inset-0 z-[60] flex items-center justify-center bg-black/50 p-4"
          role="dialog"
          aria-modal="true"
          aria-labelledby="order-lookup-title"
        >
          <div className="w-full max-w-md rounded-2xl bg-white shadow-2xl border border-gray-100 overflow-hidden">
            <div className="px-5 py-4 border-b border-gray-100 flex items-center justify-between gap-2">
              <h2 id="order-lookup-title" className="text-base font-bold text-gray-900">
                {orderLookupTitle}
              </h2>
              <button
                type="button"
                onClick={() => setOrderLookupOpen(false)}
                className="p-2 rounded-full hover:bg-gray-100 text-gray-500"
                aria-label="关闭"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="px-5 py-4 max-h-[min(70vh,420px)] overflow-y-auto">
              {orderLookupLoading ? (
                <p className="text-sm text-gray-600">加载中…</p>
              ) : (
                <pre className="text-xs text-gray-800 whitespace-pre-wrap font-sans leading-relaxed">
                  {orderLookupBody}
                </pre>
              )}
            </div>
            <div className="px-5 py-3 border-t border-gray-100 bg-gray-50 flex justify-end">
              <button
                type="button"
                onClick={() => setOrderLookupOpen(false)}
                className="px-4 py-2 rounded-xl bg-blue-600 text-white text-sm font-bold hover:bg-blue-700"
              >
                关闭
              </button>
            </div>
          </div>
        </div>
      ) : null}

    </div>
  );
}

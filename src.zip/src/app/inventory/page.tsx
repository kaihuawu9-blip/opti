'use client';

import { useState, useEffect, useMemo } from 'react';
import { usePathname } from 'next/navigation';
import { supabase, isSupabaseConfigured, supabaseConfigHint } from '@/lib/supabase';
import { useAppNavigate } from '@/lib/useAppNavigate';
import { toChineseErrorMessage, supabaseRlsProductsHint } from '@/lib/userMessages';
import { Plus, Pencil, Trash2, Search, Filter, X, AlertTriangle } from 'lucide-react';
import { useAuth } from '@/components/AuthProvider';
import {
  IMPORT_LENS_BRANDS,
  IMPORT_LENS_CATALOG,
  DOMESTIC_LENS_BRANDS,
  DOMESTIC_LENS_CATALOG,
  formatIndex,
  parseLensType,
  type LensBrandKey,
  type LensSeriesOption,
} from '@/lib/lensCatalog';

type Product = {
  id: string;
  name: string;
  category?: string;
  brand?: string | null;
  model?: string | null;
  frame_type?: string | null;
  lens_type?: string | null;
  price: number;
  stock: number;
  created_at: string;
  allow_discount?: boolean | null;
  allow_points?: boolean | null;
  allow_promo_price?: boolean | null;
  is_hot?: boolean | null;
  is_promo?: boolean | null;
  promo_price?: number | null;
  low_stock_threshold?: number | null;
};

type StockFilter = 'all' | 'low' | 'out' | 'hot' | 'promo';

function thresholdFor(p: Product): number {
  const t = Number(p.low_stock_threshold);
  return Number.isFinite(t) && t > 0 ? t : 10;
}

function isNetworkLikeError(msg: string): boolean {
  const t = (msg || '').toLowerCase();
  return t.includes('network request failed') || t.includes('failed to fetch') || t.includes('fetch failed');
}

export default function InventoryPage() {
  const pathname = usePathname();
  const navigate = useAppNavigate();
  const isPackagesRoute = pathname.replace(/\/+$/, '') === '/packages';
  const { hasPermission } = useAuth();
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [stockFilter, setStockFilter] = useState<StockFilter>('all');
  const [showForm, setShowForm] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    category: '其他',
    brand: '',
    model: '',
    frame_type: '',
    lens_type: '',
    price: '',
    stock: '',
    low_stock_threshold: '10',
    is_hot: false,
    is_promo: false,
    promo_price: '',
    allow_discount: true,
    allow_points: true,
    allow_promo_price: true,
  });

  // 让下拉在“自定义 + 进口/国产”时仍然能显示选中项
  const lensBrandSelectValue = formData.brand === '自定义' ? (formData.model || '') : '';
  const lensCustomOrigin = formData.brand === '自定义' && (formData.model === '进口' || formData.model === '国产') ? formData.model : '';
  const importLensBrand = lensCustomOrigin === '进口'
    ? IMPORT_LENS_BRANDS.find((b) => (formData.lens_type || '').startsWith(`${b} · `)) ?? ''
    : '';
  const domesticLensBrand = lensCustomOrigin === '国产'
    ? DOMESTIC_LENS_BRANDS.find((b) => (formData.lens_type || '').startsWith(`${b} · `)) ?? ''
    : '';
  const activeLensBrand = (importLensBrand || domesticLensBrand) as LensBrandKey | '';

  const parsedLensType = parseLensType(formData.lens_type || '');
  const parsedIndex = parsedLensType.index;

  const availableSeries: LensSeriesOption[] =
    lensCustomOrigin === '进口' && importLensBrand
      ? IMPORT_LENS_CATALOG[importLensBrand]
      : lensCustomOrigin === '国产' && domesticLensBrand
        ? DOMESTIC_LENS_CATALOG[domesticLensBrand]
        : [];

  // 从 lens_type 的“系列部分”匹配到下拉的 series 文本（尽力匹配）。
  const normalizedSeriesPart =
    activeLensBrand && parsedLensType.seriesPart.startsWith(`${activeLensBrand} · `)
      ? parsedLensType.seriesPart.slice(`${activeLensBrand} · `.length).trim()
      : parsedLensType.seriesPart;

  const matchedSeries = activeLensBrand
    ? availableSeries.find((x) => x.series === normalizedSeriesPart)?.series ?? ''
    : '';

  const matchedIndexStr = parsedIndex !== null && Number.isFinite(parsedIndex) ? formatIndex(parsedIndex) : '';

  /** 镜片与套餐共用镜片下拉/系列逻辑；套餐需同时填写镜框属性与镜片属性 */
  const isLensCategoryForm = formData.category === '镜片' || formData.category === '套餐';

  async function fetchProducts() {
    if (!isSupabaseConfigured) {
      setLoading(false);
      return;
    }
    setLoading(true);
    try {
      const { data, error } = await supabase.from('products').select('*').order('created_at', { ascending: false });
      if (error) console.warn('[inventory] fetch products:', error.message);
      if (data) setProducts(data);
    } catch (e) {
      console.warn('[inventory] fetch products:', e);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    // eslint-disable-next-line react-hooks/set-state-in-effect
    fetchProducts();
  }, []);

  const filteredProducts = useMemo(
    () =>
      products.filter((p) => {
        const byPackage =
          !isPackagesRoute || (p.category || '').trim() === '套餐';
        const bySearch = p.name.toLowerCase().includes(search.toLowerCase());
        const th = thresholdFor(p);
        const byStock =
          stockFilter === 'all' ||
          (stockFilter === 'low' && p.stock > 0 && p.stock < th) ||
          (stockFilter === 'out' && p.stock === 0) ||
          (stockFilter === 'hot' && p.is_hot === true) ||
          (stockFilter === 'promo' && p.is_promo === true);
        return byPackage && bySearch && byStock;
      }),
    [products, search, stockFilter, isPackagesRoute],
  );

  const stockStats = useMemo(() => {
    let low = 0;
    let out = 0;
    for (const p of products) {
      const th = thresholdFor(p);
      if (p.stock === 0) out += 1;
      else if (p.stock > 0 && p.stock < th) low += 1;
    }
    return { low, out, total: products.length };
  }, [products]);

  const resetForm = () => {
    setFormData({
      name: '',
      category: '其他',
      brand: '',
      model: '',
      frame_type: '',
      lens_type: '',
      price: '',
      stock: '',
      low_stock_threshold: '10',
      is_hot: false,
      is_promo: false,
      promo_price: '',
      allow_discount: true,
      allow_points: true,
      allow_promo_price: true,
    });
    setEditingProduct(null);
    setShowForm(false);
  };

  const openCreateForm = () => {
    setEditingProduct(null);
    setFormData({
      name: '',
      category: isPackagesRoute ? '套餐' : '其他',
      brand: '',
      model: '',
      frame_type: '',
      lens_type: '',
      price: '',
      stock: '',
      low_stock_threshold: '10',
      is_hot: false,
      is_promo: false,
      promo_price: '',
      allow_discount: true,
      allow_points: true,
      allow_promo_price: true,
    });
    setShowForm(true);
  };

  const openEditForm = (product: Product) => {
    setEditingProduct(product);
    const isLens =
      (product.category || '').trim() === '镜片' ||
      (product.category || '').trim() === '套餐' ||
      Boolean(product.lens_type);
    const isLegacyCustomOrigin = isLens && (product.brand === '进口' || product.brand === '国产');
    const isCustomSplitOrigin = isLens && product.brand === '自定义' && (product.model === '进口' || product.model === '国产');
    const brand = isLegacyCustomOrigin ? '自定义' : product.brand || '';
    const model = isLegacyCustomOrigin ? product.brand || '' : isCustomSplitOrigin ? product.model || '' : product.model || '';
    setFormData({
      name: product.name,
      category: product.category || '其他',
      brand,
      model,
      frame_type: product.frame_type || '',
      lens_type: product.lens_type || '',
      price: String(product.price),
      stock: String(product.stock),
      low_stock_threshold: String(thresholdFor(product)),
      is_hot: product.is_hot === true,
      is_promo: product.is_promo === true,
      promo_price: product.promo_price != null ? String(product.promo_price) : '',
      allow_discount: product.allow_discount !== false,
      allow_points: product.allow_points !== false,
      allow_promo_price: product.allow_promo_price !== false,
    });
    setShowForm(true);
  };

  const setLensPreset = (origin: '进口' | '国产', brandName: LensBrandKey, series: string, index: number) => {
    // 数据不改库结构：brand='自定义'，model='进口/国产'，lens_type 写品牌+系列+折射率。
    setFormData((prev) => ({
      ...prev,
      brand: '自定义',
      model: origin,
      lens_type: `${brandName} · ${series} / ${formatIndex(index)}`,
    }));
  };

  const handleSubmit = async () => {
    if (!isSupabaseConfigured) {
      window.alert(supabaseConfigHint);
      return;
    }
    const name = formData.name.trim();
    const category = formData.category || '其他';
    const brand = formData.brand.trim() || null;
    const model = formData.model.trim() || null;
    const frame_type = formData.frame_type.trim() || null;
    const lensOnly = category === '镜片' || category === '套餐';
    const lens_type = lensOnly ? formData.lens_type.trim() || null : null;
    const price = Number(formData.price);
    const stock = Number(formData.stock);
    const low_stock_threshold = Number.parseInt(String(formData.low_stock_threshold).trim(), 10);
    const promoRaw = formData.promo_price.trim();
    const promoNum = promoRaw === '' ? null : Number(promoRaw);

    if (!name) {
      window.alert('请输入商品名称');
      return;
    }
    if (Number.isNaN(price) || price < 0) {
      window.alert('请输入正确的价格');
      return;
    }
    if (!Number.isInteger(stock) || stock < 0) {
      window.alert('请输入正确的库存整数');
      return;
    }
    if (!Number.isInteger(low_stock_threshold) || low_stock_threshold < 0) {
      window.alert('低库存预警阈值需为大于等于 0 的整数');
      return;
    }
    if (formData.is_promo) {
      if (promoNum === null || Number.isNaN(promoNum) || promoNum < 0) {
        window.alert('勾选特价后请填写有效的特价金额');
        return;
      }
    }

    const retailPayload = {
      low_stock_threshold,
      is_hot: formData.is_hot,
      is_promo: formData.is_promo,
      promo_price: formData.is_promo && promoNum !== null && !Number.isNaN(promoNum) ? promoNum : null,
      allow_discount: formData.allow_discount,
      allow_points: formData.allow_points,
      allow_promo_price: formData.allow_promo_price,
    };

    const payload = { name, category, brand, model, frame_type, lens_type, price, stock, ...retailPayload };
    setSubmitting(true);
    try {
      // 优先走同源 API（服务端写库），避免前端直连 Supabase 在平板/弱网下频繁失败。
      const method = editingProduct ? 'PUT' : 'POST';
      const body = editingProduct ? { id: editingProduct.id, ...payload } : payload;
      const apiResp = await fetch('/api/inventory/products/', {
        method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
      });
      const apiJson = await apiResp.json().catch(() => ({}));
      if (apiResp.ok && apiJson?.ok) {
        resetForm();
        void fetchProducts();
        return;
      }
      if (apiJson?.error === 'SUPABASE_ADMIN_NOT_CONFIGURED') {
        window.alert('保存失败：服务端未配置数据库管理密钥（SUPABASE_SERVICE_ROLE_KEY / ALIYUN_SUPABASE_SERVICE_KEY）。');
        return;
      }

      // API 失败时，再尝试前端直连 Supabase 兜底。
      if (editingProduct) {
        const { error } = await supabase.from('products').update(payload).eq('id', editingProduct.id);
        if (error) {
          const msg = toChineseErrorMessage(error.message);
          window.alert('更新失败：' + msg + (/没有操作权限|权限/.test(msg) ? supabaseRlsProductsHint() : ''));
        } else {
          resetForm();
          void fetchProducts();
        }
      } else {
        const { error } = await supabase.from('products').insert([payload]);
        if (error) {
          const msg = toChineseErrorMessage(error.message);
          window.alert('新增失败：' + msg + (/没有操作权限|权限/.test(msg) ? supabaseRlsProductsHint() : ''));
        } else {
          resetForm();
          void fetchProducts();
        }
      }
    } catch (e) {
      const msg = e instanceof Error ? e.message : String(e);
      if (isNetworkLikeError(msg)) {
        const method = editingProduct ? 'PUT' : 'POST';
        const body = editingProduct ? { id: editingProduct.id, ...payload } : payload;
        const resp = await fetch('/api/inventory/products/', {
          method,
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(body),
        });
        const json = await resp.json().catch(() => ({}));
        if (!resp.ok || !json?.ok) {
          if (json?.error === 'SUPABASE_ADMIN_NOT_CONFIGURED') {
            window.alert('保存失败：服务端未配置数据库管理密钥（SUPABASE_SERVICE_ROLE_KEY / ALIYUN_SUPABASE_SERVICE_KEY）。');
            return;
          }
          window.alert('保存失败：' + toChineseErrorMessage(json?.error || msg));
        } else {
          resetForm();
          void fetchProducts();
        }
      } else {
        window.alert('保存失败：' + toChineseErrorMessage(msg));
      }
    } finally {
      setSubmitting(false);
    }
  };

  const handleDelete = async (id: string) => {
    if (!isSupabaseConfigured) {
      window.alert(supabaseConfigHint);
      return;
    }
    if (typeof window !== 'undefined' && !window.confirm('确定要删除这个商品吗？')) return;
    const { error } = await supabase.from('products').delete().eq('id', id);
    if (error) {
      const msg = toChineseErrorMessage(error.message);
      if (typeof window !== 'undefined') {
        window.alert('删除失败：' + msg + (/没有操作权限|权限/.test(msg) ? supabaseRlsProductsHint() : ''));
      }
    } else {
      fetchProducts();
    }
  };

  if (loading) return <div className="flex justify-center items-center h-64">加载中...</div>;
  if (!hasPermission('inventory.view')) {
    return (
      <div className="text-gray-600">
        当前账号无权访问{isPackagesRoute ? '套餐管理' : '库存管理'}。
      </div>
    );
  }

  const cycleStockFilter = () => {
    setStockFilter((prev) => {
      if (prev === 'all') return 'low';
      if (prev === 'low') return 'out';
      if (prev === 'out') return 'hot';
      if (prev === 'hot') return 'promo';
      return 'all';
    });
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap justify-between items-center gap-3">
        <div className="flex flex-wrap items-center gap-3">
          <h1 className="text-2xl font-bold text-gray-800">
            {isPackagesRoute ? '套餐管理' : '库存管理'}
          </h1>
          {isPackagesRoute ? (
            <button
              type="button"
              onClick={() => navigate('/inventory')}
              className="text-sm text-blue-600 hover:text-blue-800 underline-offset-2 hover:underline"
            >
              查看全部库存
            </button>
          ) : null}
        </div>
        <button
          onClick={openCreateForm}
          className="flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors shadow-md"
        >
          <Plus className="w-5 h-5 mr-1" /> {isPackagesRoute ? '新增套餐' : '新增商品'}
        </button>
      </div>

      {(stockStats.low > 0 || stockStats.out > 0) && (
        <div className="rounded-xl border border-amber-200 bg-amber-50/90 px-4 py-3 flex flex-wrap items-center gap-3 text-sm text-amber-950">
          <AlertTriangle className="w-5 h-5 text-amber-600 shrink-0" />
          <span>
            全店共 <strong>{stockStats.total}</strong> 个 SKU：
            {stockStats.out > 0 && (
              <>
                {' '}
                <strong className="text-red-700">{stockStats.out}</strong> 个缺货
              </>
            )}
            {stockStats.low > 0 && (
              <>
                {stockStats.out > 0 ? '，' : ' '}
                <strong className="text-amber-800">{stockStats.low}</strong> 个低于各自预警阈值
              </>
            )}
            。可在列表「库存」列查看，并在商品编辑里调整预警线。
          </span>
        </div>
      )}

      <div className="bg-white rounded-xl border border-gray-200 overflow-hidden">
        <div className="p-4 border-b border-gray-100 flex flex-col md:flex-row justify-between md:items-center gap-3 md:space-x-4">
          <div className="relative flex-1">
            <Search className="w-5 h-5 absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
            <input
              type="text"
              placeholder="搜索商品名称..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full pl-10 pr-4 py-2.5 bg-gray-50 border border-gray-200 rounded-lg focus:ring-blue-500 focus:border-blue-500 text-sm"
            />
          </div>
          <button
            type="button"
            onClick={cycleStockFilter}
            className="flex items-center px-3 py-2 text-sm text-gray-600 border border-gray-200 rounded-lg hover:bg-gray-50"
          >
            <Filter className="w-4 h-4 mr-1" /> 筛选
          </button>
        </div>
        <div className="px-4 py-2 text-xs text-gray-500 border-b border-gray-100">
          当前筛选：
          {isPackagesRoute ? ' 分类「套餐（镜框+镜片）」；' : ''}
          {stockFilter === 'all' && ' 全部'}
          {stockFilter === 'low' && ' 低库存（低于各商品预警线且 &gt;0）'}
          {stockFilter === 'out' && ' 缺货(=0)'}
          {stockFilter === 'hot' && ' 热卖'}
          {stockFilter === 'promo' && ' 特价'}
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-sm text-gray-700">
            <thead className="bg-gray-50 text-gray-600 text-xs font-semibold">
              <tr>
                <th className="px-6 py-4">商品名称</th>
                <th className="px-6 py-4">标记</th>
                <th className="px-6 py-4">分类/规格</th>
                <th className="px-6 py-4">类型</th>
                <th className="px-6 py-4">价格 (￥)</th>
                <th className="px-6 py-4">库存 / 预警</th>
                <th className="px-6 py-4">最后更新</th>
                <th className="px-6 py-4 text-right">操作</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {filteredProducts.map((product) => {
                const th = thresholdFor(product);
                const isLow = product.stock > 0 && product.stock < th;
                return (
                <tr key={product.id} className="hover:bg-gray-50 transition-colors">
                  <td className="px-6 py-4 font-medium text-gray-900">{product.name}</td>
                  <td className="px-6 py-4 text-xs">
                    {product.is_hot ||
                    product.is_promo ||
                    product.allow_discount === false ||
                    product.allow_points === false ? (
                      <div className="flex flex-wrap gap-1">
                        {product.is_hot ? (
                          <span className="px-1.5 py-0.5 rounded bg-orange-100 text-orange-800">热卖</span>
                        ) : null}
                        {product.is_promo ? (
                          <span className="px-1.5 py-0.5 rounded bg-rose-100 text-rose-800">特价</span>
                        ) : null}
                        {product.allow_discount === false ? (
                          <span className="px-1.5 py-0.5 rounded bg-slate-100 text-slate-600">不打折</span>
                        ) : null}
                        {product.allow_points === false ? (
                          <span className="px-1.5 py-0.5 rounded bg-slate-100 text-slate-600">不积分</span>
                        ) : null}
                      </div>
                    ) : (
                      <span className="text-gray-400">—</span>
                    )}
                  </td>
                  <td className="px-6 py-4 text-gray-600 text-xs">
                    <div>{product.category || '其他'}</div>
                    <div className="text-gray-400">
                      {[product.brand, product.model, product.frame_type, product.lens_type]
                        .filter(Boolean)
                        .join(' / ') || '—'}
                    </div>
                  </td>
                  <td className="px-6 py-4 text-gray-700 text-xs">
                    {(product.category || '').trim() === '套餐'
                      ? '套餐（镜框+镜片）'
                      : product.frame_type && product.lens_type
                        ? '套装（镜框+镜片）'
                        : product.lens_type
                          ? '镜片'
                          : product.frame_type
                            ? '镜框'
                            : product.category || '其他'}
                  </td>
                  <td className="px-6 py-4">
                    {product.is_promo && product.promo_price != null ? (
                      <div>
                        <span className="text-xs text-gray-400 line-through">￥{product.price.toFixed(2)}</span>
                        <div className="text-rose-700 font-semibold">￥{Number(product.promo_price).toFixed(2)}</div>
                      </div>
                    ) : (
                      <>￥{product.price.toFixed(2)}</>
                    )}
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex flex-col gap-0.5">
                      <span
                        className={`inline-flex w-fit px-2 py-1 rounded-full text-xs font-semibold ${
                          product.stock === 0
                            ? 'bg-red-50 text-red-700'
                            : isLow
                              ? 'bg-amber-50 text-amber-800'
                              : 'bg-green-50 text-green-700'
                        }`}
                      >
                        {product.stock}
                      </span>
                      <span className="text-[10px] text-gray-500">预警线 {th}</span>
                    </div>
                  </td>
                  <td className="px-6 py-4 text-gray-500">
                    {new Date(product.created_at).toLocaleDateString()}
                  </td>
                  <td className="px-6 py-4 text-right space-x-2">
                    <button
                      onClick={() => openEditForm(product)}
                      className="p-1.5 text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
                    >
                      <Pencil className="w-4 h-4" />
                    </button>
                    <button 
                      onClick={() => handleDelete(product.id)}
                      className="p-1.5 text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </td>
                </tr>
              );
              })}
              {filteredProducts.length === 0 && (
                <tr>
                  <td colSpan={8} className="px-6 py-12 text-center text-gray-500">
                    未找到匹配商品
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {showForm && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="w-full max-w-3xl bg-white rounded-2xl shadow-2xl border border-gray-100">
            <div className="px-5 py-4 border-b border-gray-100 flex items-center justify-between">
              <h3 className="font-bold text-gray-800">{editingProduct ? '编辑商品' : '新增商品'}</h3>
              <button type="button" onClick={resetForm} className="p-1 hover:bg-gray-100 rounded">
                <X className="w-4 h-4 text-gray-500" />
              </button>
            </div>

            <div className="p-5 grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm text-gray-600 mb-1">商品名称</label>
                <input
                  value={formData.name}
                  onChange={(e) => setFormData((prev) => ({ ...prev, name: e.target.value }))}
                  className="w-full px-3 py-2 border border-gray-200 rounded-lg focus:ring-blue-500 focus:border-blue-500"
                />
              </div>
              <div>
                <label className="block text-sm text-gray-600 mb-1">商品分类</label>
                <select
                  value={formData.category}
                  onChange={(e) => {
                    const next = e.target.value;
                    setFormData((prev) => {
                      const wasLensForm = prev.category === '镜片' || prev.category === '套餐';
                      const nowLensForm = next === '镜片' || next === '套餐';
                      const patch: Partial<typeof prev> = { category: next };
                      if (!nowLensForm) {
                        patch.lens_type = '';
                        if (
                          wasLensForm &&
                          prev.brand === '自定义' &&
                          (prev.model === '进口' || prev.model === '国产')
                        ) {
                          patch.brand = '';
                          patch.model = '';
                        }
                      }
                      return { ...prev, ...patch };
                    });
                  }}
                  className="w-full px-3 py-2 border border-gray-200 rounded-lg focus:ring-blue-500 focus:border-blue-500"
                >
                  <option value="镜框">镜框</option>
                  <option value="镜片">镜片</option>
                  <option value="套餐">套餐（镜框+镜片）</option>
                  <option value="隐形">隐形</option>
                  <option value="配件">配件</option>
                  <option value="其他">其他</option>
                </select>
                {formData.category === '套餐' ? (
                  <p className="mt-1.5 text-[11px] text-violet-700/90 leading-snug">
                    套餐为成套售价：请填写下方「镜框属性」与「镜片属性」（可用镜片品牌下拉自动生成镜片规格）。
                  </p>
                ) : null}
              </div>
              <div>
                <label className="block text-sm text-gray-600 mb-1">品牌</label>
                {isLensCategoryForm ? (
                  <select
                    value={lensBrandSelectValue}
                    onChange={(e) => {
                      const v = e.target.value;
                      if (v === '') {
                        setFormData((prev) => ({ ...prev, brand: '自定义', model: '' }));
                        return;
                      }
                      if (v === '进口' || v === '国产') {
                        setFormData((prev) => ({ ...prev, brand: '自定义', model: v }));
                        return;
                      }
                    }}
                    className="w-full px-3 py-2 border border-gray-200 rounded-lg focus:ring-blue-500 focus:border-blue-500"
                  >
                    <option value="">自定义</option>
                    <option value="进口">自定义 + 进口（大陆）</option>
                    <option value="国产">自定义 + 国产（大陆）</option>
                  </select>
                ) : (
                  <input
                    value={formData.brand}
                    onChange={(e) => setFormData((prev) => ({ ...prev, brand: e.target.value }))}
                    className="w-full px-3 py-2 border border-gray-200 rounded-lg focus:ring-blue-500 focus:border-blue-500"
                  />
                )}
              </div>
              <div>
                <label className="block text-sm text-gray-600 mb-1">型号</label>
                <input
                  value={formData.model}
                  onChange={(e) => setFormData((prev) => ({ ...prev, model: e.target.value }))}
                  disabled={isLensCategoryForm && formData.brand === '自定义' && !!lensCustomOrigin}
                  className="w-full px-3 py-2 border border-gray-200 rounded-lg focus:ring-blue-500 focus:border-blue-500 disabled:bg-gray-100 disabled:text-gray-500"
                />
                {isLensCategoryForm && formData.brand === '自定义' && !!lensCustomOrigin && (
                  <p className="mt-1 text-[11px] text-gray-500">已按“自定义+{lensCustomOrigin}”锁定型号，无需手工输入。</p>
                )}
              </div>
              {isLensCategoryForm && lensCustomOrigin === '进口' && (
                <>
                  <div>
                    <label className="block text-sm text-gray-600 mb-1">进口品牌</label>
                    <select
                      value={importLensBrand}
                      onChange={(e) => {
                        const b = e.target.value as typeof IMPORT_LENS_BRANDS[number];
                        if (!b) return;
                        const firstSeries = IMPORT_LENS_CATALOG[b]?.[0];
                        const firstIndex = firstSeries?.indices?.[0] ?? 1.60;
                        const firstSeriesName = firstSeries?.series ?? '';
                        if (!firstSeriesName) return;
                        setLensPreset('进口', b, firstSeriesName, firstIndex);
                      }}
                      className="w-full px-3 py-2 border border-gray-200 rounded-lg focus:ring-blue-500 focus:border-blue-500"
                    >
                      <option value="">请选择进口品牌</option>
                      {IMPORT_LENS_BRANDS.map((b) => (
                        <option key={b} value={b}>
                          {b}
                        </option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm text-gray-600 mb-1">镜片系列（下拉自动填充）</label>
                    <select
                      value={matchedSeries || ''}
                      onChange={(e) => {
                        const nextSeries = e.target.value;
                        if (!nextSeries) return;
                        const option = availableSeries.find((x) => x.series === nextSeries);
                        const nextIndex = option?.indices?.[0] ?? 1.60;
                        if (!importLensBrand) return;
                        setLensPreset('进口', importLensBrand as LensBrandKey, nextSeries, nextIndex);
                      }}
                      className="w-full px-3 py-2 border border-gray-200 rounded-lg focus:ring-blue-500 focus:border-blue-500"
                    >
                      <option value="">请选择系列</option>
                      {availableSeries.map((opt) => (
                        <option key={opt.series} value={opt.series}>
                          {opt.series}
                        </option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm text-gray-600 mb-1">折射率（n）</label>
                    <select
                      value={matchedIndexStr || ''}
                      onChange={(e) => {
                        const idx = Number.parseFloat(e.target.value);
                        if (!Number.isFinite(idx)) return;
                        const series = matchedSeries || availableSeries[0]?.series || '';
                        if (!series) return;
                        if (!importLensBrand) return;
                        setLensPreset('进口', importLensBrand as LensBrandKey, series, idx);
                      }}
                      className="w-full px-3 py-2 border border-gray-200 rounded-lg focus:ring-blue-500 focus:border-blue-500"
                    >
                      <option value="">请选择折射率</option>
                      {availableSeries
                        .find((x) => x.series === (matchedSeries || availableSeries[0]?.series))
                        ?.indices.map((n) => (
                          <option key={n} value={formatIndex(n)}>
                            {formatIndex(n)}
                          </option>
                        ))}
                    </select>
                  </div>
                </>
              )}
              {isLensCategoryForm && lensCustomOrigin === '国产' && (
                <>
                  <div>
                    <label className="block text-sm text-gray-600 mb-1">国产品牌</label>
                    <select
                      value={domesticLensBrand}
                      onChange={(e) => {
                        const b = e.target.value as typeof DOMESTIC_LENS_BRANDS[number];
                        if (!b) return;
                        const firstSeries = DOMESTIC_LENS_CATALOG[b]?.[0];
                        const firstIndex = firstSeries?.indices?.[0] ?? 1.60;
                        const firstSeriesName = firstSeries?.series ?? '';
                        if (!firstSeriesName) return;
                        setLensPreset('国产', b, firstSeriesName, firstIndex);
                      }}
                      className="w-full px-3 py-2 border border-gray-200 rounded-lg focus:ring-blue-500 focus:border-blue-500"
                    >
                      <option value="">请选择国产品牌</option>
                      {DOMESTIC_LENS_BRANDS.map((b) => (
                        <option key={b} value={b}>
                          {b}
                        </option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm text-gray-600 mb-1">镜片系列（下拉自动填充）</label>
                    <select
                      value={matchedSeries || ''}
                      onChange={(e) => {
                        const nextSeries = e.target.value;
                        if (!nextSeries) return;
                        const option = availableSeries.find((x) => x.series === nextSeries);
                        const nextIndex = option?.indices?.[0] ?? 1.60;
                        if (!domesticLensBrand) return;
                        setLensPreset('国产', domesticLensBrand as LensBrandKey, nextSeries, nextIndex);
                      }}
                      className="w-full px-3 py-2 border border-gray-200 rounded-lg focus:ring-blue-500 focus:border-blue-500"
                    >
                      <option value="">请选择系列</option>
                      {availableSeries.map((opt) => (
                        <option key={opt.series} value={opt.series}>
                          {opt.series}
                        </option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm text-gray-600 mb-1">折射率（n）</label>
                    <select
                      value={matchedIndexStr || ''}
                      onChange={(e) => {
                        const idx = Number.parseFloat(e.target.value);
                        if (!Number.isFinite(idx)) return;
                        const series = matchedSeries || availableSeries[0]?.series || '';
                        if (!series) return;
                        if (!domesticLensBrand) return;
                        setLensPreset('国产', domesticLensBrand as LensBrandKey, series, idx);
                      }}
                      className="w-full px-3 py-2 border border-gray-200 rounded-lg focus:ring-blue-500 focus:border-blue-500"
                    >
                      <option value="">请选择折射率</option>
                      {availableSeries
                        .find((x) => x.series === (matchedSeries || availableSeries[0]?.series))
                        ?.indices.map((n) => (
                          <option key={n} value={formatIndex(n)}>
                            {formatIndex(n)}
                          </option>
                        ))}
                    </select>
                  </div>
                </>
              )}
              {isLensCategoryForm ? (
                <div className="md:col-span-2">
                  <label className="block text-sm text-gray-600 mb-1">镜片属性</label>
                  <input
                    value={formData.lens_type}
                    onChange={(e) => setFormData((prev) => ({ ...prev, lens_type: e.target.value }))}
                    className="w-full px-3 py-2 border border-gray-200 rounded-lg focus:ring-blue-500 focus:border-blue-500"
                    placeholder="如：防蓝光/1.67（若选择了系列，将自动生成）"
                  />
                </div>
              ) : null}
              <div>
                <label className="block text-sm text-gray-600 mb-1">镜框属性</label>
                <input
                  value={formData.frame_type}
                  onChange={(e) => setFormData((prev) => ({ ...prev, frame_type: e.target.value }))}
                  className="w-full px-3 py-2 border border-gray-200 rounded-lg focus:ring-blue-500 focus:border-blue-500"
                  placeholder="如：全框/钛架"
                />
              </div>
              <div>
                <label className="block text-sm text-gray-600 mb-1">价格</label>
                <input
                  type="number"
                  min="0"
                  step="0.01"
                  value={formData.price}
                  onChange={(e) => setFormData((prev) => ({ ...prev, price: e.target.value }))}
                  className="w-full px-3 py-2 border border-gray-200 rounded-lg focus:ring-blue-500 focus:border-blue-500"
                />
              </div>
              <div>
                <label className="block text-sm text-gray-600 mb-1">库存</label>
                <input
                  type="number"
                  min="0"
                  step="1"
                  value={formData.stock}
                  onChange={(e) => setFormData((prev) => ({ ...prev, stock: e.target.value }))}
                  className="w-full px-3 py-2 border border-gray-200 rounded-lg focus:ring-blue-500 focus:border-blue-500"
                />
              </div>
              <div>
                <label className="block text-sm text-gray-600 mb-1">低库存预警线</label>
                <input
                  type="number"
                  min="0"
                  step="1"
                  value={formData.low_stock_threshold}
                  onChange={(e) => setFormData((prev) => ({ ...prev, low_stock_threshold: e.target.value }))}
                  className="w-full px-3 py-2 border border-gray-200 rounded-lg focus:ring-blue-500 focus:border-blue-500"
                />
                <p className="mt-1 text-[11px] text-gray-500">库存大于 0 且低于该值时标为低库存（默认 10）。</p>
              </div>

              <div className="md:col-span-2 rounded-xl border border-gray-100 bg-gray-50/80 p-4 space-y-3">
                <p className="text-sm font-semibold text-gray-800">经营属性（收银联动）</p>
                <div className="flex flex-wrap gap-4">
                  <label className="inline-flex items-center gap-2 text-sm text-gray-700 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={formData.is_hot}
                      onChange={(e) => setFormData((prev) => ({ ...prev, is_hot: e.target.checked }))}
                      className="rounded border-gray-300"
                    />
                    热卖
                  </label>
                  <label className="inline-flex items-center gap-2 text-sm text-gray-700 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={formData.is_promo}
                      onChange={(e) => setFormData((prev) => ({ ...prev, is_promo: e.target.checked }))}
                      className="rounded border-gray-300"
                    />
                    特价
                  </label>
                </div>
                {formData.is_promo ? (
                  <div>
                    <label className="block text-sm text-gray-600 mb-1">特价金额（￥）</label>
                    <input
                      type="number"
                      min="0"
                      step="0.01"
                      value={formData.promo_price}
                      onChange={(e) => setFormData((prev) => ({ ...prev, promo_price: e.target.value }))}
                      className="w-full max-w-xs px-3 py-2 border border-gray-200 rounded-lg focus:ring-blue-500 focus:border-blue-500"
                      placeholder="收银加入购物车时默认此单价"
                    />
                  </div>
                ) : null}
                <div className="flex flex-wrap gap-4">
                  <label className="inline-flex items-center gap-2 text-sm text-gray-700 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={formData.allow_discount}
                      onChange={(e) => setFormData((prev) => ({ ...prev, allow_discount: e.target.checked }))}
                      className="rounded border-gray-300"
                    />
                    店长可打折扣
                  </label>
                  <label className="inline-flex items-center gap-2 text-sm text-gray-700 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={formData.allow_points}
                      onChange={(e) => setFormData((prev) => ({ ...prev, allow_points: e.target.checked }))}
                      className="rounded border-gray-300"
                    />
                    参与会员积分（预留）
                  </label>
                  <label className="inline-flex items-center gap-2 text-sm text-gray-700 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={formData.allow_promo_price}
                      onChange={(e) => setFormData((prev) => ({ ...prev, allow_promo_price: e.target.checked }))}
                      className="rounded border-gray-300"
                    />
                    收银使用特价价
                  </label>
                </div>
              </div>
            </div>

            <div className="px-5 py-4 border-t border-gray-100 flex justify-end space-x-3">
              <button
                type="button"
                onClick={resetForm}
                className="px-4 py-2 rounded-lg border border-gray-200 text-gray-600 hover:bg-gray-50"
              >
                取消
              </button>
              <button
                type="button"
                onClick={handleSubmit}
                disabled={submitting}
                className="px-4 py-2 rounded-lg bg-blue-600 text-white hover:bg-blue-700 disabled:opacity-60"
              >
                {submitting ? '保存中...' : '保存'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

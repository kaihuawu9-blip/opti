'use client';

import { ExternalLink, Monitor } from 'lucide-react';

type Platform = {
  key: string;
  title: string;
  url: string;
};

const PLATFORMS: Platform[] = [
  {
    key: 'meituan',
    title: '美团开店宝',
    url: 'https://e.dianping.com/app/merchant-platform/fe6031ae4f544c4?iUrl=Ly9lLmRpYW5waW5nLmNvbS9hcHAvbWVyY2hhbnQtd29ya2JlbmNoL2luZGV4Lmh0bWwjLw',
  },
  { key: 'douyin', title: '抖音后台', url: 'https://fxg.jinritemai.com/' },
  { key: 'xianyu', title: '闲鱼', url: 'https://2.taobao.com/' },
  { key: 'taobao', title: '淘宝', url: 'https://myseller.taobao.com/' },
  { key: 'jd', title: '京东', url: 'https://shop.jd.com/' },
  { key: 'alibaba', title: '阿里巴巴', url: 'https://myseller.1688.com/' },
];

export default function OnlineOpsPage() {
  async function openInApp(platform: Platform) {
    if (window.electronApp?.openPlatformWindow) {
      const r = await window.electronApp.openPlatformWindow(platform);
      if (!r.ok) window.alert('打开失败：' + (r.error || '未知错误'));
      return;
    }
    window.open(platform.url, '_blank', 'noopener,noreferrer');
  }

  async function openExternal(platform: Platform) {
    if (window.electronApp?.openExternal) {
      const r = await window.electronApp.openExternal(platform.url);
      if (!r.ok) window.alert('打开失败：' + (r.error || '未知错误'));
      return;
    }
    window.open(platform.url, '_blank', 'noopener,noreferrer');
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-2">
        <Monitor className="w-6 h-6 text-blue-600" />
        <h1 className="text-2xl font-bold text-gray-800">线上运营</h1>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {PLATFORMS.map((p) => (
          <div key={p.key} className="rounded-xl border border-gray-200 bg-white p-4 space-y-3">
            <div className="font-semibold text-gray-800">{p.title}</div>
            <div className="text-xs text-gray-500 break-all">{p.url}</div>
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => void openInApp(p)}
                className="px-3 py-2 text-sm rounded-lg bg-blue-600 text-white hover:bg-blue-700"
              >
                应用内窗口打开
              </button>
              <button
                type="button"
                onClick={() => void openExternal(p)}
                className="inline-flex items-center px-3 py-2 text-sm rounded-lg border border-gray-200 text-gray-700 hover:bg-gray-50"
              >
                <ExternalLink className="w-4 h-4 mr-1" />
                外部浏览器打开
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

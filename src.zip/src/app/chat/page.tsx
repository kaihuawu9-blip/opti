'use client';

import { useEffect, useMemo, useRef, useState } from 'react';
import { MessageCircle, Send, Image as ImageIcon, Mic, Square } from 'lucide-react';
import { supabase, isSupabaseConfigured, supabaseConfigHint } from '@/lib/supabase';
import { toChineseErrorMessage } from '@/lib/userMessages';
import { useAuth } from '@/components/AuthProvider';

type ChatMessage = {
  id: string;
  sender_name: string | null;
  sender_role: string | null;
  message_type?: string | null;
  content: string;
  media_data?: string | null;
  created_at: string;
};

export default function ChatPage() {
  const { profile, session } = useAuth();
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [loading, setLoading] = useState(true);
  const [sending, setSending] = useState(false);
  const [input, setInput] = useState('');
  const [recording, setRecording] = useState(false);
  const listRef = useRef<HTMLDivElement | null>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<BlobPart[]>([]);
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const emojiList = ['😀', '😄', '😂', '😎', '👍', '👏', '🙏', '🎉', '❤️', '🔥'];

  const senderName = useMemo(
    () => profile?.full_name?.trim() || session?.user?.email || '店员',
    [profile?.full_name, session?.user?.email],
  );

  async function fetchMessages() {
    if (!isSupabaseConfigured) {
      setLoading(false);
      return;
    }
    const { data, error } = await supabase
      .from('chat_messages')
      .select('id,sender_name,sender_role,message_type,content,media_data,created_at')
      .order('created_at', { ascending: true })
      .limit(120);
    if (!error && data) setMessages(data as ChatMessage[]);
    setLoading(false);
  }

  useEffect(() => {
    void fetchMessages();
    const timer = window.setInterval(() => {
      void fetchMessages();
    }, 3000);
    return () => window.clearInterval(timer);
  }, []);

  useEffect(() => {
    const el = listRef.current;
    if (!el) return;
    el.scrollTop = el.scrollHeight;
  }, [messages.length]);

  const handleSend = async () => {
    const text = input.trim();
    if (!text || sending) return;
    if (!isSupabaseConfigured) {
      window.alert(supabaseConfigHint);
      return;
    }
    setSending(true);
    const { error } = await supabase.from('chat_messages').insert({
      sender_name: senderName,
      sender_role: profile?.role || 'staff',
      message_type: 'text',
      content: text,
    });
    setSending(false);
    if (error) {
      window.alert('发送失败：' + toChineseErrorMessage(error.message));
      return;
    }
    setInput('');
    void fetchMessages();
  };

  const sendImageMessage = async (dataUrl: string) => {
    if (!isSupabaseConfigured) {
      window.alert(supabaseConfigHint);
      return;
    }
    setSending(true);
    const { error } = await supabase.from('chat_messages').insert({
      sender_name: senderName,
      sender_role: profile?.role || 'staff',
      message_type: 'image',
      content: '[图片]',
      media_data: dataUrl,
    });
    setSending(false);
    if (error) {
      window.alert('发送失败：' + toChineseErrorMessage(error.message));
      return;
    }
    void fetchMessages();
  };

  const sendAudioMessage = async (dataUrl: string) => {
    if (!isSupabaseConfigured) {
      window.alert(supabaseConfigHint);
      return;
    }
    setSending(true);
    const { error } = await supabase.from('chat_messages').insert({
      sender_name: senderName,
      sender_role: profile?.role || 'staff',
      message_type: 'audio',
      content: '[语音]',
      media_data: dataUrl,
    });
    setSending(false);
    if (error) {
      window.alert('发送失败：' + toChineseErrorMessage(error.message));
      return;
    }
    void fetchMessages();
  };

  const onPickImage = async (file?: File) => {
    if (!file) return;
    if (!file.type.startsWith('image/')) {
      window.alert('请选择图片文件');
      return;
    }
    if (file.size > 2 * 1024 * 1024) {
      window.alert('图片请控制在 2MB 内');
      return;
    }
    const reader = new FileReader();
    reader.onload = async () => {
      const dataUrl = String(reader.result || '');
      if (!dataUrl) return;
      await sendImageMessage(dataUrl);
    };
    reader.readAsDataURL(file);
  };

  const startRecord = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const mr = new MediaRecorder(stream);
      audioChunksRef.current = [];
      mr.ondataavailable = (e) => {
        if (e.data.size > 0) audioChunksRef.current.push(e.data);
      };
      mr.onstop = async () => {
        const blob = new Blob(audioChunksRef.current, { type: 'audio/webm' });
        const reader = new FileReader();
        reader.onload = async () => {
          const dataUrl = String(reader.result || '');
          if (dataUrl) await sendAudioMessage(dataUrl);
        };
        reader.readAsDataURL(blob);
        stream.getTracks().forEach((t) => t.stop());
      };
      mediaRecorderRef.current = mr;
      mr.start();
      setRecording(true);
    } catch {
      window.alert('无法开启麦克风，请检查系统权限');
    }
  };

  const stopRecord = () => {
    const mr = mediaRecorderRef.current;
    if (!mr) return;
    mr.stop();
    mediaRecorderRef.current = null;
    setRecording(false);
  };

  if (loading) return <div className="flex justify-center items-center h-64">加载中...</div>;

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-2">
        <MessageCircle className="w-6 h-6 text-blue-600" />
        <h1 className="text-2xl font-bold text-gray-800">镜问镜答</h1>
      </div>
      <div className="bg-white rounded-2xl border border-gray-200 p-4">
        <div className="text-xs text-gray-500 mb-3">
          本频道为门店公共问答区，当前使用者：{senderName}
        </div>
        <div
          ref={listRef}
          className="h-[520px] max-h-[72vh] overflow-y-auto rounded-xl border border-gray-100 bg-gray-50 p-3 space-y-2"
        >
          {messages.map((m) => (
            <div key={m.id} className="bg-white border border-gray-200 rounded-xl px-3 py-2">
              <div className="text-xs text-gray-500 mb-1">
                {m.sender_name || '匿名'}{m.sender_role ? `（${m.sender_role}）` : ''} ·{' '}
                {new Date(m.created_at).toLocaleString('zh-CN', {
                  month: '2-digit',
                  day: '2-digit',
                  hour: '2-digit',
                  minute: '2-digit',
                })}
              </div>
              {m.message_type === 'image' && m.media_data ? (
                <img src={m.media_data} alt="chat-image" className="max-h-56 rounded-lg border border-gray-200" />
              ) : m.message_type === 'audio' && m.media_data ? (
                <audio controls src={m.media_data} className="w-72 max-w-full" />
              ) : (
                <div className="text-sm text-gray-800 whitespace-pre-wrap">{m.content}</div>
              )}
            </div>
          ))}
          {messages.length === 0 && <div className="text-sm text-gray-500 p-2">暂无消息，发一条开始提问。</div>}
        </div>
        <div className="mt-3 flex items-center gap-2">
          <div className="hidden md:flex items-center gap-1">
            {emojiList.map((em) => (
              <button
                key={em}
                type="button"
                onClick={() => setInput((prev) => `${prev}${em}`)}
                className="px-1.5 py-1 text-base rounded hover:bg-gray-100"
              >
                {em}
              </button>
            ))}
          </div>
          <input
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                void handleSend();
              }
            }}
            className="flex-1 px-3 py-2 text-sm border border-gray-200 rounded-lg"
            placeholder="输入问题或回答，按回车发送"
          />
          <input
            ref={fileInputRef}
            type="file"
            accept="image/*"
            className="hidden"
            onChange={(e) => {
              const f = e.target.files?.[0];
              void onPickImage(f);
              e.currentTarget.value = '';
            }}
          />
          <button
            type="button"
            onClick={() => fileInputRef.current?.click()}
            disabled={sending || recording}
            className="inline-flex items-center px-3 py-2 text-sm rounded-lg border border-gray-200 hover:bg-gray-50 disabled:opacity-60"
            title="发送图片"
          >
            <ImageIcon className="w-4 h-4" />
          </button>
          <button
            type="button"
            onClick={() => (recording ? stopRecord() : void startRecord())}
            disabled={sending}
            className={`inline-flex items-center px-3 py-2 text-sm rounded-lg border ${
              recording ? 'border-red-200 bg-red-50 text-red-700' : 'border-gray-200 hover:bg-gray-50'
            } disabled:opacity-60`}
            title={recording ? '停止录音并发送' : '开始录音'}
          >
            {recording ? <Square className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
          </button>
          <button
            type="button"
            onClick={() => void handleSend()}
            disabled={sending || recording}
            className="inline-flex items-center px-4 py-2 text-sm rounded-lg bg-blue-600 text-white hover:bg-blue-700 disabled:opacity-60"
          >
            <Send className="w-4 h-4 mr-1" />
            {sending ? '发送中...' : '发送'}
          </button>
        </div>
      </div>
    </div>
  );
}


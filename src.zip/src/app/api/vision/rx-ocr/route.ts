import { NextRequest, NextResponse } from 'next/server';

type RxEye = {
  ds?: string;
  dc?: string;
  axis?: string;
  va?: string;
  pd?: string;
  add?: string;
};

type RxOcrResult = {
  right?: RxEye;
  left?: RxEye;
  customerName?: string;
  date?: string;
  technician?: string;
  notes?: string;
};

function asString(v: unknown): string {
  return typeof v === 'string' ? v.trim() : '';
}

function normalizeEye(v: unknown): RxEye {
  const x = (v && typeof v === 'object' ? v : {}) as Record<string, unknown>;
  return {
    ds: asString(x.ds),
    dc: asString(x.dc),
    axis: asString(x.axis),
    va: asString(x.va),
    pd: asString(x.pd),
    add: asString(x.add),
  };
}

function normalizeResult(v: unknown): RxOcrResult {
  const x = (v && typeof v === 'object' ? v : {}) as Record<string, unknown>;
  return {
    right: normalizeEye(x.right),
    left: normalizeEye(x.left),
    customerName: asString(x.customerName),
    date: asString(x.date),
    technician: asString(x.technician),
    notes: asString(x.notes),
  };
}

export async function POST(req: NextRequest) {
  try {
    const form = await req.formData();
    const file = form.get('image');
    if (!(file instanceof File)) {
      return NextResponse.json({ ok: false, error: '未上传图片' }, { status: 400 });
    }
    if (!file.type.startsWith('image/')) {
      return NextResponse.json({ ok: false, error: '仅支持图片文件' }, { status: 400 });
    }

    const apiKey = (process.env.OPENAI_API_KEY || '').trim();
    const baseUrl = (process.env.OPENAI_BASE_URL || 'https://api.openai.com/v1').trim();
    const model = (process.env.OPENAI_MODEL || 'gpt-4o-mini').trim();
    if (!apiKey) {
      return NextResponse.json({ ok: false, error: '服务端未配置 OPENAI_API_KEY' }, { status: 500 });
    }

    const buf = Buffer.from(await file.arrayBuffer());
    const dataUrl = `data:${file.type};base64,${buf.toString('base64')}`;

    const systemPrompt =
      '你是眼镜门店验光单 OCR 助手。任务：从图片中提取 OD/OS（右/左眼）处方值。只输出 JSON，不要输出其他文字。';
    const userPrompt = `请识别图片中的验光单，输出 JSON，严格使用以下结构：
{
  "right": { "ds": "", "dc": "", "axis": "", "va": "", "pd": "", "add": "" },
  "left": { "ds": "", "dc": "", "axis": "", "va": "", "pd": "", "add": "" },
  "customerName": "",
  "date": "",
  "technician": "",
  "notes": ""
}
规则：
1) 读不到就填空字符串。
2) 不要推测不存在的值。
3) axis 只保留数字，不带 °。
4) pd 保留数字（可含小数点），不要带 mm。
5) 如果同一字段有多个候选，优先清晰、靠近 OD/OS 标签的值。`;

    const upstream = await fetch(`${baseUrl.replace(/\/$/, '')}/chat/completions`, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${apiKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model,
        temperature: 0,
        messages: [
          { role: 'system', content: systemPrompt },
          {
            role: 'user',
            content: [
              { type: 'image_url', image_url: { url: dataUrl } },
              { type: 'text', text: userPrompt },
            ],
          },
        ],
      }),
    });

    const raw = await upstream.text();
    if (!upstream.ok) {
      return NextResponse.json({ ok: false, error: `识别服务失败: ${raw.slice(0, 300)}` }, { status: 502 });
    }

    let content = '';
    try {
      const data = JSON.parse(raw) as { choices?: Array<{ message?: { content?: string } }> };
      content = data?.choices?.[0]?.message?.content?.trim() || '';
    } catch {
      return NextResponse.json({ ok: false, error: '识别服务返回格式异常' }, { status: 502 });
    }
    if (!content) {
      return NextResponse.json({ ok: false, error: '识别结果为空' }, { status: 502 });
    }

    const jsonText = (() => {
      const s = content.indexOf('{');
      const e = content.lastIndexOf('}');
      if (s >= 0 && e > s) return content.slice(s, e + 1);
      return content;
    })();

    let parsed: unknown;
    try {
      parsed = JSON.parse(jsonText);
    } catch {
      return NextResponse.json({ ok: false, error: `识别结果不可解析: ${content.slice(0, 200)}` }, { status: 502 });
    }

    const normalized = normalizeResult(parsed);
    return NextResponse.json({ ok: true, result: normalized });
  } catch (e) {
    const msg = e instanceof Error ? e.message : '未知错误';
    return NextResponse.json({ ok: false, error: msg }, { status: 500 });
  }
}

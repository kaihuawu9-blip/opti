import { NextRequest, NextResponse } from 'next/server';
import { createClient } from '@supabase/supabase-js';
import { getSupabaseServiceKey, getSupabaseUrl } from '@/core/auth/supabase';

function adminClient() {
  const url = getSupabaseUrl();
  const key = getSupabaseServiceKey();
  if (!url || !key) return null;
  return createClient(url, key, { auth: { persistSession: false } });
}

export async function POST(req: NextRequest) {
  try {
    const admin = adminClient();
    if (!admin) return NextResponse.json({ ok: false, error: 'SUPABASE_ADMIN_NOT_CONFIGURED' }, { status: 500 });
    const body = await req.json();
    const { error } = await admin.from('products').insert([body]);
    if (error) return NextResponse.json({ ok: false, error: error.message }, { status: 400 });
    return NextResponse.json({ ok: true });
  } catch (e) {
    return NextResponse.json({ ok: false, error: e instanceof Error ? e.message : String(e) }, { status: 500 });
  }
}

export async function PUT(req: NextRequest) {
  try {
    const admin = adminClient();
    if (!admin) return NextResponse.json({ ok: false, error: 'SUPABASE_ADMIN_NOT_CONFIGURED' }, { status: 500 });
    const body = await req.json();
    const { id, ...changes } = body || {};
    if (!id) return NextResponse.json({ ok: false, error: 'MISSING_ID' }, { status: 400 });
    const { error } = await admin.from('products').update(changes).eq('id', id);
    if (error) return NextResponse.json({ ok: false, error: error.message }, { status: 400 });
    return NextResponse.json({ ok: true });
  } catch (e) {
    return NextResponse.json({ ok: false, error: e instanceof Error ? e.message : String(e) }, { status: 500 });
  }
}

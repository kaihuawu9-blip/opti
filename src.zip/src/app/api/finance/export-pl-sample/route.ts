import { exportEyewearFinanceSaleToXlsx, type EyewearFinanceSaleDocument } from '@/lib/finance';
import { DEFAULT_STORE_DISPLAY_FALLBACK } from '@/lib/constants';

export const runtime = 'nodejs';
/** 静态导出：构建期生成该 GET 的固定响应 */
export const dynamic = 'force-static';

function buildSampleDocument(): EyewearFinanceSaleDocument {
  const now = new Date().toISOString();
  return {
    doc_type: 'eyewear_finance_sale_v1',
    sale_no: `DEMO-PL-${now.slice(0, 10).replace(/-/g, '')}`,
    sale_datetime: now,
    store_name: `${DEFAULT_STORE_DISPLAY_FALLBACK}（演示）`,
    line_items: [
      {
        line_no: 1,
        category: 'frame',
        category_label: '镜架',
        sku_or_name: '演示 TR90 镜架',
        quantity: 1,
        unit_price_tax_inclusive: 680,
        line_amount_tax_inclusive: 680,
        unit_cost: 220,
        line_cost: 220,
        tax_code: 'VAT_13',
      },
      {
        line_no: 2,
        category: 'lens',
        category_label: '镜片',
        sku_or_name: '1.67 非球面',
        quantity: 2,
        unit_price_tax_inclusive: 400,
        line_amount_tax_inclusive: 800,
        unit_cost: 120,
        line_cost: 240,
        tax_code: 'VAT_13',
      },
      {
        line_no: 3,
        category: 'processing_fee',
        category_label: '加工费',
        sku_or_name: '磨边装配',
        quantity: 1,
        unit_price_tax_inclusive: 80,
        line_amount_tax_inclusive: 80,
        unit_cost: 0,
        line_cost: 0,
        tax_code: 'VAT_13',
      },
    ],
    payment_channels: [
      { channel: 'wechat', channel_label: '微信', amount: 1000 },
      { channel: 'cash', channel_label: '现金', amount: 560 },
    ],
    financial_summary: {
      currency: 'CNY',
      vat_rate: 0.13,
      revenue_tax_inclusive: 1560,
      revenue_tax_exclusive: 1380.53,
      output_vat_amount: 179.47,
      total_cost: 460,
      amount_receivable: 1560,
      amount_received: 1560,
      balance_due: 0,
    },
    prescription_ref: {
      prescription_doc_no: 'RX-DEMO-001',
      linked_sale_no: `DEMO-PL-${now.slice(0, 10).replace(/-/g, '')}`,
      remark: '演示数据，仅供导出格式校验',
    },
    compliance_meta: {
      currency: 'CNY',
      vat_rate: 0.13,
      rounding_rule: 'half_up_2dp',
      generated_at: now,
    },
    profit_loss: {
      report_title: '利润表（眼镜零售 · 银行贷款审核参考样式）',
      reporting_entity: `${DEFAULT_STORE_DISPLAY_FALLBACK}（演示）`,
      period_label: `${now.slice(0, 4)}年${now.slice(5, 7)}月`,
      revenue_frames: { current_month: 601.77, year_to_date: 601.77 },
      revenue_lenses_and_accessories: { current_month: 778.76, year_to_date: 778.76 },
      cost_of_sales: { current_month: 460, year_to_date: 460 },
      inventory_provision: { current_month: 0, year_to_date: 0 },
      business_taxes_and_surcharges: { current_month: 179.47, year_to_date: 179.47 },
      selling_expenses: { current_month: 8000, year_to_date: 48000 },
      net_non_operating: { current_month: 0, year_to_date: 0 },
    },
  };
}

export async function GET() {
  try {
    const doc = buildSampleDocument();
    const buffer = await exportEyewearFinanceSaleToXlsx(doc);
    const name = `银行贷款审核标准报表_${doc.sale_no}.xlsx`;
    return new Response(new Uint8Array(buffer), {
      headers: {
        'Content-Type': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        'Content-Disposition': `attachment; filename*=UTF-8''${encodeURIComponent(name)}`,
      },
    });
  } catch (e) {
    const msg = e instanceof Error ? e.message : '导出失败';
    return new Response(JSON.stringify({ error: msg }), {
      status: 500,
      headers: { 'Content-Type': 'application/json' },
    });
  }
}

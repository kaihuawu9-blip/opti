/** 桌面端：保存的热敏打印机系统名（Electron deviceName），用于静默直打、不经 PDF 另存 */

const STORAGE_KEY = 'sale_system_receipt_printer_device_v1';
const COMPAT_MODE_KEY = 'sale_system_printer_compat_mode_v1';

export function getSavedReceiptPrinterDevice(): string | null {
  if (typeof window === 'undefined') return null;
  try {
    const v = window.localStorage.getItem(STORAGE_KEY);
    return v?.trim() || null;
  } catch {
    return null;
  }
}

export function setSavedReceiptPrinterDevice(name: string | null): void {
  if (typeof window === 'undefined') return;
  try {
    if (!name?.trim()) window.localStorage.removeItem(STORAGE_KEY);
    else window.localStorage.setItem(STORAGE_KEY, name.trim());
  } catch {
    // ignore quota
  }
}

export function getPrinterCompatMode(): boolean {
  if (typeof window === 'undefined') return false;
  try {
    return window.localStorage.getItem(COMPAT_MODE_KEY) === 'true';
  } catch {
    return false;
  }
}

export function setPrinterCompatMode(enabled: boolean): void {
  if (typeof window === 'undefined') return;
  try {
    if (enabled) {
      window.localStorage.setItem(COMPAT_MODE_KEY, 'true');
    } else {
      window.localStorage.removeItem(COMPAT_MODE_KEY);
    }
  } catch {
    // ignore quota
  }
}

/** 收银 / 报表小票：使用 Electron IPC 打印到保存的热敏打印机 */
export async function printReceiptWithElectronPreference(order?: any): Promise<void> {
  try {
    const compatMode = getPrinterCompatMode();
    
    if (compatMode) {
      console.log('兼容模式开启，使用 GlassOrderPrinter ESC/POS 纯文本打印...');
      
      if (!order) {
        console.warn('兼容模式需要订单对象，无法打印');
        window.alert('兼容模式需要订单数据，请重新结算后再试');
        return;
      }
      
      try {
        if (!(window as any).electronAPI?.glassOrderPrintTest) {
          console.error('electronAPI.glassOrderPrintTest 不可用');
          window.alert('兼容模式打印通道不可用，请重启桌面端后重试');
          return;
        }
        await (window as any).electronAPI.glassOrderPrintTest(order);
        console.log('GlassOrderPrinter 指令已发送');
      } catch (e) {
        console.error('GlassOrderPrinter 打印失败:', e);
        window.alert('兼容模式打印失败，请检查控制台');
      }
    } else {
      console.log('兼容模式关闭，使用标准高清打印...');
      
      if (!(window as any).electronAPI?.print) {
        console.error('electronAPI.print 不可用');
        return;
      }
      
      console.log('调用 electronAPI.print...');

      const root = typeof document !== 'undefined' ? document.getElementById('receipt-print-area') : null;
      const htmlContent = root
        ? `<!DOCTYPE html><html><head><meta charset="UTF-8"><style>html,body{margin:0;padding:0;background:#fff;}body{display:flex;justify-content:center;}</style></head><body>${root.innerHTML}</body></html>`
        : '';
      const result = await (window as any).electronAPI.print({
        order: order || null,
        htmlContent,
      });
      
      console.log('打印结果:', result);
      
      if (result?.status === 'success') {
        console.log('打印成功！');
      } else {
        console.error('打印失败:', result);
      }
    }
  } catch (e) {
    console.error('打印异常:', e);
  }
}

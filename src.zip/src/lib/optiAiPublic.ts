/**
 * 镜售 Opti-AI 公网域名（解析如 114.55.227.24 的 ECS）。
 * 在 .env.local 中覆盖下列 NEXT_PUBLIC_* 即可切换环境，无需改业务代码。
 *
 * - NEXT_PUBLIC_API_URL              对外 API 根（优先于下方两项），如 https://opti-ai.cn
 * - NEXT_PUBLIC_OPTI_AI_SITE_ORIGIN  主站根地址，默认 https://opti-ai.cn
 * - NEXT_PUBLIC_OPTI_AI_API_ORIGIN   API 根（未设 NEXT_PUBLIC_API_URL 时使用），默认 https://api.opti-ai.cn
 * - NEXT_PUBLIC_OPTI_AI_SUPABASE_URL 可选；若未设置 NEXT_PUBLIC_SUPABASE_URL 则回退此项（自托管 Supabase 时常用）
 */

export const OPTI_AI_SITE_ORIGIN_DEFAULT = 'https://opti-ai.cn';
export const OPTI_AI_API_ORIGIN_DEFAULT = 'https://api.opti-ai.cn';

function trimTrailingSlashes(s: string): string {
  return s.replace(/\/+$/, '');
}

function normalizeOrigin(raw: string | undefined, fallback: string): string {
  const v = (raw ?? '').trim();
  if (!v) return fallback;
  return trimTrailingSlashes(v);
}

/** 主站 origin，无末尾斜杠 */
export function getOptiAiSiteOrigin(): string {
  return normalizeOrigin(process.env.NEXT_PUBLIC_OPTI_AI_SITE_ORIGIN, OPTI_AI_SITE_ORIGIN_DEFAULT);
}

/** API 网关 origin，无末尾斜杠（优先 NEXT_PUBLIC_API_URL，其次 NEXT_PUBLIC_OPTI_AI_API_ORIGIN） */
export function getOptiAiApiOrigin(): string {
  const primary = (process.env.NEXT_PUBLIC_API_URL || '').trim();
  if (primary) return normalizeOrigin(primary, OPTI_AI_API_ORIGIN_DEFAULT);
  return normalizeOrigin(process.env.NEXT_PUBLIC_OPTI_AI_API_ORIGIN, OPTI_AI_API_ORIGIN_DEFAULT);
}

/** 拼接 API 绝对 URL，path 须以 / 开头 */
export function optiAiApiUrl(path: string): string {
  const base = getOptiAiApiOrigin();
  const p = path.startsWith('/') ? path : `/${path}`;
  return `${base}${p}`;
}

/** 桌面端更新清单默认地址（可被 NEXT_PUBLIC_UPDATE_MANIFEST_URL 覆盖） */
export function getDefaultUpdateManifestUrl(): string {
  return `${getOptiAiSiteOrigin()}/update-manifest.json`;
}

import { createClient } from '@supabase/supabase-js';
import type { PaymentOrderUpdater } from '@/lib/payments/types';
import { getSupabaseServiceKey, getSupabaseUrl } from '@/lib/supabase';

/**
 * 将 payment_transactions 中 **external_txn_no = 商户订单号（pay 返回的 outTradeNo）** 的行更新为已支付。
 * 收银创建 pending 记录时请写入相同的 outTradeNo 到 external_txn_no（或按需改为 qr_payload 等字段并在下方调整查询）。
 */
export function createSupabasePaymentOrderUpdater(): PaymentOrderUpdater {
  return async ({ outTradeNo, paidAt }) => {
    const url = getSupabaseUrl();
    const key = getSupabaseServiceKey();
    if (!url || !key || url.includes('placeholder.supabase.co')) {
      throw new Error('缺少有效的云端数据库 URL 或服务密钥（SUPABASE_SERVICE_ROLE_KEY / SUPABASE_SECRET_KEY），无法更新订单');
    }
    const sb = createClient(url, key, { auth: { persistSession: false } });

    const { error } = await sb
      .from('payment_transactions')
      .update({
        status: 'paid',
        paid_at: paidAt || new Date().toISOString(),
      })
      .eq('external_txn_no', outTradeNo);

    if (error) throw new Error(error.message);
  };
}

'use client';

import { useCallback } from 'react';
import { useRouter } from 'next/navigation';

/** 与 next.config trailingSlash 一致 */
export function normalizeAppPath(href: string): string {
  const trimmed = href.replace(/^\/+/, '').replace(/\/+$/, '');
  if (!trimmed) return '/';
  return `/${trimmed}/`;
}

/**
 * 应用内导航：走 Next.js 客户端路由，目标页面的 JS 在点击跳转后才加载（路由级 code-split）。
 * Electron（app://）与浏览器共用同一壳子，不再整页 location 跳转。
 */
export function useAppNavigate() {
  const router = useRouter();

  return useCallback(
    (href: string) => {
      const target = normalizeAppPath(href);
      if (typeof window !== 'undefined' && window.location.protocol !== 'app:') {
        // 在浏览器/平板环境下使用整页跳转，规避部分设备上 SPA 路由不生效的问题。
        window.location.assign(target);
        return;
      }
      router.push(target);
    },
    [router],
  );
}

import type { SupabaseClient } from '@supabase/supabase-js';
import { DEFAULT_STORE_DISPLAY_FALLBACK } from '@/lib/constants';

/** 自 store_config 同步前，或拉取失败时的兜底 */
let cachedDefaultStoreDisplayName: string = DEFAULT_STORE_DISPLAY_FALLBACK;
let cachedSupportHost = 'opti-ai.cn';

export function setDefaultStoreDisplayNameFromConfig(name: string | null | undefined): void {
  const t = String(name ?? '').trim();
  if (t) cachedDefaultStoreDisplayName = t;
}

export function getDefaultStoreDisplayNameSync(): string {
  return cachedDefaultStoreDisplayName;
}

function normalizeSupportHost(value: string | null | undefined): string {
  const s = String(value ?? '').trim();
  if (!s) return '';
  const noProtocol = s.replace(/^https?:\/\//iu, '').replace(/^\/\//u, '');
  const host = noProtocol.split('/')[0]?.trim();
  return host || '';
}

export function getPrintTechSupportLineSync(): string {
  return `技术支持: ${cachedSupportHost}`;
}

/** 优先具体门店 stores.name；空则使用 store_config.default_store_display_name */
export function resolveStoreDisplayName(v: string | null | undefined): string {
  const s = String(v ?? '').trim();
  return s || cachedDefaultStoreDisplayName;
}

export async function fetchStoreConfigDefaults(client: SupabaseClient): Promise<void> {
  try {
    const { data, error } = await client
      .from('store_config')
      .select('default_store_display_name')
      .eq('id', 1)
      .maybeSingle();
    if (error) return;
    const row = data as { default_store_display_name?: string | null } | null;
    if (row?.default_store_display_name) {
      setDefaultStoreDisplayNameFromConfig(row.default_store_display_name);
    }
  } catch {
    // 表不存在或网络失败：保留代码内兜底
  }

  // 兼容不同库结构：优先 support_url，无则回退 domain。
  try {
    const { data, error } = await client.from('store_config').select('support_url').eq('id', 1).maybeSingle();
    if (!error) {
      const row = data as { support_url?: string | null } | null;
      const host = normalizeSupportHost(row?.support_url);
      if (host) {
        cachedSupportHost = host;
        return;
      }
    }
  } catch {
    // ignore and fallback to domain
  }

  try {
    const { data, error } = await client.from('store_config').select('domain').eq('id', 1).maybeSingle();
    if (!error) {
      const row = data as { domain?: string | null } | null;
      const host = normalizeSupportHost(row?.domain);
      if (host) cachedSupportHost = host;
    }
  } catch {
    // 表字段不存在时使用默认域名
  }
}
